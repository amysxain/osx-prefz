Description:
    Autumna is a color scheme for Aptana to give it
    a nice dark, autumn'ish feel. 

Author:
    Brian Reavis
    brianreavis@inwo.com
    http://thirdroute.com

License: 
    Why would I be stingy and apply some sort of licence 
    to this? Use it and/or distribute it however you like. It 
    would be nice if you mention me, if you're feeling kind.  