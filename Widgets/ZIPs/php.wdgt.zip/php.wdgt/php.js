function evalPHP()
{
	var commandLine = document.getElementById('pathToPHP').value;
    var cmd = widget.system(commandLine, evalCallback);
	var code = document.getElementById('inputArea').value;
	if (code.substring(0,2) != '<?') {
		code = "<?php \n" + code;
	}
	cmd.write(code);
	cmd.close();
}

var evalCallback = function (output)
{	
    document.getElementById('OutputLayer').innerHTML =
		output.outputString.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;');
}

var gDoneButton;
var gInfoButton;

function setup()
{
	document.getElementById('OutputLayer').innerHTML = '<i>PHP output will be here.</i>'
	gDoneButton = new AppleGlassButton(document.getElementById("doneButton"), "Done", hidePrefs);
	gInfoButton = new AppleInfoButton(document.getElementById("infoButton"), document.getElementById("front"), "white", "white", showPrefs);
	gInfoButton.setStyle("black","black");	
	loadPath();
}

function hidePrefs()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget) {
        widget.prepareForTransition("ToFront");
    }

    back.style.display="none";
    front.style.display="block"; 

    if (window.widget) {
        setTimeout ('widget.performTransition();', 0);
	}
}

function showPrefs()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    if (window.widget) {
        widget.prepareForTransition("ToBack");
	}

    front.style.display="none";
	back.style.display="block";

	if (window.widget) {
        setTimeout ('widget.performTransition()', 0);
	}
}

function loadPath()
{
	if (window.widget) {
	    var phpPath = widget.preferenceForKey("pathToPHP");
		var inputBox = document.getElementById('pathToPHP');
		
	    if (phpPath && phpPath.length > 0) {
	        inputBox.value = phpPath;
	    } else {
			inputBox.value = 'phpfoo!';
		}
	}
}

function savePath()
{
	if (window.widget) {
	    widget.setPreferenceForKey(document.getElementById('pathToPHP').value, 'pathToPHP');
	}	
}
