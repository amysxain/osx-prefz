<?
function writeOutput($Output, $FileName)
{
	@unlink($FileName);
	if(!$handle = @fopen($FileName, 'w')) {
		echo "Cannot open file ($FileName)";
		exit;
	}
	if(@fwrite($handle, $Output) === FALSE) {
		echo "Cannot write to file ($FileName)";
		exit;
	}
}

//syslog(LOG_WARNING, "Searching for '$argv[1]'");
ob_start();
echo "<div name=\"statusUpdate\" id=\"statusUpdate\"></div>";
//echo "<!-- " . date("U") . " -->";
echo "Searching for <b>'$argv[1]'</b>:<br><ul>";
$handle = fopen("TagsHTML.txt", "r");
while(($data = fgetcsv($handle, 1000, "\t")) !== FALSE) {
	if((stristr($data[0], "$argv[1]")) OR (stristr($data[1], "$argv[1]"))) {
		$Snippet = "&lt;" . trim($data[0]) . "";
		
		if((trim($data[1]) != "") && (trim($data[2]) != "")) {
			$Snippet .= " " . trim($data[1]) . "=&quot;" . trim($data[2]) . "&quot;";
		} elseif(trim($data[1]) != "") {
			$Snippet .= " " . trim($data[1]) . "";
		}
		$Snippet .= "&gt;&lt;/" . trim($data[0]) . "&gt;";
		echo "<li><a href=\"javascript:;\" onclick=\"copyCodeSnippet('$Snippet');\">$Snippet</a>";
		//echo "<br>";
	}
}
echo "</ul>";
fclose($handle);

$Output = ob_get_contents();
ob_end_clean();
writeOutput($Output, 'Output.txt');
?>