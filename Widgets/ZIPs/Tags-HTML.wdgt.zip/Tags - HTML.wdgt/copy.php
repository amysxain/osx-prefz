<?
$Command = '/bin/echo -n ' . escapeshellarg($argv[1]) . ' | /usr/bin/pbcopy';
`$Command`;
?>