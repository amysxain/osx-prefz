function converter(user, number){
if (user == "extra" && number == "4"){var box = eval("document.convert.extra4")}
if (user == "extra" && number == "2"){var box = eval("document.convert.extra2")}
if (user == "extra" && number == "1"){var box = eval("document.convert.extra1")}
if (user == "owner" && number == "4"){var box = eval("document.convert.owner4")}
if (user == "owner" && number == "2"){var box = eval("document.convert.owner2")}
if (user == "owner" && number == "1"){var box = eval("document.convert.owner1")}
if (user == "group" && number == "4"){var box = eval("document.convert.group4")}
if (user == "group" && number == "2"){var box = eval("document.convert.group2")}
if (user == "group" && number == "1"){var box = eval("document.convert.group1")}
if (user == "other" && number == "4"){var box = eval("document.convert.other4")}
if (user == "other" && number == "2"){var box = eval("document.convert.other2")}
if (user == "other" && number == "1"){var box = eval("document.convert.other1")}

if (box.checked == true){
switch (user)
{
case "extra":
document.convert.h_extra.value += ("+number")
var a= (document.convert.h_extra.value)
var b= eval(a)
document.convert.h_extra.value=b
document.convert.t_extra.value=b
break
case "owner":
document.convert.h_owner.value += ("+number")
var a= (document.convert.h_owner.value)
var b= eval(a)
document.convert.h_owner.value=b
document.convert.t_owner.value=b
break
case "group":
document.convert.h_group.value += ("+number")
var a= (document.convert.h_group.value);
var b= eval(a)
document.convert.h_group.value=b
document.convert.t_group.value=b
break
case "other":
document.convert.h_other.value += ("+number")
var a= (document.convert.h_other.value)
var b= eval(a)
document.convert.h_other.value=b
document.convert.t_other.value=b
break
}
}

if (box.checked == false){
switch (user)
{
case "extra":
if (document.convert.h_extra.value == ""){
document.convert.t_extra.value=""
}else {
var a=(document.convert.h_extra.value);
b=a-(number);
c=eval(b);
document.convert.h_extra.value=c
document.convert.t_extra.value=c
}
break
case "owner":
if (document.convert.h_owner.value == ""){
document.convert.t_owner.value=""
}else {
var a=(document.convert.h_owner.value);
b=a-(number);
c=eval(b);
document.convert.h_owner.value=c
document.convert.t_owner.value=c
}
break
case "group":
if (document.convert.h_group.value == ""){
document.convert.t_group.value=""
}else {
var a=(document.convert.h_group.value);
b=a-(number);
c=eval(b);
document.convert.h_group.value=c
document.convert.t_group.value=c
}
break
case "other":
if (document.convert.h_other.value == ""){
document.convert.t_other.value=""
}else {
var a=(document.convert.h_other.value);
b=a-(number);
c=eval(b);
document.convert.h_other.value=c
document.convert.t_other.value=c
}
}
}
}