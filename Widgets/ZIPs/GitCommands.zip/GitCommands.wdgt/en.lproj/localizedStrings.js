var localizedStrings = new Object;

localizedStrings['Title'] = 'Git Commands:';
localizedStrings["Done"] = "Done";
