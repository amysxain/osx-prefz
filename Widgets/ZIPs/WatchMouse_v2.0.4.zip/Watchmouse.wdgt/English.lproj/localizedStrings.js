// English language - mousewatch widget v2

localizedStrings["Done"] = "Done";
localizedStrings["Monitoring Widget"] = "Monitoring Widget";
localizedStrings["PAUSED <br />No connection"] = "PAUSED <br />No connection";
localizedStrings["Checking"] = "Checking";
localizedStrings["ERROR"] = "ERROR";
localizedStrings["Not Found"] = "Not Found";

localizedStrings["Please, set the preferences<br />on the back of the widget."] = "Please, set the preferences<br />on the back of the widget.";

localizedStrings["Watch from this computer"] = "Watch from this computer";
localizedStrings["URL"] = "URL";
localizedStrings["Check every"] = "Check every";
localizedStrings["Minute"] = "Minute";
localizedStrings["Minutes"] = "Minutes";
localizedStrings["Hour"] = "Hour";

localizedStrings["Watch from the worldwide network"] = "Watch from the worldwide network";
localizedStrings["E-mail"] = "E-mail";
localizedStrings["Password"] = "Password";
localizedStrings["Register"] = "Free account";
localizedStrings["Display"] = "Display";
localizedStrings["Period"] = "Period";
localizedStrings["All Rules"] = "All Rules";
localizedStrings["24 hours"] = "24 hours";
localizedStrings["This week"] = "This week";
localizedStrings["Last week"] = "Last week";
localizedStrings["This month"] = "This month";
localizedStrings["Last month"] = "Last month";

localizedStrings["Warn on errror"] = "Warn on errror";
localizedStrings["Never"] = "Never";
localizedStrings["Immediately"] = "Immediately";
localizedStrings["After"] = "After";
localizedStrings["consecutive errors"] = "consecutive errors";

localizedStrings["Join the WM-network"] = "Join the WM-network";

localizedStrings["AVAILABILITY LAST 72 HOURS"] = "AVAILABILITY LAST 72 HOURS";
localizedStrings["Authentication error, please, check the preferences."] = "Authentication error, please, check the preferences.";
localizedStrings["Updating from network..."] = "Updating from network...";
localizedStrings["Watching from network"] = "Watching from network";
localizedStrings["All rules"] = "All rules";
localizedStrings["Error retrieving rules"] = "Error retrieving rules";
localizedStrings["No active rules found"] = "No active rules found";

localizedStrings["Rule"] = "Rule";
localizedStrings["Rules"] = "Rules";

localizedStrings["There is a new version of this widget available."] = "There is a new version of this widget available.";
localizedStrings["Download now"] = "Download&nbsp;now";
localizedStrings["Download later"] = "Download&nbsp;later";


// strings for Growl notification

localizedStrings["PAUSED - No connection"] = "PAUSED - No connection";
localizedStrings["Checked"] = "Checked";
localizedStrings["Status"] = "Status";
localizedStrings["at"] = "at";

localizedStrings["Errors"] = "Errors";
localizedStrings["Error"] = "Error";


// special localized strings - use to adjust the horizontal offset of the 3 help icons

localizedStrings["Local Help Icon Offset"] = "187";
localizedStrings["Net Help Icon Offset"] = "239";
localizedStrings["P2P Help Icon Offset"] = "148";
