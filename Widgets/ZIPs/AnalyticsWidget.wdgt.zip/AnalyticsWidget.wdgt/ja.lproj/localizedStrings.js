// Japanese Localization - Done - Thanks to ZD

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'サイトが選択されていません';
localizedStrings['Username:'] = 'ユーザネーム: ';
localizedStrings['Password:'] = 'パスワード: ';
localizedStrings['visit'] = 'ユーザー サマリー';
localizedStrings['traffic'] = 'トラフィック サマリー';
localizedStrings['content'] = 'コンテンツ サマリー';
localizedStrings['goal'] = 'コンバージョン サマリー';