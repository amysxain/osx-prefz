// Finnish Localization

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'No Site Selected';
localizedStrings['Username:'] = 'Username: ';
localizedStrings['Password:'] = 'Password: ';
localizedStrings['visit'] = 'Kävijöiden esittely';
localizedStrings['traffic'] = 'Liikenteen lähteiden esittely';
localizedStrings['content'] = 'Sisältökatsaus';
localizedStrings['goal'] = 'Tavoitteiden esittely';