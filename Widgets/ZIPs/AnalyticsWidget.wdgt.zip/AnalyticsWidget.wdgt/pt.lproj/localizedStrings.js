// Portugese Localization - done - Thanks Guilhermy (http://www.cinecast.com.br/)

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'Nenhum site selecionado';
localizedStrings['Username:'] = 'Usuário: ';
localizedStrings['Password:'] = 'Senha: ';
localizedStrings['visit'] = 'Visão geral dos visitantes';
localizedStrings['traffic'] = 'Visão geral das fontes de tráfego';
localizedStrings['content'] = 'Visão geral de conteúdo';
localizedStrings['goal'] = 'Visão geral das metas';