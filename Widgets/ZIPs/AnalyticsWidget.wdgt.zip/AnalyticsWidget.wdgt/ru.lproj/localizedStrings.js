// Russian Localization

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'No Site Selected';
localizedStrings['Username:'] = 'Username: ';
localizedStrings['Password:'] = 'Password: ';
localizedStrings['visit'] = 'Обзор посетителей';
localizedStrings['traffic'] = 'Обзор источников трафика';
localizedStrings['content'] = 'Обзор содержания';
localizedStrings['goal'] = 'Обзор целей';