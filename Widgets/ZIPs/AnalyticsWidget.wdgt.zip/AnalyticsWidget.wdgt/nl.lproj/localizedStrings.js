// Dutch Localization

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'No Site Selected';
localizedStrings['Username:'] = 'Gebruikersnaam: ';
localizedStrings['Password:'] = 'Wachtwoord: ';
localizedStrings['visit'] = 'Overzicht van bezoekers';
localizedStrings['traffic'] = 'Overzicht van verkeersbronnen';
localizedStrings['content'] = 'Overzicht van inhoud';
localizedStrings['goal'] = 'Overzicht van doelen';