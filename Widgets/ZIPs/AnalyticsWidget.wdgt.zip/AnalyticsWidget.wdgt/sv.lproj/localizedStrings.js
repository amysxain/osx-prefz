// Swedish Localization - done - Thanks Johan

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'No Site Selected';
localizedStrings['Username:'] = 'Användarnamn: ';
localizedStrings['Password:'] = 'Lösenord: ';
localizedStrings['visit'] = 'Översikt över besökare';
localizedStrings['traffic'] = 'Översikt över trafikkällor';
localizedStrings['content'] = 'Innehållsöversikt';
localizedStrings['goal'] = 'Mål - översikt';