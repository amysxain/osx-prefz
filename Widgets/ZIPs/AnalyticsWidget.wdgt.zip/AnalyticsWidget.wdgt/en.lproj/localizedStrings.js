// English Localization

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'No Site Selected';
localizedStrings['Username:'] = 'Username: ';
localizedStrings['Password:'] = 'Password: ';
localizedStrings['visit'] = 'Visitors Overview';
localizedStrings['traffic'] = 'Traffic Sources Overview';
localizedStrings['content'] = 'Content Overview';
localizedStrings['goal'] = 'Goals Overview';
