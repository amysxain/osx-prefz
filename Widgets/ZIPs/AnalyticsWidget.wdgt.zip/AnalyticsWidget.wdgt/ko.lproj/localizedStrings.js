// Korean Localization

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'No Site Selected';
localizedStrings['Username:'] = 'Username: ';
localizedStrings['Password:'] = 'Password: ';
localizedStrings['visit'] = '방문자 개요';
localizedStrings['traffic'] = '트래픽 소스 개요';
localizedStrings['content'] = '콘텐츠 개요';
localizedStrings['goal'] = '목표 개요';