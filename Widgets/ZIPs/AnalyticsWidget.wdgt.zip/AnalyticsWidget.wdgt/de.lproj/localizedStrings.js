// German Localization - Done - Thanks Laura (http://www.ihcra.com/)

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'Keine Seite ausgewählt';
localizedStrings['Username:'] = 'Benutzername: ';
localizedStrings['Password:'] = 'Kennwort: ';
localizedStrings['visit'] = 'Besucherübersicht';
localizedStrings['traffic'] = 'Übersicht über die Zugriffsquellen';
localizedStrings['content'] = 'Übersicht über die Seiteninhalte';
localizedStrings['goal'] = 'Übersicht über die Ziele';