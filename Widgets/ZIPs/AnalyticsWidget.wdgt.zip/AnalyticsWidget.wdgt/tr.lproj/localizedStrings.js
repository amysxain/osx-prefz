// Turkish Localization

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'No Site Selected';
localizedStrings['Username:'] = 'Username: ';
localizedStrings['Password:'] = 'Password: ';
localizedStrings['visit'] = 'Ziyaretçilere Genel Bakış';
localizedStrings['traffic'] = 'Trafik Kaynaklarına Genel Bakış';
localizedStrings['content'] = 'İçerik Özeti';
localizedStrings['goal'] = 'Hedeflere Genel Bakış';