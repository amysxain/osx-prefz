// Danish Localization - Thanks Michael (http://www.junges.dk/gug)

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'No Site Selected';
localizedStrings['Username:'] = 'Brugernavn: ';
localizedStrings['Password:'] = 'Adgangskode: ';
localizedStrings['visit'] = 'Oversigt over besøgende';
localizedStrings['traffic'] = 'Oversigt over trafikkilder';
localizedStrings['content'] = 'Indholdsoversigt';
localizedStrings['goal'] = 'Måloversigt';