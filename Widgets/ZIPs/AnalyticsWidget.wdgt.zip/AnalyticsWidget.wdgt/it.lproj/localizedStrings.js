// Italian Localization - done - Thanks Matteo

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'Nessun Sito Selezionato';
localizedStrings['Username:'] = 'Nome Utente: ';
localizedStrings['Password:'] = 'Password: ';
localizedStrings['visit'] = 'Visitatori';
localizedStrings['traffic'] = 'Fonti di traffico';
localizedStrings['content'] = 'Sezioni del sito';
localizedStrings['goal'] = 'Obiettivi';