// French Localization - done - thanks Cil (http://www.unjouraparis.com/)

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'Aucun site sélectionné';
localizedStrings['Username:'] = 'Nom d’utilisateur: ';
localizedStrings['Password:'] = 'Mot de passe: ';
localizedStrings['visit'] = 'Visiteurs';
localizedStrings['traffic'] = 'Sources de trafic';
localizedStrings['content'] = 'Contenu';
localizedStrings['goal'] = 'Objectifs';
