// Norwegian Localization

var localizedStrings = new Array;

localizedStrings['No Site Selected'] = 'No Site Selected';
localizedStrings['Username:'] = 'Username: ';
localizedStrings['Password:'] = 'Password: ';
localizedStrings['visit'] = 'Oversikt over besøkende';
localizedStrings['traffic'] = 'Trafikkildeoversikt';
localizedStrings['content'] = 'Innholdsoversikt';
localizedStrings['goal'] = 'Oversikt over mål';