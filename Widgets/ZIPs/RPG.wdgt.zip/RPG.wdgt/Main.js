/*
 *	RPG Widget
 *	Version 1.1.1
 *	Copyright ©2002-2009 David Kreindler. All rights reserved.
 */

// lists of characters corresponding to hasUppercase, hasLowercase, hasNumerals & hasSymbols, respectively
// these should be loaded from xx.lproj/localizedStrings.js

if (typeof(upperChars) === 'undefined')
	var upperChars = new Array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
if (typeof(lowerChars) === 'undefined')
	var lowerChars = new Array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z');
if (typeof(numeralChars) === 'undefined')
	var numeralChars = new Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
if (typeof(symbolChars) === 'undefined')
	var symbolChars = new Array('!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~');

// other localized strings

var copyTitle;	// the tooltip text for the copy button
var errorText;	// the string to display if the password character set is empty

// gui properties & their default values (overridden, on loading, from preferences, if they exist)

function Schema() {
	this.description = 'RPG';
	this.passwordLength = 8;
	this.passwordRevealed = true;
	this.hasUppercase = true;
	this.hasLowercase = true;
	this.hasNumerals = true;
	this.hasSymbols = true;
	this.otherChars = new Array();
	this.excludedChars = new Array();
	this.excludedChars.indexOf = bSearch;
}

var schema = new Schema();

// the current password (or error message)

var password = '';

// password error -- currently just due to an empty character set

var error = false;

// whether we are currently displaying the description or the password (or bullets) in the display box

var descriptionShowing = true;

// display box text colors
// TO DO: localize?

var focusRGB = 'rgb(0, 255, 0)';
var blurRGB = 'rgb(153, 153, 153)';

// flip animation things
// TO DO: get hSize and vSize from wherever they are actually defined (?)

var backsideRequested;
var frontsideRequested;
var hSize = 318;
var vSize = 281;
var stretcher;

// callback function for stretchFinished

function transitionToBack()
{
	stretcher.element.style.height = vSize + 'px';
	stretcher.element.style.width = hSize + 'px';
	window.resizeTo(hSize, vSize);
	
	if (window.widget)
		window.widget.prepareForTransition('ToBack');
		
	document.getElementById('front').style.display='none';
	document.getElementById('back').style.display='block';
	
	if (window.widget)
		setTimeout('window.widget.performTransition()', 0);
}

// callback function for stretcher.Stretch

function stretchFinished()
{
	if (backsideRequested)
		setTimeout( function() { transitionToBack(); }, 30); 
	else if (frontsideRequested)
		frontsideRequested = false;
}

// helpers for load()

// IMPORTANT: these two functions rely on the fact that the preference name is identical to the schema property name and the element ID
//            if this identity needs to change, pass two additional named parameters to the functions

function loadCheckboxFromPrefs(name)
{
	var pref = widget.preferenceForKey(createInstancePreferenceKey(name));
	if (pref && pref.length > 0)
	{
		schema[name] = pref == 'true';
		document.getElementById(name).checked = schema[name];
	}
}
		
function loadCharArrayFromPrefs(name)
{
	var pref = widget.preferenceForKey(createInstancePreferenceKey(name));
	if (pref && pref.length > 0)
	{	// we assume that the array starts out empty
		for (var i = 0; i < pref.length; i++)
			schema[name].push(pref.charAt(i));
		document.getElementById(name).value = pref;
	}
}

// onload handler
			
function load()
{
	// set up localized strings

    document.getElementById('display').innerText = getLocalizedString('RPG');
    document.getElementById('descriptionLabel').innerText = getLocalizedString('Description:');
    document.getElementById('lengthLabel').innerText = getLocalizedString('Length:');
	document.getElementById('passwordRevealedLabel').innerText = getLocalizedString('Show Password'); 
    document.getElementById('includeLabel').innerText = getLocalizedString('Include:');
	document.getElementById('hasUppercaseLabel').innerText = getLocalizedString('Uppercase Letters'); 
	document.getElementById('hasLowercaseLabel').innerText = getLocalizedString('Lowercase Letters'); 
	document.getElementById('hasNumeralsLabel').innerText = getLocalizedString('Numerals'); 
	document.getElementById('hasSymbolsLabel').innerText = getLocalizedString('Punctuation & Symbols'); 
    document.getElementById('excludeLabel').innerText = getLocalizedString('Exclude:');
    document.getElementById('credits').innerText = getLocalizedString('RPG (Widget Edition)');

	errorText = getLocalizedString('ERROR: Nothing Included');

	document.getElementById('newPassword').title = getLocalizedString('click to generate a new password'); 
	document.getElementById('clearButton').title = getLocalizedString('click to clear the password display'); 
	copyText = getLocalizedString('click to copy the current password to the clipboard');

	document.getElementById('description').title = getLocalizedString('enter a name for this instance of the RPG widget'); 
	document.getElementById('passwordLength').title = getLocalizedString('enter the desired number of characters in the password'); 
	document.getElementById('passwordRevealed').title = getLocalizedString('select to show password characters instead of bullets (•)'); 
	document.getElementById('hasUppercase').title = getLocalizedString('select to include uppercase letters (ABCDEFGHIJKLMNOPQRSTUVWXYZ) in the password'); 
	document.getElementById('hasLowercase').title = getLocalizedString('select to include lowercase letters (abcdefghijklmnopqrstuvwxyz) in the password'); 
	document.getElementById('hasNumerals').title = getLocalizedString('select to include numerals (0123456789) in the password'); 
	document.getElementById('hasSymbols').title = getLocalizedString('select to include the following characters in the password: !"#$%&\'()*+,-./:;<=>?@[\]^_`{|}~'); 
	document.getElementById('otherChars').title = getLocalizedString('enter additional characters to include in the password'); 
	document.getElementById('excludedChars').title = getLocalizedString('enter characters to exclude from the password'); 

	// retrieve preferences & set up the GUI accordingly
	
	if (window.widget)
	{
		var pref;
	
		pref = widget.preferenceForKey(createInstancePreferenceKey('description'));
		if (pref && pref.length > 0)
		{
			schema.description = pref;
			document.getElementById('description').value = schema.description;
			document.getElementById('display').innerText = schema.description;	// we always launch with the description displayed
		}
	
		pref = widget.preferenceForKey(createInstancePreferenceKey('passwordLength'));
		if (pref && pref.length > 0)
		{
			schema.passwordLength = parseInt(pref);
			document.getElementById('passwordLength').value = schema.passwordLength.toString();
		}
		
		loadCheckboxFromPrefs('passwordRevealed');
		loadCheckboxFromPrefs('hasUppercase');
		loadCheckboxFromPrefs('hasLowercase');
		loadCheckboxFromPrefs('hasNumerals');
		loadCheckboxFromPrefs('hasSymbols');
		
		loadCharArrayFromPrefs('otherChars');
		loadCharArrayFromPrefs('excludedChars');
	}
	
	// set up buttons
	
    CreateGlassButton('newPassword', { text: 'New Password', onclick: 'newPassword' });
    CreateGlassButton('copyButton', { disabled: true, text: 'Copy', onclick: 'copyPassword' });
    CreateInfoButton('info', { foregroundStyle: 'white', onclick: 'showBack', backgroundStyle: 'white', frontID: 'front' });
/*    CreateInfoButton('clearButton', { foregroundStyle: 'white', onclick: 'clearPasswordDisplay', backgroundStyle: 'white', frontID: 'displayBox' }); */
    CreateGlassButton('done', { text: 'Done', onclick: 'showFront' });

	// construct our stretcher
	
	stretcher = new Stretcher(document.getElementById('front'), 187, 374, stretchFinished);
}

// onfocus handler
	
function focus()
{
	// front
	document.getElementById('display').style.color = focusRGB;
	
	// back
	document.getElementById('credits').style.color = focusRGB;
}

// onblur handler
		
function blur()
{
	// front
	document.getElementById('display').style.color = blurRGB;
	
	// back
	document.getElementById('credits').style.color = blurRGB;
}

// draw either the password (or bullets) or the description in the display box

function updateDisplay()
{
	var displayStr;
	var clearDisplay;

	if (descriptionShowing)	// draw the description
	{
		clearDisplay = 'none';
		displayStr = schema.description;
	}
	else	// draw the password or bullets
	{
		clearDisplay = 'inline';
		
		if (schema.passwordRevealed || error)	// draw the password (or error message)
			displayStr = password;
		else	// !schema.passwordRevealed && !error -- draw bullets -- the user is hiding the password, so we assume they also wish to hide the number of characters in the password, so we draw a fixed number of bullets
			displayStr = '••••••••••••••••••••••••';
	}
	
	// draw the display text, show/hide the clear button, enable/disable the copy button, and set the latter's tooltip text
	
	document.getElementById('display').innerText = displayStr;
	document.getElementById('clearButton').style.display = clearDisplay;
	document.getElementById('copyButton').object.setEnabled(!descriptionShowing);
	document.getElementById('copyButton').title = descriptionShowing ? '' : copyText;
}

// generate a new random password string and update the display

function newPassword()
{
	var provisionalCharSet = new Array();
	var characterSet = new Array();

	// create a provisional character set from the included character groups
	
	provisionalCharSet = schema.otherChars.slice(0);
	
	if (schema.hasUppercase)
		provisionalCharSet = provisionalCharSet.concat(upperChars);
	
	if (schema.hasLowercase)
		provisionalCharSet = provisionalCharSet.concat(lowerChars);
	
	if (schema.hasSymbols)
		provisionalCharSet = provisionalCharSet.concat(symbolChars);
	
	if (schema.hasNumerals)
		provisionalCharSet = provisionalCharSet.concat(numeralChars);
	
	// remove excludedChars from provisionalCharSet to make characterSet
	
	schema.excludedChars.sort();	// make binary search possible
	
	for (var i = 0; i < provisionalCharSet.length; i++)
		if (schema.excludedChars.indexOf(provisionalCharSet[i]) == -1)	// if we do not find the provisional character in excludedChars, then it is ok to use it in the final character set
			characterSet.push(provisionalCharSet[i]);
			
	if (characterSet.length == 0) {	// we cannot make a password if we have no characters to choose from
		error = true;
		password = errorText;
	}
	else	// concatenate random characters from characterSet
	{
		password = '';
		for (var i = 0; i < schema.passwordLength; i++)
			password = password.concat(characterSet.random());
			
		error = false;
	}
	
	descriptionShowing = false;
	updateDisplay();
}

function finishCopy()
{
	/* empty */
}

function copyPassword()		// put the current password on the pasteboard
{
	if (window.widget)
	{
		var command = widget.system('/usr/bin/pbcopy', finishCopy);
		command.write(password);
		command.close();
	}
}

function clearPasswordDisplay()		// display the description string, and register that we are displaying it (not the password string or bullets)
{
	descriptionShowing = true;
	updateDisplay();
}

function showBack()		// flip the widget around
{
	backsideRequested = true;
	stretcher.stretch();
}

function change(target)		// handle changes to the prefs GUI
{
	switch (target.id)
	{
	case 'description':
		schema.description = target.value;
		if (window.widget)
			widget.setPreferenceForKey(schema.description, createInstancePreferenceKey('description'));
		break;
	case 'passwordLength':
		var pwdLen = parseInt(target.value, 10);
		if (isNaN(pwdLen))		// if the text cannot be interpreted as an integer, the best we can do is restore the last value
			target.value = schema.passwordLength;
		else {	// we have an integer
			schema.passwordLength = pwdLen;
			if (window.widget)
				widget.setPreferenceForKey(schema.passwordLength.toString(), createInstancePreferenceKey('passwordLength'));
		}
		break;
	case 'passwordRevealed':
	case 'hasUppercase':
	case 'hasLowercase':
	case 'hasNumerals':
	case 'hasSymbols':
		schema[target.id] = target.checked;
		if (window.widget)
			widget.setPreferenceForKey(schema[target.id] ? 'true' : 'false', createInstancePreferenceKey(target.id));
		break;
	case 'otherChars':
	case 'excludedChars':
		for (var i = 0; i < target.value.length; i++)
			schema[target.id][i] = target.value.charAt(i);
		schema[target.id].length = target.value.length;
		if (window.widget)
			widget.setPreferenceForKey(target.value, createInstancePreferenceKey(target.id));
		break;
	}
	
	// assume that if there was an error, the user fixed it
	
	if (error) {
		error = false;
		descriptionShowing = true;
	}
	
	updateDisplay();	// in case we changed passwordRevealed or cleared error
}

function goHome()	// handle a click on the version string
{
	if(window.widget)
		widget.openURL('http://www.autistici.org/rpg/');
}

function showFront()	// flip the widget back around
{
	if (window.widget)
		window.widget.prepareForTransition('ToFront');

	document.getElementById('front').style.display='block';
	document.getElementById('back').style.display='none';

	if (window.widget)
		setTimeout('window.widget.performTransition()', 0);
	
	if (backsideRequested)
	{
		backsideRequested = false;
		frontsideRequested = true;
		setTimeout( function() { stretcher.stretch(); }, 800); 
	}
}

function remove()	// onremove handler
{
		// we do not need to check for (window.widget) here, because this handler would not be installed otherwise
		widget.setPreferenceForKey(null, createInstancePreferenceKey('description'));
		widget.setPreferenceForKey(null, createInstancePreferenceKey('passwordLength'));
		widget.setPreferenceForKey(null, createInstancePreferenceKey('passwordRevealed'));
		widget.setPreferenceForKey(null, createInstancePreferenceKey('hasUppercase'));
		widget.setPreferenceForKey(null, createInstancePreferenceKey('hasLowercase'));
		widget.setPreferenceForKey(null, createInstancePreferenceKey('hasNumerals'));
		widget.setPreferenceForKey(null, createInstancePreferenceKey('hasSymbols'));
		widget.setPreferenceForKey(null, createInstancePreferenceKey('otherChars'));
		widget.setPreferenceForKey(null, createInstancePreferenceKey('excludedChars'));
}

if (window.widget)
{
	widget.onremove = remove;
}
