/*
 *	RPG Widget
 *	Version 1.1.1
 *	Copyright ©2002-2009 David Kreindler. All rights reserved.
 */

var localizedStrings = new Object;

localizedStrings['RPG'] = 'RPG';
localizedStrings['Copy'] = 'Copy';
localizedStrings['New Password'] = 'New Password';

localizedStrings['Description:'] = 'Description:';
localizedStrings['Length:'] = 'Length:';
localizedStrings['Show Password'] = 'Show Password';
localizedStrings['Include:'] = 'Include:';
localizedStrings['Uppercase Letters'] = 'Uppercase Letters';
localizedStrings['Lowercase Letters'] = 'Lowercase Letters';
localizedStrings['Numerals'] = 'Numerals';
localizedStrings['Punctuation & Symbols'] = 'Punctuation & Symbols';
localizedStrings['Exclude:'] = 'Exclude:';
localizedStrings['RPG (Widget Edition)'] = 'RPG Widget v1.1.1';
localizedStrings['Done'] = 'Done';

localizedStrings['ERROR: Nothing Included'] = 'ERROR: Nothing Included';

localizedStrings['click to generate a new password'] = 'click to generate a new password'; 
localizedStrings['click to clear the password display'] = 'click to clear the password display'; 
localizedStrings['click to copy the current password to the clipboard'] = 'click to copy the current password to the clipboard';

localizedStrings['enter a name for this instance of the RPG widget'] = 'enter a name for this instance of the RPG widget'; 
localizedStrings['enter the desired number of characters in the password'] = 'enter the desired number of characters in the password'; 
localizedStrings['select to show password characters instead of bullets (•)'] = 'select to show password characters instead of bullets (•)'; 
localizedStrings['select to include uppercase letters (ABCDEFGHIJKLMNOPQRSTUVWXYZ) in the password'] = 'select to include uppercase letters (ABCDEFGHIJKLMNOPQRSTUVWXYZ) in the password'; 
localizedStrings['select to include lowercase letters (abcdefghijklmnopqrstuvwxyz) in the password'] = 'select to include lowercase letters (abcdefghijklmnopqrstuvwxyz) in the password'; 
localizedStrings['select to include numerals (0123456789) in the password'] = 'select to include numerals (0123456789) in the password'; 
localizedStrings['select to include the following characters in the password: !"#$%&\'()*+,-./:;<=>?@[\]^_`{|}~'] = 'select to include the following characters in the password: !"#$%&\'()*+,-./:;<=>?@[\]^_`{|}~'; 
localizedStrings['enter additional characters to include in the password'] = 'enter additional characters to include in the password'; 
localizedStrings['enter characters to exclude from the password'] = 'enter characters to exclude from the password';

var upperChars = new Array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
var lowerChars = new Array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z');
var numeralChars = new Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
var symbolChars = new Array('!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~');
