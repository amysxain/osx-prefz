/*
 ***************************************************************
 * <Stretcher object definition.  Stretches a div up and down> *
 ***************************************************************
 */

/*
 * Stretcher constructor; parameters:
 *
 * -- element: The element to stretch
 * -- stretchDistance: Distance (in pixels) the content should stretch
 * -- stretchDuration: How long (in ms) the stretch animation should take
 * -- onFinished: A callback (if no callback is needed, pass null)
 *
 */
 
function Stretcher (element, stretchDistance, stretchDuration, onFinished)
{
	this.element = element;	
	this.stretchDistance = stretchDistance;
	this.duration = stretchDuration;
	this.onFinished = onFinished;

	// min and max position can be changed to alter the stretched/shrunk sizes;
	// getComputedStyle depends on the target (in this case, the stretcher element)
	// being visible, so don't instantiate the Stretcher until the content is shown
	this.minPosition = parseInt(document.defaultView.getComputedStyle(this.element, '').getPropertyValue('height'));
	this.maxPosition = this.minPosition + this.stretchDistance;
	
	// Set variables to what they'd be in the beginning 'shrunk' state
	this.positionFrom = this.minPosition;
	this.positionTo = this.maxPosition;
		
	// new AppleClasses support
	var self = this; // eliminates scope problems in timers/event handlers
	
	this.stretchAnimator = null;
			
	// AppleAnimation callback; this is where we actually change the size
	this.nextFrame = function (animation, now, first, done) {
		self.element.style.height = now + 'px';
	}
	
	this.changeDirection = function () {
		if (self.positionTo == self.maxPosition)
			self.positionTo = self.minPosition;
		else
			self.positionTo = self.maxPosition;
	}
	
	// Callback for AppleAnimator; also called to interrupt a stretch-in-progress
	this.doneStretching = function () {
		// If we've just shrunk, resize the window to the new AFTER the animation is complete
		if (window.widget && (parseInt(self.element.style.height) == self.minPosition))
			window.resizeTo(parseInt(document.defaultView.getComputedStyle(self.element, '').getPropertyValue('width')), self.minPosition);
		self.positionFrom = parseInt(self.element.style.height);
		self.changeDirection();
		delete self.stretchAnimator;
		if (self.onFinished)
			self.onFinished();
	}
}

/*
 * stretch should only be called via a Stretcher instance, i.e. 'instance.stretch(event)'
 * Calling Stretcher_stretch() directly will result in 'this' evaluating to the window
 * object, and the function will fail; parameters:
 */
 
Stretcher.prototype.stretch = function ()
{
	// if we're currently stretching
	if (this.stretchAnimator) {
		this.stretchAnimator.stop();
		var handler = this.onFinished;
		this.onFinished = null;
		this.doneStretching();
		this.onFinished = handler;
	} 
	
	// Resize the window before stretching to make room for the newly-sized content
	if (window.widget && (this.positionTo == this.maxPosition))
		window.resizeTo(parseInt(document.defaultView.getComputedStyle(this.element, '').getPropertyValue('width')), this.positionTo);
	this.stretchAnimator = new AppleAnimator(this.duration, 13, this.positionFrom, this.positionTo, this.nextFrame);
	this.stretchAnimator.oncomplete = this.doneStretching;
	this.stretchAnimator.start();
}
	
/*
 * Report whether or not the Stretcher is in its maximized position
 * DO NOT call this function to determine whether or not the Stretcher is 
 * currently animating; set the onFinished handler to be notified when animation
 * is complete
 */
 
Stretcher.prototype.isStretched = function()
{
	return (parseInt(this.element.style.height) == this.maxPosition);
}
