/*
 *	Copyright 2007-2009 David Kreindler. All rights reserved.
 */
 
function getLocalizedString(string)
{
	try
	{
		string = localizedStrings[string] || string;
	}
	catch (e)
	{
		/* empty */
	}
	return string;
}

function createInstancePreferenceKey(key)
{
	return widget.identifier + '-' + key;
}

function random()	// 0 <= return < 1
{

/*
 *	In current implementations of Dashboard, JavaScript's Math.random() is not random, so we cannot use it.
 *	There are many options, but for the highest quality randomness, we read directly from /dev/random.
 */
 
	// read two bytes from /dev/random; construct a 16-bit unsigned integer from them, and divide the result by 2^16
	
	var command = widget.system("echo $(( ($(echo $(dd if=/dev/random bs=1 count=1 2> /dev/null) | perl -e '$/ = undef; my $val = <STDIN>; print ord($val);') * 0xff) + $(echo $(dd if=/dev/random bs=1 count=1 2> /dev/null) | perl -e '$/ = undef; my $val = <STDIN>; print ord($val);') ))", null);
	return command.outputString / 0x10000;
}

Array.prototype.random = function()			// return a random element from the array
{
	return this[Math.floor(random() * this.length)];
}

function bSearch(target, fromIndex)
{
	// binary search to determine location of target in a sorted Array
	// returns -1 if target is not a member of the Array
	
	var i = (typeof(fromIndex) !== 'undefined' && fromIndex > 0) ? fromIndex : 0;
	var k = this.length - 1;
	while (i <= k)
	{
	    var j = Math.floor((i + k) / 2);
	    if (target > this[j])
	    	i = j + 1;
	    else if (target < this[j])
	        k = j - 1;
	    else	// target == this[j]
	    	return j;
	}
	return -1;	// not found
}
