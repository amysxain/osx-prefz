﻿// Inherit from AppleInfoButton
function XButton(button, div, foregroundStyle, backgroundStyle, onclick)
{
	this = new AppleInfoButton(button, div, foregroundStyle, backgroundStyle, onclick);
	this.setStyle = function(foregroundStyle, backgroundStyle)
		{
			this._flipLabel.src = "file:///System/Library/WidgetResources/ibutton/" + foregroundStyle + "_i.png";
			this._flipCircle.style.background = "url(file:///System/Library/WidgetResources/ibutton/" + backgroundStyle + "_rollie.png) no-repeat top left";
		};
}
