gadget = {
  //The source URL for the gadget from Catalog
  src: "http://gmodules.com/ig/ifr?url=http://www.google.com/ig/modules/googlevideo.xml&amp;synd=open&amp;w=320&amp;h=280&amp;title=__MSG_title__&amp;lang=all&amp;country=ALL&amp;border=%23ffffff%7C3px%2C1px+solid+%23999999&amp;output=js",
  
  //Optional Gadget title, default to URL parameter 'title'
  title: "Google Video",
  
  //Hides gadget title on front side, default true
  hideTitle: true,
  
  //Optional gadget width, defaults to URL parameter 'w'
  //width: 320,
  
  //Optional gadget width, defaults to URL parameter 'h'
  //height: 300,
  
  //Optional gadget border as CSS properties, defaults to URL parameter 'border'  
  //border: "",
  
  //Optional refresh image on front side, default false 
  showRefresh: true,
  
  //Optional auto refresh time in min 
  //autoRefresh: 10,
  
  //Optional show backside first, default false 
  //startOnBackside: true
  
  //Optional gadget parameter names
  //params: [],
  
  //Not used: Leave to keep Safari happy
  notUsed: null
}
