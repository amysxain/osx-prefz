var backWidth = 220;
var backHeight = 220;
var frontWidth = 190;
var frontHeight = 190;
var extraWidth = 20;
var extraHeight = 20;
var spaceWidth = 30;
var spaceHeight = 70;
var backShown = false;

function setup() {
  if (window.widget) {
    widgetSetup();
    parse();
    readPrefs();
    updateParams();
    var style1 = 
      document.defaultView.getComputedStyle(document.getElementById("Gadgets"), "");
    var style2 = 
      document.defaultView.getComputedStyle(document.getElementById("Background"), "");
    extraWidth = parseInt(style2.width) - parseInt(style1.width);  
    extraHeight = parseInt(style2.height) - parseInt(style1.height);  
    var style = 
      document.defaultView.getComputedStyle(document.getElementById("Backside"), "");
    if (style && style.width != null && style.height != null) {
      backWidth = parseInt(style.width);  
      backHeight = parseInt(style.height);
    }          
    widget.onshow = apply;
    widget.onremove = clearPrefs;
    if (widget.context != null) {
      var link = document.getElementById("WidgetopUrl");
      if (link != null) {
        link.style.display = "none";
      }
    }
    if (gadget.startOnBackside) {
      showBack();
    }
  }  
}

function readPrefs() {
  if (gadget.params != null) {
    for (var i = 0; i < gadget.params.length; i++) {
      var value = widget.preferenceForKey(widget.identifier + "-" + gadget.params[i]);
      if (value != null) {
        var element = document.getElementById("Parameter_" + gadget.params[i]);
        if (element) {
          element.value = value;
        }    	
      }     	
    }
  }
}

function clearPrefs() {
  if (gadget.params != null) {
    for (var i = 0; i < gadget.params.length; i++) {
      widget.setPreferenceForKey(null, widget.identifier + "-" + gadget.params[i]);
    }
  }  
}
    
function parse() {
  if (!gadget.title) {
    gadget.title = getParameter("title");
  }
  else {
    setParameter("title", gadget.title);
  }
  if (gadget.hideTitle) {
    setParameter("title", "");    
  }
  if (getParameter("title").length == 0) {
    spaceHeight = 55;
  }
  else {
    spaceHeight = 70;
  }
  if (gadget.border != null) {
    setParameter("border", gadget.border);
  }
  if (gadget.width) {
    setParameter("w", gadget.width);
  }
  else {
    gadget.width = parseInt(getParameter("w", frontWidth - spaceWidth));
  }
  if (gadget.height) {
    setParameter("h", gadget.height);
  }
  else {
    gadget.height = parseInt(getParameter("h", frontHeight - spaceHeight));
  }
  gadget.url = getParameter("url");
  var link = document.getElementById("GadgetUrl");
  link.innerHTML = gadget.title;
  //link.href = "javascript: window.openURL(www.spiegel.de)";
  link.gadgetUrl = gadget.url;
  link.onclick = function() {
    widget.openURL("http://www.google.com/ig/directory?synd=open&url=" + this.gadgetUrl);
  }
  link.target = "_blank";
  if (gadget.params != null) {
    for (var i = 0; i < gadget.params.length; i++) {
      var element = document.getElementById("Parameter_" + gadget.params[i]);
      if (element) {
        element.value = getParameter("up_" + gadget.params[i]);
      }    	
    }
  }
  if (gadget.showRefresh && document.getElementById("Refresh") != null) {
    var refresh = document.getElementById("Refresh");
    if (refresh != null) {
      refresh.style.display = "block";
      refresh.onclick = apply;
    }  
  }
}

function getParameter(key, defaultValue) {
  var src = gadget.src;
  if (src.indexOf("&amp;") >= 0) {
    src = src.replace(/\&amp\;/g, "&");
  }
  var index = src.indexOf("&" + key + "=");
  if (index < 0) {
    index = src.indexOf("?" + key + "=");
  }
  if (index > 0) {
    var index2 = src.indexOf("&", index + 1);
    if (index2 >= 0) {
      return decode(src.substring(index + key.length + 2, index2));
    }
    return decode(src.substring(index + key.length + 2));
  }
  return defaultValue;   
}

function setParameter(key, value) {
  var src = gadget.src;
  if (src.indexOf("&amp;") >= 0) {
    src = src.replace(/\&amp\;/g, "&");
  }
  var index = src.indexOf(key + "=");
  if (index > 0) {
    var index2 = src.indexOf("&", index);
    if (index2 < 0) {
      index2 = src.length;
    }
    gadget.src = src.substring(0, index + key.length + 1) + encode(value) + src.substring(index2);    
  }
}

function decode(value) {
  var result = decodeURIComponent(value);
  return result.replace(/(\+)/g, " ");
}

function encode(value) {
  var result = encodeURIComponent(value);
  return result.replace(/(\s)/g, "+");  
}

function apply() {
  document.getElementById("Loading").style.display = "block";
  var element = document.getElementById("Gadget");
  var src = gadget.src;
  if (src.indexOf("&amp;") >= 0) {
    src = src.replace(/\&amp\;/g, "&");
  }
  element.gadgetSrc = src;
  element.onload = loaded;
  element.onerror = function() {
    alert("Loading inner.html failed.");
  }
  
  var date = new Date();
  element.src = "inner.html?" + date.getTime();
  element.width = gadget.width + spaceWidth;
  element.height = gadget.height + spaceHeight;
  frontWidth = gadget.width + spaceWidth + extraWidth;
  frontHeight = gadget.height + spaceHeight + extraHeight;
  if (!backShown) {
    window.resizeTo(frontWidth, frontHeight);
    if (gadget.autoRefresh) {
      autoRefreshId = setTimeout(apply, gadget.autoRefresh * 60000);
    }
  }
}

function loaded() {
  var element = this;
  var script = frames["Gadget"].document.getElementById("Code");
  if (script != null) {
    script.parentNode.removeChild(script);
  }
  script = frames["Gadget"].document.createElement("script");
  script.id = "Code";
  script.setAttribute("type", "text/javascript");
  script.setAttribute("src", element.gadgetSrc);
  frames["Gadget"].document.getElementsByTagName("head")[0].appendChild(script);
  document.getElementById("Loading").style.display = "none";
}

function updateParams() {
  var params = gadget.params;
  if (params != null && params.length > 0) { 
    for (var i = 0; i < params.length; i++) {
      var element = document.getElementById("Parameter_" + params[i]);
      if (element && element.value != null) {
        setParameter("up_" + params[i], element.value);
        widget.setPreferenceForKey(element.value, widget.identifier + "-" + gadget.params[i]);        
      }
    }
  }
}

function reload() {
  hideBack();
  apply();
}

function widgetSetup() {
  if (window.widget) {
  	var gReloadButton = new AppleGlassButton(document.getElementById("ReloadButton"), 
  	                                      "Reload", reload); 
  	var gDoneButton = new AppleGlassButton(document.getElementById("DoneButton"), 
  	                                      "Done", hideBack); 
	  var gInfoButton = new AppleInfoButton(document.getElementById("InfoButton"), 
	                                        document.getElementById("front"), 
	                                        "black", "black", showBack);
  }
}

function showBack() {
    var front = document.getElementById("front");
    var back = document.getElementById("back");
 
    if(window.widget)
        widget.prepareForTransition("ToBack");
 
    backShown = true;
    front.style.display="none";
    frontWidth = window.innerWidth;
    frontHeight = window.innerHeight;
    window.resizeTo(backWidth, backHeight);
    back.style.display="block";
 
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);  
}

function hideBack() {
    var front = document.getElementById("front");
    var back = document.getElementById("back");
 
    if (window.widget)
        widget.prepareForTransition("ToFront");
 
    backShown = false;
    back.style.display="none";
    window.resizeTo(frontWidth, frontHeight);  
    if (gadget.params != null && gadget.params.length > 0) {
      updateParams();
      apply();
    }
    front.style.display="block";
 
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}                                                
  