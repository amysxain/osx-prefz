var tim1;
var tim2;
var URLLink = "http://a.ltri.us";
var URLDonate = "https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=mike@cannellnet.com&item_name=Site%20Watch";
var URLAmazonWidget = "http://engine.a.ltri.us/widgets/amazonsearch/downloadurl.php";
var versionControl = parseFloat("1.2");
var URLversionControl = "http://engine.a.ltri.us/widgets/sitewatch/currver.txt";
var URLSiteWatch = "http://engine.a.ltri.us/widgets/sitewatch/downloadurl.php";

function load()
{
	setupParts();
	initSettings();
    checkForNewVersion(versionControl,URLversionControl);
	checkSite();	
}

function remove()
{
	// your widget has just been removed from the layer
	// remove any preferences as needed
    // widget.setPreferenceForKey(null, createInstancePreferenceKey("your-key"));
}

function hide()
{
	// your widget has just been hidden stop any timers to
	// prevent cpu usage
	if (monitorsRunning) {
		ioMonitor.stop();
		netMonitor.stop();
		monitorsRunning = false;
	}
}

function show()
{
	// your widget has just been shown.  restart any timers
	// and adjust your interface as needed
}

function showBack(event)
{
	// your widget needs to show the back

	var front = document.getElementById("front");
	var back = document.getElementById("back");

	if (window.widget)
		widget.prepareForTransition("ToBack");

	front.style.display="none";
	back.style.display="block";
	
	if (window.widget)
		setTimeout('widget.performTransition();', 0);
		
	document.getElementById("scrollArea").object.refresh();
}

function showFront(event)
{
	// your widget needs to show the front
	clearTimeout(tim2);
	document.getElementById("indicator").object.setValue(0);
	checkSite();
	saveBackValues();

	var front = document.getElementById("front");
	var back = document.getElementById("back");

	if (window.widget)
		widget.prepareForTransition("ToFront");

	front.style.display="block";
	back.style.display="none";
    
    setLabel(event);
	
	if (window.widget)
		setTimeout('widget.performTransition();', 0);
}

if (window.widget)
{
	widget.onremove = remove;
	widget.onhide = hide;
	widget.onshow = show;
}

function checkSite()
{
var url = document.getElementById("url").value;
var interval = document.getElementById("mins").value;

	if(url.length > 9 && interval != "" && isNaN(interval) == false){
		clearTimeout(tim1);
		fetchXMLData(url);
	}else{
		var tim1 = setTimeout('checkSite();',5000);
	}
}

function fetchXMLData(url)
{
	var xml_request = new XMLHttpRequest();
	xml_request.open("GET", url, true);
	
	xml_request.onreadystatechange = function()
	{
	document.getElementById("indicator").object.setValue(10);
		if(xml_request.readyState == 4){
				if(xml_request.status == 200){
					document.getElementById("indicator").object.setValue(1);
				}else{
					document.getElementById("indicator").object.setValue(20);
					var content = document.getElementById("scrollArea").object.content;
					var currText = content.innerHTML;
					content.innerHTML = currText + "Error:  -404 Site not found: " + Date() + "<br />";
					document.getElementById("scrollArea").object.refresh();
				}
			var intVal = (document.getElementById("mins").value*60000);	
			var tim2 = setTimeout('checkSite();',intVal);
		}
	}
	
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);	
}

function checkForNewVersion(ver,url)
{
	var xml_request = new XMLHttpRequest();
	xml_request.open("GET", url, true);
	
	xml_request.onreadystatechange = function()
	{
		if(xml_request.readyState == 4 && xml_request.status == 200){
				temp = parseFloat(xml_request.responseText);
                                
				if(ver < temp){
                	document.getElementById("img5").style.display="block";
					document.getElementById("glassbutton3").style.display="block";
					document.getElementById("glassbutton4").style.display="block";
					document.getElementById("text7").style.display="block";
				} else { 
                    resetVersionControl();
                }
		}
	}
	
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);
}

function resetVersionControl()
{
	document.getElementById("img5").style.display="none";
	document.getElementById("glassbutton3").style.display="none";
	document.getElementById("glassbutton4").style.display="none";
	document.getElementById("text7").style.display="none";
}


function goAmazon(event) 
{
	widget.openURL(URLAmazonWidget);
}


function checkNow(event) 
{
	clearTimeout(tim2);
	checkSite();
}


function openSite() 
{
	widget.openURL(URLLink);
}

function goDonate(event) 
{
	widget.openURL(URLDonate);
}

function saveBackValues()
{
	var del = ",";
	var text = document.getElementById("url").value+del;
	text += document.getElementById("mins").value+del;
    text += document.getElementById("textfield0").value;

	widget.system ("/bin/echo " + text + " > settings.txt",null);
}

function initSettings()
{
	var xml_request = new XMLHttpRequest();
	xml_request.open("GET", "settings.txt", true);
	
	xml_request.onreadystatechange = function()
	{
		if(xml_request.readyState == 4){	
			var initResults = xml_request.responseText;
            if(initResults != ""){
			var theValues = initResults.split(",");
			document.getElementById("url").value = theValues[0];
			document.getElementById("mins").value = theValues[1];
            document.getElementById("textfield0").value = theValues[2];
            document.getElementById("text0").innerText = theValues[2];
            }
		}
	}
	
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);
}


function setLabel(event)
{
    document.getElementById("text0").innerText = document.getElementById("textfield0").value;
}

function downloadNow()
{
    widget.openURL(URLSiteWatch);
	resetVersionControl();
}
