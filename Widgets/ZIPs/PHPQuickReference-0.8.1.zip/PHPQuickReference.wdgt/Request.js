/**
 *	PHPQuickReference Widget
 *
 *	© Claudio Procida 2005-2008
 *
 *	Disclaimer
 *
 *	The PHPQuickReference Widget software (from now, the "Software") and the accompanying materials
 *	are provided “AS IS” without warranty of any kind. IN NO EVENT SHALL THE AUTHOR(S) BE
 *	LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 *	INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN
 *	IF THE AUTHOR(S) HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. The entire risk as to
 *	the results and performance of this software is assumed by you. If the software is
 *	defective, you, and not the author, assume the entire cost of all necessary servicing,
 *	repairs and corrections. If you do not agree to these terms and conditions, you may not
 *	install or use this software.
 */
 
/**
 *	Variables
 */

var function_list;
var busy_loading = false;
var hint_index = -1;
var function_candidates;

/**
 *	Constants
 */

var REF_START = "class=\"refentry\">",
	REF_END = "</div><br /><br />",
	USR_START = "<small>User Contributed Notes</small><br />",
	USR_END = "<div class=\"foot\">",
	USR_PREFIX = "<div>",
	PHP_REF_URL = "http://www.php.net/",
	PHP_MANUAL_URL = PHP_REF_URL + "manual/",
	PHP_LOOKUP_URL = "http://www.php.net/quickref.php",
	FUNCTION_LIST_START = "<!-- result list start -->",
	FUNCTION_LIST_END = "<!-- result list end -->";

function sendRequest() {
	var url = PHP_REF_URL + getObj('q').value;

	xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function()
	{
		if (xmlhttp.readyState == 4) {
			var response = "";
			if (xmlhttp.status == 200) {
				if (responseIsValid(xmlhttp.responseText)) {
					response = parseResponse(xmlhttp.responseText);
					showResults(response);
				}
				else {
					error("Term not found.");
				}
			}
			else {
				error("No response from server.");
			}
		}
	}

	xmlhttp.open("GET", url, true);
	xmlhttp.send(null);
}

function parseResponse(text) {
	var reference, userNotes;
	
	reference = text.substring(text.indexOf(REF_START) + REF_START.length, text.indexOf(REF_END));
	
	reference = reference.replace(/href=".*function\.([a-z\-]+)\.php"/gi, 'href="javascript:linkedSearch(\'$1\')"'); // grab reference URLs
	reference = reference.replace(/href="(http:\/\/.*)"/gi, 'href="javascript:goToUrl(\'$1\')"'); // grab external URLs
	reference = reference.replace(/href="(.*\.php(#.+)?)"/gi, 'href="javascript:goToUrl(PHP_MANUAL_URL+\'$1\')"'); // grab internal URLs

	if (text.indexOf(USR_END) != -1) {
		userNotes = USR_PREFIX + text.substring(text.indexOf(USR_START) + USR_START.length, text.indexOf(USR_END));
	}
	else {
		userNotes = USR_START + '<div class="note">There are no user contributed notes for this function.</div>';
	}

	return [reference, userNotes];
}

function responseIsValid(text) {
	return (text) && (text.indexOf(REF_START) != -1) && (text.substring(text.indexOf(REF_START), text.indexOf(REF_END)).length > 0);
}

function refine(event) {
	switch (event.keyCode)
	{
		// Prevent event propagation (i.e. to Scroller) when using arrows in the search field
		case 37:
		case 38:
		case 39:
		case 40:
			event.stopPropagation();
	}

	if (!function_list)
	{
		// Load functions list
		if (busy_loading)
			// Wait until we are finished
			return;
		busy_loading = true;
		throbber.start();
		var url = PHP_LOOKUP_URL;

		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function()
		{
			if (xmlhttp.readyState == 4) {
				if (xmlhttp.status == 200) {
					var list = xmlhttp.responseText.substring(xmlhttp.responseText.indexOf(FUNCTION_LIST_START),
						xmlhttp.responseText.indexOf(FUNCTION_LIST_END));
					var i = 0;
					var pattern = />([^<]+)<\/a/gi;
					function_list = new Array();
					while ((result = pattern.exec(list)) != null)
						function_list[i++] = result[1];
					alert("Loaded " + function_list.length + " functions from PHP reference.");

					// Call another time to display results
					busy_loading = false;
					refine(event);

					throbber.stop();
				}
				else {
					error("No response from server.");
				}
			}
		};
		xmlhttp.open("GET", url, true);
		xmlhttp.send(null);
	}
	else
	{
		switch (event.keyCode)
		{
			// No operation when user digits ENTER, RETURN, DEL or CANC
			case 8:
			case 13:
			case 46:
				break;

			// TAB cycles thru alternatives
			case 9:
				if (!function_candidates ||
					hint_index != -1)
				{
					hint_index++;
					hint_index %= function_candidates.length;
					hint(getObj("q"), function_candidates[hint_index]);
					getObj("q").style.color = "green";
				}
				break;
				
			// Filter the functions list based on user input
			default:
				throbber.start();
				function_candidates = function_list.filter(new RegExp("^" + getObj("q").value, "i"));

				// reset index
				hint_index = 0;
				
				if (function_candidates.length < 1)
					getObj("q").style.color = "red";
				else
				{
					getObj("q").style.color = "";
/*
			var menu = null;
	
			if (window.widget)
				menu = widget.createMenu();
				
			for (var i = 0; i < function_candidates.length; i++)		
				menu.addMenuItem (function_candidates[i]);
	
			if (menu != null)
			{
				var selectedItem = menu.popup(40, 60);
				
				if (selectedItem >= 0)
				{
					alert(function_candidates[selectedItem]);
				}
			}
*/
				}
				try
				{
					if (function_candidates.length > 0)
					{
						var prefix = common_prefix(function_candidates);
						if (in_array(function_candidates, prefix))
							getObj("q").style.color = "green";
						hint(getObj("q"), prefix);
						hint_index = 0;
					}
				}
				catch (e)
				{
					alert("Exception: " + e);
				}

				//doSearch();
				throbber.stop();
		}
	}
}

Array.prototype.filter = function(regexp)
{
	var l = 0;
	var ret_arr = new Array();
	for (var i = 0; i < this.length; i++)
		if (this[i].match(regexp))
			ret_arr[l++] = this[i];
	return ret_arr;
};

function common_prefix(arr)
{
	var len = arr.length;
	if (len == 1)
		return arr[0];
	if (len == 2)
	{
		var min_len = Math.min(arr[0].length, arr[1].length);
		var prefix = "";
		for (var i = 0; i < min_len; i++)
		{
			if (arr[0].charAt(i) == arr[1].charAt(i))
			{
				prefix += arr[0].charAt(i);
			}
			else
			{
				break;
			}
		}
		return prefix;
	}
	var new_len = Math.ceil(len / 2);
	var new_arr = new Array(new_len);
	for (var i = 0; i < new_len; i++)
	{
		new_arr[i] = common_prefix(arr.slice(i * 2, (i + 1) * 2));
	}
	return common_prefix(new_arr);
}

function hint(obj, val)
{
	if (obj.selectionStart || obj.selectionStart == '0')
	{
		obj.value = val;
		obj.selectionStart = val.length;
	}
	else
	{
		obj.value = val;
	}
}

function in_array(arr, val)
{
	var len = arr.length;
	for (var i = 0; i < len; i++)
		if (arr[i] == val)
			return true;
	return false;
}