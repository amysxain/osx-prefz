/**
 *	PHPQuickReference Widget
 *
 *	© Claudio Procida 2005-2008
 *
 *	Disclaimer
 *
 *	The PHPQuickReference Widget software (from now, the "Software") and the accompanying materials
 *	are provided “AS IS” without warranty of any kind. IN NO EVENT SHALL THE AUTHOR(S) BE
 *	LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 *	INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN
 *	IF THE AUTHOR(S) HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. The entire risk as to
 *	the results and performance of this software is assumed by you. If the software is
 *	defective, you, and not the author, assume the entire cost of all necessary servicing,
 *	repairs and corrections. If you do not agree to these terms and conditions, you may not
 *	install or use this software.
 */
 
/**
 *	Variables
 */
 
var drawerTimer = null,
	throbber = null,
	flipShown = false,
	drawerShown = false,
	tabs = new Array(),
	activePanel = null,
	currentSize,
	animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null},
	scroll = {duration:0, starttime:0, to:0, now:-50, from:0, firstElement:null, timer:null};

/**
 *	Constants
 */

var DRAWER_STOP = 42,
	DRAWER_REST = -200,
	WIDGET_HOME = "http://www.emeraldion.it/software/widgets/phpquickreference.html";

/**
 *	Init function
 */
	
function setup() {
	if (window.widget) {
	    widget.onshow = onshow;
	    widget.onhide = onhide;
	}
	throbber = new Throbber();

	scrollerInit(getObj("myScrollBar"), getObj("myScrollTrack"), getObj("myScrollThumb"));
	
	createGenericButton(getObj("done"), getLocalizedString("Done"), hidePrefs);
	createGenericButton(getObj("donate"), getLocalizedString("Donate!"), donate);
	
	createTab(getObj("referencetab"), getLocalizedString("Reference"), alert);
	createTab(getObj("usernotestab"), getLocalizedString("User Notes"), alert);

	document.getElementById("version").innerHTML = "v" + window.getInfoDictionaryValueForKey("CFBundleVersion");
	
	window.resizeTo(288, 275);
	if (!window.widget)
		onshow();
		
	var checker = new VersionChecker();
	checker.didFetchLatestVersion = function(updateAvailable, item, version)
	{
		if (updateAvailable)
		{
			document.getElementById('update-available').style.display = 'block';
		}
	};
	checker.checkUpdate();
}

function createTab(tab, title, callback) {
	tabs[tabs.length] = tab;
	tab.innerHTML = '<div class="tab"><div class="tab-left"><div class="tab-right"><div class="tab-body">'+title+'</div></div></div></div>';
	tab.onclick = function (e) {
		for (var i = 0; i < tabs.length; i++) {
			var tabID = tabs[i].id,
				panelID = tabID.substring(0, tabID.indexOf("tab")),
				panel = getObj(panelID);
			if (tabs[i] == this) {
				tabs[i].childNodes[0].className = "tabdown";
				panel.style.display = "visible";
				activePanel = panel;
				calculateAndShowThumb(panel);
			}
			else {
				tabs[i].childNodes[0].className = "tab";
				panel.style.display = "none";
				
			}
		}
	};
}

/**
 *	Dashboard event handlers
 */

function onshow() {
}

function onhide() {
}

/**
 *	Preference handling functions
 */

function readPrefs() {
	if (window.widget) {
		//dummyProperty = widget.preferenceForKey("dummyProperty");
	}
}

function savePrefs() {
	if (window.widget) {
		//widget.setPreferenceForKey(dummyProperty, "dummyProperty");
	}
}

function showPrefs() {
	
//	hideDrawer();
	currentSize = getCurrentSize();
	if (currentSize && !currentSize.equalsTo({w:288, h:275}))
	{
		myResizeTo(288, 275);
		setTimeout(doShowPrefs, 1100);
	}
	else
	{
		doShowPrefs();
	}
}

function doShowPrefs()
{
	var front = getObj("front");
	var back = getObj("back");

	if (window.widget)
		widget.prepareForTransition("ToBack");
       
	front.style.display="none";
	back.style.display="block";

	if (window.widget)
		setTimeout ('widget.performTransition();', 0);
}

function hidePrefs() {
	
	var front = getObj("front");
	var back = getObj("back");

	if (window.widget)
		widget.prepareForTransition("ToFront");

	hidefliprollie();
	
	back.style.display="none";
	front.style.display="block";

	if (window.widget)
		setTimeout ('widget.performTransition();', 0);
		
	if (currentSize && !currentSize.equalsTo(getCurrentSize()))
		setTimeout(myResizeTo, 1100, currentSize.w, currentSize.h);
}

/**
 *	Internationalization support
 */

function getLocalizedString (key) {
	try {
		var ret = localizedStrings[key];
		if (ret === undefined)
			ret = key;
		return ret;
	}
	catch (ex) {
	}
	return key;
}

/**
 *	Interface boundary handlers
 */
 
function doSearch() { // form submit action
	throbber.start();
	hideDrawer();
	sendRequest();
}

function linkedSearch(term) { // form submit action
	hideDrawer();
	getObj("dqform").q.value = term;
	getObj("dqform").submit();
}

function doReset() { // resets search form
	getObj("dqform").reset();
	throbber.stop();
	hideDrawer();
}

function donate() { // redirect to PayPal
	goToUrl("http://www.emeraldion.it/software/widgets/phpquickreference/donate");
}


/**
 *	Visual FX functions
 */
 
/**
 *	Someday I'll rewrite from scratch all this messy spaghetti-code :(
 *
 */

function selectTab(tab) {
	for (var i = 0; i < tabs.length; i++) {
		var tabID = tabs[i].id,
			panelID = tabID.substring(0, tabID.indexOf("tab")),
			panel = getObj(panelID);
		if (tabs[i] == tab) {
			tabs[i].childNodes[0].className = "tabdown";
			panel.style.display = "visible";
			activePanel = panel;
			calculateAndShowThumb(panel);
		}
		else {
			tabs[i].childNodes[0].className = "tab";
			panel.style.display = "none";				
		}
	}
}

function showfliprollie() { // convenience method
	showObj("fliprollie");
}

function hidefliprollie() { // convenience method
	hideObj("fliprollie");
}

function showDrawer() {	// brings the drawer down
	if (!drawerShown) {
		showObj("drawer");
		calculateAndShowThumb(getObj("reference"));
		if (scroll.timer != null) {
			clearInterval (scroll.timer);
			scroll.timer  = null;
		}
		toggleTop(); 
		var starttime = (new Date).getTime() - 13;
 
		scroll.duration = 500;
		scroll.starttime = starttime;
		scroll.firstElement = getObj("drawer");
		scroll.timer = setInterval ("smoothScroll();", 13);
		scroll.from = scroll.now;
		scroll.to = DRAWER_STOP;
		smoothScroll();
		drawerShown = true;
	}
}

function hideDrawer() { // dismisses the drawer
	if (drawerShown) {
		clearTimer(drawerTimer);
		if (scroll.timer != null) {
			clearInterval (scroll.timer);
			scroll.timer  = null;
		}

		var starttime = (new Date).getTime() - 13;

		scroll.duration = 500;
		scroll.starttime = starttime;
		scroll.firstElement = getObj("drawer");
		scroll.timer = setInterval ("smoothScroll();", 13);
		scroll.from = scroll.now;
		scroll.to = -getObj("drawer").offsetHeight;
		smoothScroll();
		drawerShown = false;
	}
}

function smoothScroll() { // visualizes a scrolling animation
	var T;
	var ease;
	var time = (new Date).getTime();
   

	T = clampTo(time-scroll.starttime, 0, scroll.duration);
	if (T >= scroll.duration) {
		clearInterval (scroll.timer);
		scroll.timer = null;
		scroll.now = scroll.to;
		if (!drawerShown)
			toggleTop();

	}
	else {
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / scroll.duration));
		scroll.now = computeNextFloat (scroll.from, scroll.to, ease);
	}
	
	with (scroll.firstElement.style) {
		top = scroll.now + 'px';
		clip = 'rect(' + clampTo(DRAWER_STOP-scroll.now, 0, DRAWER_STOP-scroll.now) + 'px auto auto auto)'; //clip drawer to hide behind front
	}
}

function animate() { // shows a glowing effect
	var T;
	var ease;
	var time = (new Date).getTime();
   

	T = clampTo(time-animation.starttime, 0, animation.duration);

	if (T >= animation.duration) {
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	}
	else {
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}

	animation.firstElement.style.opacity = animation.now;
}

/**
 *	Interface event handlers
 */

function mousescroll(event) {
	scrollBy(window.event.wheelDelta / 20);
}

function mousemove (event) {
	if (!flipShown) {
		if (animation.timer != null) {
			clearInterval (animation.timer);
			animation.timer  = null;
		}
 
		var starttime = (new Date).getTime() - 13;
 
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ("flip");
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 1.0;
		animate();
		flipShown = true;
	}
}

function mouseexit (event) {
	if (flipShown) {
		// fade in the info button
		if (animation.timer != null) {
			clearInterval (animation.timer);
			animation.timer  = null;
		}

		var starttime = (new Date).getTime() - 13;

		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ("flip");
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}

function enterflip(event) {
	showfliprollie();
}

function exitflip(event) {
	hidefliprollie();
}

/**
 *	Notification and visualization functions
 */

function showResults(response) {
	getObj("reference").style.top = 0; // scroll to top
	getObj("reference").innerHTML = '<div class="result">' + response[0] + '</div>';
	getObj("drawer").style.display = 'block'; // necessary to calculate thumb
	calculateAndShowThumb(getObj("reference"));

	getObj("usernotes").style.top = 0; // scroll to top
	getObj("usernotes").innerHTML = '<div class="result">' + response[1] + '</div>';

	selectTab(getObj("referencetab"));
	throbber.stop();
	showDrawer(); // show with an animation
}

function error(message) {
	hideDrawer();
	getObj("reference").innerHTML = '<div class="error-outer"><div class="error-inner"><div class="error"><img id="error-mark" src="img/error.png" />'+message+'</div></div></div>';
	calculateAndShowThumb(getObj("reference"));
	throbber.stop();
	showDrawer();
	if (drawerTimer)
		clearTimeout(drawerTimer);
	var timetoread = message.split(" ").length * 500 + 1000; // 1 second + 5/10th for every word
	drawerTimer = setTimeout('hideDrawer()', timetoread);
}

/**
 *	Miscellaneous utilities
 */
 
function getObj(id) { // retrieves an element
	return document.getElementById(id);
}

function showObj(id) { // shows an element
	getObj(id).style.display = 'block';
}

function hideObj(id) { // hides an element
	getObj(id).style.display = 'none';
}

function responseString() { // provides a toString method for responses
	var str = '';
	if (this.date)
		str += '<div style="float: left">' + strftime(this.date) + '</div>';
	if (this.place)
		str += '<div style="float: right">' + this.place + '</div>';
	str += '<br style="clear: both" />' + this.text;
	return str;
}

function toggleTop() {
	with (getObj('top')) {
		className = className == 'closed' ? 'open' : 'closed';
	}
}

function goToUrl(url) { // opens a URL
	if (window.widget) {
		widget.openURL(url);
	}
	else {
		window.open(url);
	}
}

function clampTo(value, min, max) { // constrains a value between two limits
	return value < min ? min : value > max ? max : value;
}

function computeNextFloat (from, to, ease) { // self explaining
	return from + (to - from) * ease;
}

var resizeAnimation = {startW: 0, startH: 0, endW: 0, endH: 0, duration: 1000, timer: null, starttime: null};
function myResizeTo(w, h)
{
	resizeAnimation.startW = window.outerWidth;
	resizeAnimation.startH = window.outerHeight;

	resizeAnimation.endW = w
	resizeAnimation.endH = h;
	
	resizeAnimation.starttime = new Date().getTime();
	
	resizeAnimation.timer = setInterval(myResizing, 63);
}

function myResizing()
{
	var now = new Date().getTime();
	var w = resizeAnimation.startW + Math.round( (resizeAnimation.endW - resizeAnimation.startW) * (now - resizeAnimation.starttime) / resizeAnimation.duration);
	var h = resizeAnimation.startH + Math.round( (resizeAnimation.endH - resizeAnimation.startH) * (now - resizeAnimation.starttime) / resizeAnimation.duration);
	var deltaY = h - window.outerHeight;
	if (now - resizeAnimation.starttime >= resizeAnimation.duration)
	{
		clearInterval(resizeAnimation.timer);
		w = resizeAnimation.endW;
		h = resizeAnimation.endH;
		deltaY = h - window.outerHeight;
		
		calculateAndShowThumb(activePanel);
	}
	window.resizeTo(w, h);
	with (getObj("content")) {	// resizes the container
		style.height = offsetHeight - 1 + deltaY + "px";
	}
	with (getObj("drawer-left")) {	// resizes the container
		style.height = offsetHeight + deltaY + "px";
	}
	with (getObj("myScrollBar")) {	// resizes the scrollbar
		style.height = offsetHeight + deltaY + "px";
	}
}

function getCurrentSize()
{
	return {w:window.outerWidth, h:window.outerHeight, equalsTo: function(oth) { return this.w == oth.w && this.h == oth.h; }};
}

// Someday I have to thoroughly comment this ugly mess out :)