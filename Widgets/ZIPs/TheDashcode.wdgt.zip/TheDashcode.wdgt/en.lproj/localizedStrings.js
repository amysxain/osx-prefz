var localizedStrings = new Object;

localizedStrings["My RSS Feed"] = "My RSS Feed";
localizedStrings["New URL: "] = "New URL: ";
localizedStrings["Set"] = "Set";
localizedStrings["Feed URLs: "] = "Feed URLs: ";
localizedStrings["Article Length"] = "Article Length";
localizedStrings["Reset"] = "Reset";
localizedStrings["Done"] = 'Back';
localizedStrings["Invalid Feed"] = "Invalid Feed";
localizedStrings["%s does not appear to be a valid RSS or Atom feed."] = "%s does not appear to be a valid RSS or Atom feed.";
localizedStrings["No Items Found"] = "No Items Found";
localizedStrings["The feed does not contain any entries."] = "The feed does not contain any entries.";
localizedStrings["No items matched the search terms."] = "No items matched the search terms.";
localizedStrings["Nothing To Display"] = "Nothing To Display";
localizedStrings["The feed does not contain any entries within the specified criteria."] = "The feed does not contain any entries within the specified criteria.";
localizedStrings["Loading"] = '.....';
localizedStrings["%s new"] = "%s new";
