// Javascript
// Created by Eric Clemmons
// For use by MidAtlanticInc.com
// Copyright 2005
var currentVer = "2.5.1";
var latestVer = "0";
var version;
var updateInterval = 2800;

if(window.widget) widget.onshow = checkVersion;

function setup() {
	var stamp = new Date();
    // preparePrefs();
	if(window.widget) widget.setPreferenceForKey( Math.round(stamp.getTime() / 1000), "timeStamp");

	window.resizeTo(425,228);
	
	step_two();
	// open up widget on startup.
	
	get_version();
	updateIcons();
}

function alertbox(msg) {
	//alert("Message (msg) = '"+msg+"'.");
	if(msg == null) msg = "<b>The Internet cannot be found!</b>  This widget requires an active internet connection to work successfully.<br /><br />";
	e = document.getElementById('alert_box_text');

	e.innerHTML = msg + "<button type=\"button\" value=\"Close\" onclick=\"close_alert_box();\" style=\"width: 75px;\">Close</button>";

	document.getElementById('alert_box').style.display = "block";

	/* in the event that they're not confirmed subscribers, they're limited */
	if((msg.indexOf("double-checking") > -1) || (msg.indexOf("not activated")>-1)) {
		document.prefs.existingClient.checked = false;
		existingClient = document.prefs.existingClient.value;
		widget.setPreferenceForKey(existingClient, "existingClient");
		updateIcons();
	}

}

function close_alert_box() {
	document.getElementById("alert_box").style.display = "none";
}

function updateIcons() {
		var existingClient = getPref("existingClient");
		document.getElementById("subsMail").src = "images/mail_on.png";
		if(existingClient) {
			document.getElementById("subsText").innerHTML = " E-mail, Chat and Phone support available.";
			document.getElementById("subsChat").src = "images/chat_on.png";
			document.getElementById("subsPhone").src = "images/phone_on.png";
		} else {
			document.getElementById("subsText").innerHTML = "<a href='mailto:info@midatlanticconsulting.com'>E-mail</a> support available for free.";
			document.getElementById("subsChat").src = "images/chat_off.png";
			document.getElementById("subsPhone").src = "images/phone_off.png";
		}
}

function checkVersion() {
	var stamp = new Date();
	lastTimeStamp = widget.preferenceForKey("timeStamp");
	dateNow = new Date();
	dateNow = Math.round(dateNow.getTime() / 1000);
  if(lastTimeStamp) {
  	var difference =dateNow - lastTimeStamp;
  	var diffMinutes = difference/60;
  	var diffHours = Math.round(diffMinutes/60);
	  if(diffMinutes >= updateInterval) {
	  	alert("Time for an update!");
	  	widget.setPreferenceForKey( Math.round(stamp.getTime() / 1000), "timeStamp");
	  	get_version();
	  }
	  else {
	  	alert("Last checked for update "  + diffMinutes + " minutes ago.");
	  }
  }
}

function get_version() {
        jQuery.ajax({
            url: 'http://www.versiontracker.com/dyn/moreinfo/macosx/27902',
            success: function(html) {
                var latestVersion = jQuery('table.prod-info-box-table td:eq(5)', html).text();
                if (currentVer != latestVersion) {
                    var msg = "<strong>Update Available!</strong> <button value=\"Click here\" onclick=\"widget.openURL('http://www.midatlanticconsulting.com/downloads.php');\">Update to v" + latestVersion + "</button>";
    				alertbox(msg);
                }
            }
        });
}

function subscribe() {
	if(isFormComplete()) {
		//saveClient();
		//mailCassie();
		widget.setPreferenceForKey(document.prefs.existingClient.value, "existingClient");
			var url = "https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&no_shipping=1&item_name=MacHelp for " + getPref("fname") + " " + getPref("lname") + "(" + getPref("email") + ")" + "&business=maccassie@mac.com&amount=";
			var cash;
			for(i = 0; i < 3; i++)
				if(document.payment.amount[i].checked) cash = document.payment.amount[i].value;
			url+=cash + "&";
		widget.openURL(url);
		//showPayment();
	} else
		document.getElementById("current_user").innerHTML = "<em>***</em>PLEASE COMPLETE THE REQUIRED FIELDS<em>***</em>";
}

function logIn() {
	var newUser;
	if(!getPref("fname")) var newUser = true; else newUser = false;

	if(newUser) {
		if(isFormComplete()) {
			alert("Form completed. Trying to log in...");
            // saveClient();
			//mailCassie();
		}
		else {
			alert("Form incomplete. Can't log in!");
			document.getElementById("current_user").innerHTML = "<em>***</em>PLEASE COMPLETE THE REQUIRED FIELDS<em>***</em>";
		}
	} else {
		alert("Pre-existing login, saving preferences...");
        // saveClient();
	}
}

var req;
function mailCassie() {
	var requestURL = "http://www.epicsitedesigns.com/mail?";
	var message = "Name: " + getPref('fname') + " " + getPref('lname') + " <" + getPref('email') + ">" + 
						 "\nPhone Number: " + getPref('phone') + 
						 "\nCompany Name: " + getPref('cname') +
						 "\nAddress:\n\t" + getPref('address1') + "\n\t" + getPref('city') + ", " + document.prefs.state.options[parseInt(getPref('state1'))].value + " " + getPref('zip');
	var stringURL = "to=maccassie@mac.com&from=widget-login@midatlanticconsulting.com&subject=[MacHelp] New User: " + getPref("fname") + " " + getPref("lname") + "&message=" + message + "&p=ep!c&";

	req = new XMLHttpRequest();
	req.onreadystatechange = cassieSent;
	req.open("POST", requestURL+stringURL, false);
	req.send("");
}

function cassieSent() {
	if(req.readyState == 4 && req.status >= 200) {
		if(req.responseText == "success") saveClient();
		else {
			document.getElementById("current_user").innerHTML = "<em>***</em>COULD NOT LOGIN! CHECK CONNECTION OR TRY AGAIN<em>***</em>";
		}
	}
}

function checkLatestVersion() {
	
	if (!version) {
		version = new XMLHttpRequest();
		version.onreadystatechange = checkLatestVersion;
		version.open("GET","http://www.epicsitedesigns.com/widget/ver/MacHelp.ver", false);
		version.send(null);
	} else {
		if(version.readyState == "4") {
			latestVer = version.responseText;
			alert("Latest Version: " + latestVer);
			version.readyState = "0";
			version = null;
			if((latestVer != currentVer) && (latestVer != null)) {
				alert("Current Version: " + currentVer);
				document.getElementById("update").style.opacity = 1;
			}
		}
	}
}

//changeBackground: <img> sends "this" and if it should be
//	highlighted or not (boolean).  Image names must be:
//	"titlebar_off.png" or "titlebar_on.png"
function changeBackground(subject, enabled) {
	var imageSrc = subject.src;
	var toggleLoc = imageSrc.indexOf("on.png");
	if (toggleLoc < 0) toggleLoc=imageSrc.indexOf("off.png");
	if (enabled) 
		var overSrc = imageSrc.substring(0, toggleLoc) + "on.png";
	else
		var overSrc = imageSrc.substring(0, toggleLoc) + "off.png";

	subject.src = overSrc;
}

function toggle(disable, enable) {
	if(disable.style.display != "none") {
		disable.style.display = "none";
		enable.style.display = "block";
	} else {
		disable.style.display = "block";
		enable.style.display = "none";
	}
}

var progFrame = 1;
var progMin = 1;
var progMax = 12;
function startProg() {
	timer = setInterval("spinProg();", 50);
}
function spinProg() {
	newProg = "images/spinner/prog" + progFrame + ".png";
	progFrame++;
	if(progFrame > progMax) progFrame = progMin;
	changeProg(newProg);
}
function stopProg() {
	clearInterval(timer);
	progFrame = 1;
}

function changeProg(newSrc) {
	document.getElementById("spinner").src = newSrc;
}

// Content Stretching functions
//                          //

			var stretcher;
			var stepEnabled = true;
			var lastStep = 2;

function stretchTo(stepNo, event) {
				var step0height = 10;
				var step1height = 175;//112;
				var step2height = 145;//145;//150;
				var step3height = 314;//284;
				var inc = 20;
				
				stepEnabled = !stepEnabled;
				if(lastStep + 1 == stepNo) stepEnabled = !stepEnabled;
				if(stepNo >= 2) stepEnabled = true;
				
				if(stepNo == 0) inc = step0height;
				if(stepNo == 1) inc = stepEnabled ? step1height : 20;
				if(stepNo == 2) inc = stepEnabled ? step2height : step1height;
				if(stepNo == 3) inc = stepEnabled ? step3height : step2height;
				var mainElt = document.getElementById('mid');
				
                alert(inc);
                

				toggle(document.getElementById('titlebar_d_arrow'),document.getElementById('titlebar_f_arrow')); 
				step = new Stretcher(mainElt, null, inc);
				step.stretch(event);
				lastStep = stepNo;
			}
			
			function overTitle () {
				mousemove(document.getElementById('infobar'), null);
			}
			function outTitle () {
				mouseexit(document.getElementById('infobar'), event);
			}



function getPref(attr) {
	return widget.preferenceForKey(attr);
}
function setPref(attrValue, attr) {
	widget.setPreferenceForKey(attrValue, attr);
	return null;
}

function showPrefs()
{
	//Adjust the prefs accordingly based on already knowing user info
    // preparePrefs();

	var front = document.getElementById("front");
	var back = document.getElementById("back");

	if (window.widget)
		widget.prepareForTransition("ToBack");
       
	front.style.display="none";
	back.style.display="block";
	exitflip(event);

	if (window.widget) {
		setTimeout ('widget.performTransition();', 100); 
	}
}

function showRegistration()
{
    window.resizeTo(425,650);
    
    showPrefs();
    document.getElementById('current_user').style.display = 'none';
    document.getElementById('new_user').style.display = 'block';
    document.getElementById("details_container").style.height="510px";
}

function showLogin()
{
    window.resizeTo(425, 230);
    document.getElementById("details_container").style.height="110px";
    showPrefs();
    document.getElementById('current_user').style.display = 'block';
    document.getElementById('new_user').style.display = 'none';
    
    jQuery("#current_user input")[0].focus();
    
    jQuery('#current_user form').submit(function(e) {
        e.preventDefault();
        
        if (jQuery('#passcode').val() == '1ph0n3') {
            widget.setPreferenceForKey(true, "existingClient");
            hidePrefs();
        } else {
            jQuery(this).addClass('error');
        }
    });
}

function hidePrefs()
{
	updateIcons();
	var front = document.getElementById("front");
	var back = document.getElementById("back");

	//save techname & salesname
    // setPref(document.prefs.techname.options.selectedIndex, "techname");
    // setPref(document.prefs.salesname.options.selectedIndex, "salesname");

	if (window.widget)
		widget.prepareForTransition("ToFront");
      
	back.style.display="none";
	front.style.display="block";
    document.getElementById("details_container").style.height = "90px";
	
	step_two();

	if (window.widget)
		setTimeout ('widget.performTransition();', 0);
}

function preparePrefs() {
	//current_user is the <div> that we write in.
	current_user = document.getElementById("current_user");
	fname = getPref("fname");
	if(!fname) {
		current_user.innerHTML = "You are not logged in.  Please complete the following:";
		document.getElementById("details_container").style.height="250px";
	} else {
		current_user.innerHTML = "You are logged in as <em>" + fname + " " + getPref("lname") + "</em>. &nbsp;( <a href='#' onclick='showPayment();'>change login...</a> )";
		document.prefs.fname.value = fname;
		document.prefs.lname.value = getPref("lname");
		document.prefs.cname.value = getPref("cname");
		document.prefs.address1.value = getPref("address1");
		document.prefs.city.value = getPref("city");
		document.prefs.state.options[parseInt(getPref("state1"))].selected = true;
		document.prefs.zip.value = getPref("zip");
		document.prefs.email.value = getPref("email");
		document.prefs.phone.value = getPref("phone");
		if(getPref("existingClient")) document.prefs.existingClient.checked = "checked";
			//step_three(0);

	}

	techname = getPref("techname");
	salesname = getPref("salesname");
	if(techname) document.prefs.techname.options[parseInt(techname)].selected = true;
	if(salesname)	document.prefs.salesname.options[parseInt(salesname)].selected = true;
	
}

function saveClient() {	
	fname = document.prefs.fname.value;
	lname = document.prefs.lname.value;
	cname = document.prefs.cname.value;
	address1 = document.prefs.address1.value;
	city = document.prefs.city.value;
	state = document.prefs.state.options.selectedIndex;
	zip = document.prefs.zip.value;
	email = document.prefs.email.value;
	phone = document.prefs.phone.value;
	existingClient = document.prefs.existingClient.value;
	if(existingClient == "on") var subscriber = 1; else var subscriber = 0;
	if(isFormComplete) {
		widget.setPreferenceForKey(fname, "fname");
		widget.setPreferenceForKey(lname, "lname");
		widget.setPreferenceForKey(cname, "cname");
		widget.setPreferenceForKey(address1, "address1");
		widget.setPreferenceForKey(city, "city");
		widget.setPreferenceForKey(state, "state1");
		widget.setPreferenceForKey(zip, "zip");
		widget.setPreferenceForKey(email, "email");
		widget.setPreferenceForKey(phone, "phone");
		widget.setPreferenceForKey(existingClient, "existingClient");

			document.getElementById("step_two").innerHTML = "<center><span class='heading'>Q</span><span class='default'>: Is this a <a href='#' onclick='javascript: step_three(1);'>sales</a> or <a href='#' onclick='javascript: step_three(2);'>support</a> request?</span></center>";
			
		updateIcons();

		state = document.prefs.state.options[parseInt(getPref('state1'))].value;
		
		var url = "http://www.epicsitedesigns.com/sites/machelp/?action=login&fname="+
							fname+"&lname="+lname+"&company="+cname+"&address="+
							address1+"&city="+city+"&zipcode="+zip+"&email="+email+
							"&phone="+phone+"&state="+state+"&subscriber="+subscriber+"&";
		alert(url);
		//widget.openURL(url);

		alertbox("Logging in...<br />");

		var xml_request = new XMLHttpRequest();
		xml_request.onload = function(e) { 
			var msg = xml_request.responseText;
			alertbox(msg);
			hidePrefs();
		}
		xml_request.overrideMimeType("text/xml");
		xml_request.open("GET", url,true);
		xml_request.setRequestHeader("Cache-Control", "no-cache");
		xml_request.setRequestHeader("wx", "385");
		xml_request.send(null);
	} else {
		document.getElementById("current_user").innerHTML = "<em>***</em>PLEASE COMPLETE THE REQUIRED FIELDS<em>***</em>";
		return false;
	}
}

function isFormComplete() {
	fname = document.prefs.fname.value;
	lname = document.prefs.lname.value;
	cname = document.prefs.cname.value;
	address1 = document.prefs.address1.value;
	city = document.prefs.city.value;
	state = document.prefs.state.options.selectedIndex;
	zip = document.prefs.zip.value;
	email = document.prefs.email.value;
	phone = document.prefs.phone.value;
	existingClient = document.prefs.existingClient.value;
	if(fname && lname && address1 && city && state && zip && (email.indexOf("@") > 0))
		return 1;
	else return 0;
}

var backStretch;
function stretchBack() {
	stepBack = new Stretcher(document.getElementById("details_container"), null, 217);
	stepBack.stretch(event);
}
var stepPayment;
function showPayment() {
	var newHeight;
	if(document.prefs.existingClient.value == "on") newHeight = 217; else newHeight = 250;
	stepPayment = new Stretcher(document.getElementById("details_container"), null, newHeight);
	stepPayment.stretch(event);
}

//step_two tells the user to login if they're not already.
//otherwise, it'll ask if it's a Sales or Support request.
function step_two() {
	steptwo = document.getElementById("step_two");
	if(getPref('existingClient')) {
	    jQuery('#mid').css('height', 175);
        window.resizeTo(425, 200);
        
	    jQuery('#contact .detail em').css('display', 'none');
        
	    jQuery.ajax({
	        url: "http://www.midatlanticconsulting.com/staff/employeelist.tdf",
	        success: function(tdf) {
	            var html = "<center><select onChange='javascript:contact(this);'>\n";
	            
	            var lines = tdf.split("\n");
	            
	            for (var i in lines) {
	                if (i == 0) {
                        html = html + "<option value=''>Select Tech Assigned To You...</option>";
                        html += "<option value='Send an <img id=\"subsMail\" src=\"images/mail_on.png\" width=\"20\" height=\"20\" /><a href=\"mailto:info@midatlanticconsulting.com\">E-mail</a>'\"'>(None)</option>";
	                    continue;
	                }
                    var line = lines[i];
                    
                    var fields = line.split("\t");
                    var value = 'Send an <img id="subsMail" src="images/mail_on.png" width="20" height="20" /><a href="mailto:' + fields[4] + '">E-mail</a>';
                    if (fields[5].length > 1) {
                        value += ', <img id="subsChat" src="images/chat_on.png" width="20" height="20" /><a href="aim:goim?screenname=' + fields[5] + '&message=Hi ' + fields[0] + '">IM</a>';
                    }
                    value += ' or call <img id="subsPhone" src="images/phone_on.png" width="20" height="20" /><em>(703) 644-5565 x' + fields[3] + "</em>.";
                    html = html + "<option value='" + value + "'>" + fields[0] + ": " + fields[1] + "</option>\n";
	            }
	            
                html = html + "</center></select>";
                
                steptwo.innerHTML = html;
                
                var selectedTech = widget.preferenceForKey('selectedTech');
                if (selectedTech) {
                    var select = jQuery('select', steptwo);
                    select.attr('selectedIndex', selectedTech);
                    contact(select[0]);
                }

                
                
                // jQuery('#contact').css('top', -9).html();
                
	        }
	    });
    } else {
        // steptwo.innerHTML = "<center>Please <a href='#' onclick='showPrefs();'>login</a> to complete an online request.</center>";
        document.getElementById('subsOptions').style.display = 'none';
        jQuery('#mid').css('height', 200);
        
        steptwo.innerHTML = "<center>Are you a <a href='#' onclick='showRegistration();'>New User</a> or an <a href='#' onclick='showLogin();'>Existing User?</a></center>";
		changeBackground(document.getElementById("subsMail", false));
		changeBackground(document.getElementById("subsChat", false));
		changeBackground(document.getElementById("subsPhone", false));

		}
}

function contact(select) {
    widget.setPreferenceForKey(select.selectedIndex, "selectedTech");
    
    jQuery('#contact').css('top', -9).html(select.options[select.selectedIndex].value);
    jQuery('#contact a').each(function() {
        jQuery(this).attr('href', 'javascript:widget.openURL("' + this.href + '");');
    });
    stretchTo(2, event);
}

//1 = sales, 2 = support
var requestType;
function step_three(choice) {
	if(choice == 1) requestType = "Sales";
	if(choice == 2) requestType = "Support";
	inner = document.getElementById("step_three");
	techname = getPref("techname");
	techtext = "<center>Your tech contact is <em>" + document.prefs.techname[parseInt(techname)].text + "</em>. (<a href='#' onclick='showPrefs();'>Change contact</a>)</center>";
	salesname = getPref("salesname");
	salestext = "<center>Your sales contact is <em>" + document.prefs.salesname[parseInt(salesname)].text + "</em>. (<a href='#' onclick='showPrefs();'>Change contact</a>)</center>";
	if(choice == 1) inner.innerHTML = salestext
	if(choice == 2) inner.innerHTML = techtext;
	
	if(choice > 0) { 
		document.getElementById("connection_text").innerHTML = "<em>Checking Connection...</em>";

		stretchTo(2, event);
		startProg(); 
		mousemove(document.getElementById('spinner'), event);
		//setTimeout(checkConnection, 2000);
				var xml_request = new XMLHttpRequest();
				xml_request.onload = function(e) { 
					var msg = xml_request.responseText;
					isInternet(msg);
				}
				xml_request.overrideMimeType("text/xml");
				xml_request.open("GET", "http://big.oscar.aol.com/MacHlpWdgt?on_url=http://www.epicsitedesigns.com/true.txt&off_url=http://www.epicsitedesigns.com/false.txt",true);
				xml_request.setRequestHeader("Cache-Control", "no-cache");
				xml_request.setRequestHeader("wx", "385");
				xml_request.send(null);		
	}
}

function isInternet(isThere) {
		alert("Got response: " + isThere);
		mouseexit(document.getElementById('spinner'), event);
		//document.getElementById("spinner").style.opacity = "0";
		
		var cText = isThere;
		var eClient = getPref('existingClient');

		if((isThere == "true") && (eClient == "on"))
			var cText = "Send request via <a href='#' onclick='stretchTo(3, event);'>E-Mail</a> or <a href='#' onClick='javascript: iChat();'>Chat</a>?";
		if((isThere == "false") || (eClient != "on")) {
			var cText = "Send request via <em>E-Mail</em>:";
			//stretchTo(3, event);
		}
		if(isThere == null) {
			var cText = "<b>Connection Missing</b>:  Please call <em>24/7 IT Support Line</em>.";
			stretchTo(2,event);
		} else { stretchTo(3,event); }
		document.getElementById("connection_text").innerHTML = cText;
		stopProg();

}
var req = false;
function checkConnection() {
	buddyName = "MacHlpWdgt";
	var requestURL  = "http://big.oscar.aol.com/"+buddyName+"?on_url=http://www.epicsitedesigns.com/true.txt&off_url=http://www.epicsitedesigns.com/false.txt";
		req = new XMLHttpRequest();
		req.onreadystatechange = AIMReqChange;
		req.open("GET", requestURL, false);
		//req.setRequestHeader("Cache-Control", "no-cache");
		req.send("");
}

function AIMReqChange() {
	//alert(req.responseText);
	if(req.readyState == 4 && req.status >= 200)
		setTimeout(isInternet(req.responseText), 1000);
}

function iChat() {
		var techField = document.prefs.techname.options[parseInt(getPref('techname'))];
	var salesField = document.prefs.salesname.options[parseInt(getPref('salesname'))];
	var techTo = techField.text + " <" + techField.value + ">";
	var salesTo = salesField.text + " <" + salesField.value + ">";

	var message = "Name: " + getPref('fname') + " " + getPref('lname') + " <" + getPref('email') + ">" + 
						 "\nPhone Number: " + getPref('phone') + 
						 "\nCompany Name: " + getPref('cname') +
						 "\nAddress:\n\t" + getPref('address1') + "\n\t" + getPref('city') + ", " + document.prefs.state.options[parseInt(getPref('state1'))].value + " " + getPref('zip') +
						 "\nTech contact: " + techTo + 
						 "\nSales contact: " + salesTo + 
						 "\nRequest type: " + requestType;// +
						 //"\nRequest Description: \n\t" + document.request.request.value;
		var openAS = "tell application \"iChat\"\n\tactivate\n\tdelay 5\n\tsend \"" + message + "\" to account \"MacHlpWdgt\"\nend tell";
		//var openAS = "tell application \"iChat\"\n\tactivate\n\tdelay 1\n\tend tell";
		//var AS = widget.system("/usr/bin/osascript -e '" + openAS + "'" , null).status;

		document.getElementById("connection_text").innerHTML =  "Complete request in your <em>chat</em> program... (<a href='#' onclick='iChat();'>Retry</a>)";

				
		widget.openURL("aim:goim?screenname=MacHlpWdgt&message=< Press [ENTER] to begin chat > (Begin Client Info: ) " + message);
}

function eraseRequestText() {
	if(document.request.request.value == "Please complete your request in detail...")
		document.request.request.value = "";

	document.getElementById("request").style.color = "#000";
	document.getElementById("request").style.fontStyle = "normal";
}

function sendRequest() {
	fname = document.prefs.fname.value;
	lname = document.prefs.lname.value;
	cname = document.prefs.cname.value;
	address1 = document.prefs.address1.value;
	city = document.prefs.city.value;
	state = document.prefs.state.options[parseInt(getPref('state1'))].value;//document.prefs.state.options.selectedIndex;
	zip = document.prefs.zip.value;
	email = document.prefs.email.value;
	phone = document.prefs.phone.value;
	existingClient = document.prefs.existingClient.value;
	var techField = document.prefs.techname.options[parseInt(getPref('techname'))];
	var salesField = document.prefs.salesname.options[parseInt(getPref('salesname'))];	
	if(existingClient == "on") var subscriber = 1; else var subscriber = 0;
	if(requestType == "Sales") var to = salesField.value; else var to = techField.value;
	var message=document.request.request.value;

	var url = "http://www.epicsitedesigns.com/sites/machelp/?action=email&fname="+
					fname+"&lname="+lname+"&company="+cname+"&address="+
					address1+"&city="+city+"&zipcode="+zip+"&email="+email+
					"&phone="+phone+"&state="+state+"&subscriber="+subscriber+
					"&to="+to+"&type="+requestType+"&message="+message+"&";

	alertbox("<b><u>Please Wait While Sending Request.</u></b><br />Gathering Data...");
	alert("Grabbing System Profiler info & saving it to /private/tmp/[email].txt");
	widget.system("system_profiler > /private/tmp/"+email+".txt",null);
	alertbox("<b><u>Please Wait While Sending Request.</u></b><br />Gathering Data...Done<br />Transferring Diagnostic Information...");
	alert("Trying to upload...");
	var commandLine = "/usr/bin/osascript -e 'tell application \"URL Access Scripting\" to upload \"/private/tmp/"+email+".txt\" to \"ftp://machelp%40epicsitedesigns.com:w1dg3t@ftp.epicsitedesigns.com/"+email+".txt\" with progress'"
  var output = widget.system(commandLine, null).outputString;
  alertbox("<b><u>Please Wait While Sending Request.</u></b><br />Gathering Data...Done<br />Transferring Diagnostic Information...Done<br />Delivering Request...");
	alert("Did file upload to site? " + output);
	
				var xml_request = new XMLHttpRequest();
				xml_request.onload = function(e) { 
					var msg = xml_request.responseText;
					alertbox(msg + "<br />");
					if(msg.indexOf("activate") == -1) cleanUp(1);
				}
				xml_request.overrideMimeType("text/xml");
				xml_request.open("GET", url,true);
				xml_request.setRequestHeader("Cache-Control", "no-cache");
				xml_request.setRequestHeader("wx", "385");
				xml_request.send(null);		


	/* OLD CODE
	var techField = document.prefs.techname.options[parseInt(getPref('techname'))];
	var salesField = document.prefs.salesname.options[parseInt(getPref('salesname'))];
	var techTo = techField.text + " <" + techField.value + ">";
	var salesTo = salesField.text + " <" + salesField.value + ">";
	var message = "Name: " + getPref('fname') + " " + getPref('lname') + " <" + getPref('email') + ">" + 
						 "\nPhone Number: " + getPref('phone') + 
						 "\nCompany Name: " + getPref('cname') +
						 "\nAddress:\n\t" + getPref('address1') + "\n\t" + getPref('city') + ", " + document.prefs.state.options[parseInt(getPref('state1'))].value + " " + getPref('zip') +
						 "\nTech contact: " + techTo + 
						 "\nSales contact: " + salesTo + 
						 "\nRequest type: " + requestType +
						 "\n\nRequest Description: \n\t" + document.request.request.value;
	if(requestType == "Sales") var to = salesTo;
	if(requestType == "Support") var to = techTo;

		alert("Sending a " + requestType + " request...");
	
	var subject = "[Widget " + requestType + " request] ";
	if(getPref('existingClient')) subject += "Existing Client";
		else
		subject += "Prospective Client";
	var from = getPref('fname') + " " + getPref('lname') + " <" + getPref('email') + ">";
	//alert(to + "\n" + from + "\n" + subject + "\n" + message);
	alert("Attempting to send...");
	//alert(getPref('existingClient'));
	//to = "eric@epicsitedesigns.com";
	if(requestType == "Sales") to = salesTo; else to = techTo;
	var requestURL = "http://www.epicsitedesigns.com/mail?";
	var stringURL = "to=" + to + "&from=" + from + "&subject=" + subject + "&message=" + message + "&p=ep!c&";
	//alert(stringURL);
	req = new XMLHttpRequest();
	req.onreadystatechange = isSent;
	req.open("POST", requestURL+stringURL, false);
	req.send("");
	*/
}

function isSent() {
	if(req.readyState == 4 && req.status >= 200) {
		if(req.responseText == "success") cleanUp(1)
		else cleanUp(0);
	}
}

function cleanUp(success) {
	if(success == 1) cText = "<em>Your request has been received and will be processed.</em>";
	if(success == 0) cText = "<em>Failed to send request.  Please call your 24/7 IT Support Line.</em>";

	document.request.request.value = "Please complete your request in detail...";
	document.getElementById("request").style.color = "gray";
	document.getElementById("request").style.fontStyle = "italic";
	document.getElementById("connection_text").innerHTML = cText;
	stretchTo(2, event);
}





