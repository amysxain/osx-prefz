/* Default Apple (enhanced) scripts */

/* Mouseover "i" button, enables circle */
function enterflip(event)
{
	document.getElementById('fliprollie').style.display = 'block';
}

function exitflip(event)
{
	document.getElementById('fliprollie').style.display = 'none';
}

/* fading script */
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};

function mousemove (subject, event)
{
	if (!flipShown)
	{
		if (animation.timer != null)
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
 
		var starttime = (new Date).getTime() - 13;
 
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = subject; //document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 1.0;
		animate();
		flipShown = true;
	}
}
function mouseexit (subject, event)
{
	if (flipShown)
	{
		// fade in the info button
		if (animation.timer != null)
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}

		var starttime = (new Date).getTime() - 13;

		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = subject; //document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}

function animate()
{
	var T;
	var ease;
	var time = (new Date).getTime();
   

	T = limit_3(time-animation.starttime, 0, animation.duration);

	if (T >= animation.duration)
	{
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	}
	else
	{
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}

	animation.firstElement.style.opacity = animation.now;
}

function limit_3 (a, b, c)
{
	return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease)
{
	return from + (to - from) * ease;
}

/* Stretch animation */
/*
 * Stretcher constructor.  Parameters:
 *
 * -- element: The element to stretch
 * -- doneNotification: A callback (if no callback is needed, pass null)
 *
 */
//

function Stretcher (element, doneNotification, heightIncrement) {
	this.element = element;

	this.startTime = 0;
	this.timer = null;
	
	// min and max position can be changed to alter the stretched/shrunk sizes.
	var computedStyle = document.defaultView.getComputedStyle(this.element, "");
	this.minPosition = parseInt(computedStyle.getPropertyValue("height"));
	this.maxPosition = heightIncrement; //this.minPosition + heightIncrement;
	
	this.positionFrom = this.minPosition;
	this.positionNow = this.minPosition;
	this.positionTo = 0;
	
	this.isCollapsed = false;
	this.stretching = false;
	
	this.stretch = Stretcher_stretch;
	this.tick = Stretcher_tick;
	this.doneNotification = doneNotification;
}
/*
 * This should only be called via a Stretcher instance, i.e. "instance.stretch(event)"
 * Calling Stretcher_stretch() directly will result in "this" evaluating to the window
 * object, and the function will fail.  Parameters:
 * 
 * -- event: the mouse click that starts everything off (from an onclick handler).
 *		We check for the shift key to do a slo-mo stretch.
 */
//For setting how much the content increases or decreases in size
// --- Defaults to "50";
 
function Stretcher_stretch (event) {
	if (this.stretching) return;
	
	var timeNow = (new Date).getTime();
	var multiplier = (event.shiftKey ? 10 : 1); // enable slo-mo
	
	var computedHeight = document.defaultView.getComputedStyle(this.element, "").getPropertyValue("height");
	if (this.isCollapsed) {
		// we're shrinking back down.  Save the previous maximized size.
		//this.maxPosition = parseInt(computedHeight, 10);
	} else {
		// we're stretching.  Save the previous minimum.
		this.minPosition = parseInt(computedHeight, 10);
	}

	
	this.stretchTime = 250 * multiplier;
	this.positionFrom = this.positionNow;
	
	var resizeTo = this.isCollapsed ? this.minPosition : this.maxPosition;

	this.positionTo = parseInt(resizeTo); // lots of hard coding, yum...
	this.startTime = timeNow - 13; // set it back one frame.
	
	// We need to store this in a local variable so the timer does not lose scope
	// when invoking tick.
	var localThis = this;
	this.stretching = true;
	this.timer = setInterval (function() { localThis.tick(); }, 13);
	this.tick();
}
/*
 * Tick does all the incremental resize work.
 * This function is very similar to the tick() function in the Fader sample.
 */
function Stretcher_tick () {
	var T;
	var ease;
	var time  = (new Date).getTime();
	var yLoc;
	var frame;
		
	T = limit_3(time-this.startTime, 0, this.stretchTime);
	ease = 0.5 - (0.5 * Math.cos(Math.PI * T / this.stretchTime));

	if (T >= this.stretchTime) {
		this.element.style.height = this.maxPosition + "px";
		yLoc = this.positionTo;
		clearInterval (this.timer);
		this.timer = null;
		this.isCollapsed = !this.isCollapsed;
		if (this.doneNotification) {
			// call after the last frame is drawn
			var localThis = this;
			setTimeout (function() { localThis.doneNotification(); }, 0);
		}
		this.stretching = false;
	} else {
		yLoc = computeNextFloat(this.positionFrom, this.positionTo, ease);
		// convert to a integer, not sure if this is the best way
		this.positionNow = parseInt(yLoc);
		this.element.style.height = this.positionNow + "px";
		if(window.widget) window.resizeTo(425, yLoc+60);
	}
}

/* Back to apple functions! */
/* Display front/back of widget */
