//----------------------------------------------------------------------------------------------
//									Declaring variables
var Timer = 1500;
var stretcher;
var glassDoneButton;
var whiteInfoButton;
var Listscrollbar, ListscrollArea;
var Datascrollbar, DatascrollArea;

var KleurStyleIn = "#FFFFFF";
var KleurStyleOut = "#FFFF00";
var poortTabel = new Array(55000);
	poortTabel[20] = "FTP";
	poortTabel[21] = "FTP";
	poortTabel[22] = "SSH";
	poortTabel[23] = "Telnet";
	poortTabel[25] = "SMTP";
	poortTabel[53] = "DNS";
	poortTabel[80] = "Web";
	poortTabel[110] = "POP3";
	poortTabel[119] = "NNTP";
	poortTabel[123] = "Time";
	poortTabel[139] = "Samba";
	poortTabel[143] = "IMAP";
	poortTabel[407] = "Timbuktu";
	poortTabel[427] = "Web";
	poortTabel[443] = "HTTPS";
	poortTabel[510] = "FirstClass";
	poortTabel[515] = "Printer";
	poortTabel[548] = "AFP";
	poortTabel[554] = "QuickTime";
	poortTabel[591] = "FileMaker";
	poortTabel[631] = "CUPS";
	poortTabel[993] = "S-IMAP";
	poortTabel[995] = "S-POP3";
	poortTabel[1863] = "MSN";
	poortTabel[2083] = "iTunes";
	poortTabel[3031] = "RemoteAE";
	poortTabel[3283] = "ARD";
	poortTabel[3689] = "iTunes";
	poortTabel[4662] = "Donkey";
	poortTabel[5190] = "AIM";
	poortTabel[5222] = "Jabber";
	poortTabel[5223] = "Jabber";
	poortTabel[5297] = "iChat";
	poortTabel[5298] = "iChat";
	poortTabel[5900] = "ARD";
	poortTabel[6346] = "Limewire";
	poortTabel[6348] = "Limewire";
	poortTabel[6881] = "Torrent";
	poortTabel[6667] = "IRC";
	poortTabel[7777] = "Unreal";
	poortTabel[8080] = "Proxy";
	poortTabel[8770] = "iPhoto";
	poortTabel[9898] = "AIM";

//----------------------------------------------------------------------------------------------
//									Load script
function Laad()
{
	stretcher = new Stretcher(document.getElementById('Voorkant'), 200, 250, ToonVelden);
	glassDoneButton = new AppleGlassButton(document.getElementById('doneButton'), "Done", hidePrefs);
	whiteInfoButton = new AppleInfoButton(document.getElementById('infoButton'), document.getElementById('Voorkant'), "white", "white", showPrefs);

	Listscrollbar = new AppleVerticalScrollbar(document.getElementById('ListScrollBar'));
	ListscrollArea = new AppleScrollArea(document.getElementById('ListContainer'), Listscrollbar);
	ListscrollArea.scrollsHorizontally = false;
	ListscrollArea.singlepressScrollPixels = 15;
	window.onfocus = function () { ListscrollArea.focus(); }
	window.onblur = function () { ListscrollArea.blur(); }
	Datascrollbar = new AppleVerticalScrollbar(document.getElementById('DataScrollBar'));
	DatascrollArea = new AppleScrollArea(document.getElementById('DataContainer'), Datascrollbar);
	DatascrollArea.scrollsHorizontally = false;
	DatascrollArea.singlepressScrollPixels = 15;
	window.onfocus = function () { DatascrollArea.focus(); }
	window.onblur = function () { DatascrollArea.blur(); }
	
	
	if (window.widget)
	{
		
		var ThemaPref = widget.preferenceForKey("Theme");
		if (ThemaPref == undefined || ThemaPref == null)
		{
			ThemaPref = 0;
			widget.setPreferenceForKey(ThemaPref,"Theme");
			document.getElementById('ThemaPopup').selectedIndex = ThemaPref;
		} else {
			
			document.getElementById('ThemaPopup').selectedIndex = ThemaPref;
		}
		switch(ThemaPref) {
			case 0:
				document.getElementById('Bovenkant').style.background = "url(Images/Red_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Red_02.png)";
			break;
			case 1:
				document.getElementById('Bovenkant').style.background = "url(Images/WarmRed_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/WarmRed_02.png)";
			break;
			case 2:
				document.getElementById('Bovenkant').style.background = "url(Images/Yellow_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Yellow_02.png)";
			break;
			case 3:
				document.getElementById('Bovenkant').style.background = "url(Images/Green_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Green_02.png)";
			break;
			case 4:
				document.getElementById('Bovenkant').style.background = "url(Images/Blue_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Blue_02.png)";
			break;
			case 5:
				document.getElementById('Bovenkant').style.background = "url(Images/Grey_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Grey_02.png)";
			break;
			case 6:
				document.getElementById('Bovenkant').style.background = "url(Images/DarkGrey_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/DarkGrey_02.png)";
			break;
		}
		
		var IncomingPref = widget.preferenceForKey("Incoming");
		if (IncomingPref == undefined || IncomingPref == null)
		{
			IncomingPref = 0;
			widget.setPreferenceForKey(IncomingPref,"Incoming");
			document.getElementById('InkomendKleurPopup').selectedIndex = IncomingPref;
		} else {
			document.getElementById('InkomendKleurPopup').selectedIndex = IncomingPref;
		}
		switch(IncomingPref) {
			case 0:
				KleurStyleIn = "<font color='#FFFFFF'>";
			break;
			case 1:
				KleurStyleIn = "<font color='#FFFF00'>";
			break;
			case 2:
				KleurStyleIn = "<font color='#00FF00'>";
			break;
			case 3:
				KleurStyleIn = "<font color='#FF0000'>";
			break;
			case 4:
				KleurStyleIn = "<font color='#000000'>";
			break;
			case 5:
				KleurStyleIn = "<font color='#0000FF'>";
			break;
		}
		
		var OutgoingPref = widget.preferenceForKey("Outgoing");
		if (OutgoingPref == undefined || OutgoingPref == null)
		{	
			OutgoingPref = 0;
			widget.setPreferenceForKey(OutgoingPref,"Outgoing");
			document.getElementById('UitgaandKleurPopup').selectedIndex = OutgoingPref;
		} else {
			document.getElementById('UitgaandKleurPopup').selectedIndex = OutgoingPref;
		}
		switch(OutgoingPref) {
			case 0:
				KleurStyleOut = "<font color='#FFFF00'>";
			break;
			case 1:
				KleurStyleOut = "<font color='#FF0000'>";
			break;
			case 2:
				KleurStyleOut = "<font color='#00FF00'>";
			break;
			case 3:
				KleurStyleOut = "<font color='#0000FF'>";
			break;
			case 4:
				KleurStyleOut = "<font color='#FFFFFF'>";
			break;
			case 5:
				KleurStyleOut = "<font color='#000000'>";
			break;
		}
		
		timerInterval = setInterval("ToonVerbindingen();", Timer);
	}
	
	ToonVerbindingen();
}

//----------------------------------------------------------------------------------------------
//									Timerinterval related
if (window.widget) {
    widget.onhide = onhide;
    widget.onshow = onshow;
}

function onshow() 
{
	if (timerInterval == null) 
	{
		ToonVerbindingen();
		timerInterval = setInterval("ToonVerbindingen();", Timer);
	}
}

function onhide() {
	if (timerInterval != null) 
	{
		clearInterval(timerInterval);
		timerInterval = null;
	}
}

//----------------------------------------------------------------------------------------------
//									Rotation of the widget
function showPrefs()
{
	var front = document.getElementById('Voorkant');
	var back = document.getElementById('Achterkant');
	
	if (window.widget)
	{
		widget.prepareForTransition("ToBack");
	}
	front.style.display="none";
	back.style.display="block";
	
	if (window.widget)
	{
		setTimeout ("widget.performTransition();", 0);	
	}
}

function hidePrefs()
{
	var front = document.getElementById('Voorkant');
	var back = document.getElementById('Achterkant');
	
	if (window.widget)
	{
		widget.prepareForTransition("ToFront");
	}
	back.style.display="none";
	front.style.display="block";
	
	if (window.widget)
	{
		setTimeout ("widget.performTransition();", 0);
	}
	ToonVerbindingen();
}

//----------------------------------------------------------------------------------------------
//									Activated by clicking on the popup

function ThemaPopupDoe(popupItem)
{
	if(window.widget)
	{
		widget.setPreferenceForKey(popupItem.selectedIndex,"Theme");
		switch(popupItem.selectedIndex) {
			case 0:
				document.getElementById('Bovenkant').style.background = "url(Images/Red_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Red_02.png)";
			break;
			case 1:
				document.getElementById('Bovenkant').style.background = "url(Images/WarmRed_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/WarmRed_02.png)";
			break;
			case 2:
				document.getElementById('Bovenkant').style.background = "url(Images/Yellow_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Yellow_02.png)";
			break;
			case 3:
				document.getElementById('Bovenkant').style.background = "url(Images/Green_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Green_02.png)";
			break;
			case 4:
				document.getElementById('Bovenkant').style.background = "url(Images/Blue_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Blue_02.png)";
			break;
			case 5:
				document.getElementById('Bovenkant').style.background = "url(Images/Grey_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/Grey_02.png)";
			break;
			case 6:
				document.getElementById('Bovenkant').style.background = "url(Images/DarkGrey_01.png)";
				document.getElementById('Onderkant').style.background = "url(Images/DarkGrey_02.png)";
			break;
		}
	}
}

function InkomendKleurPopupDoe(popupItem)
{
	if(window.widget)
	{
		widget.setPreferenceForKey(popupItem.selectedIndex,"Incoming");
		switch(popupItem.selectedIndex) {
			case 0:
				KleurStyleIn = "<font color='#FFFFFF'>";
			break;
			case 1:
				KleurStyleIn = "<font color='#FFFF00'>";
			break;
			case 2:
				KleurStyleIn = "<font color='#00FF00'>";
			break;
			case 3:
				KleurStyleIn = "<font color='#FF0000'>";
			break;
			case 4:
				KleurStyleIn = "<font color='#000000'>";
			break;
			case 5:
				KleurStyleIn = "<font color='#0000FF'>";
			break;
		}
	}
}

function UitgaandKleurPopupDoe(popupItem)
{
	if(window.widget)
	{
		widget.setPreferenceForKey(popupItem.selectedIndex,"Outgoing");
		switch(popupItem.selectedIndex) {
			case 0:
				KleurStyleOut = "<font color='#FFFF00'>";
			break;
			case 1:
				KleurStyleOut = "<font color='#FF0000'>";
			break;
			case 2:
				KleurStyleOut = "<font color='#00FF00'>";
			break;
			case 3:
				KleurStyleOut = "<font color='#0000FF'>";
			break;
			case 4:
				KleurStyleOut = "<font color='#FFFFFF'>";
			break;
			case 5:
				KleurStyleOut = "<font color='#000000'>";
			break;
		}
	}
}

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//									Showing the IP list
function ToonVerbindingen()
{
	var inhoud = document.getElementById('ListContainer');
	var resultaat = maakNetstatArray();
	var aantalRijen = resultaat.length;
	
	document.getElementById('ListContainer').innerText = "";
	ListscrollArea.refresh();
	
	for (var i=0; i< aantalRijen; ++i)
	{
		var element = resultaat[i];
		if (element.ipNummer != "127.0.0.1")
		{
			var rij = maakRij(element.ipNummer, element.poort, element.uitgaand);
			inhoud.appendChild(rij);
		}
	}
	
	ListscrollArea.refresh();
}

//----------------------------------------------------------------------------------------------
//									Getting IP numbers, ports and upstream
function maakNetstatArray()
{
	var netstatArray = new Array();
	var ipnummerArray = new Array();
	var poortArray = new Array();
	var uitgaandArray = new Array();
	
	var obj = widget.system("netstat -n | grep 'ESTABLISHED' | awk '{print $3, \"A\", $5, \"E\"}'", null);
	var ruwResultaat = obj.outputString;
	var lijnen = new Array();
	lijnen = ruwResultaat.split("E");
	for (var i = 0; i < (lijnen.length - 1); i++)
	{
		lijnen[i] = lijnen[i].replace(/ /g,"");
		var lijn = new Array();
		lijn = lijnen[i].split("A");
		var lijnString = lijn[1] + "";
		var ipsEnPoorten = new Array();
		ipsEnPoorten = lijnString.split(".");
		
		ipnummerArray[i] = ipsEnPoorten[0] + "." + ipsEnPoorten[1] + "." + ipsEnPoorten[2] + "." + ipsEnPoorten[3];
		poortArray[i] = maakPoortNaam((ipsEnPoorten[4] + ""));
		uitgaandArray[i] = lijn[0];
		
		netstatArray[i] = new Array();
		netstatArray[i] = {ipNummer:ipnummerArray[i], poort:poortArray[i], uitgaand:uitgaandArray[i]};
	}
	
	return netstatArray;
}

//----------------------------------------------------------------------------------------------
//									Create a styled row of IP, port and upstream
function maakRij(ipNummer, poort, uitgaand)
{
	var styledrij = document.createElement ('div');
	styledrij.setAttribute ('class', 'RijStyle');
	var ipDiv = document.createElement ('div');
	if (uitgaand > 0)
	{
		ipDiv.setAttribute ('id', 'IPUitStyle');
		ipDiv.innerHTML = KleurStyleOut + ipNummer + "</font>";
	} else {
		ipDiv.setAttribute ('id', 'IPInStyle');
		ipDiv.innerHTML = KleurStyleIn + ipNummer + "</font>";
	}
	ipDiv.setAttribute ('ipNumber', ipNummer);
	ipDiv.setAttribute ('onclick', 'clickOpIp(event, this);');
	styledrij.appendChild (ipDiv);
	var poortDiv = document.createElement ('div');
	if (uitgaand > 0)
	{
		poortDiv.setAttribute ('id', 'PoortUitStyle');
		poortDiv.innerHTML = KleurStyleOut + poort + "</font>";
	} else {
		poortDiv.setAttribute ('id', 'PoortInStyle');
		poortDiv.innerHTML = KleurStyleIn + poort + "</font>";
	}
	styledrij.appendChild (poortDiv);
	var uitgaandDiv = document.createElement ('div');
	uitgaandDiv.setAttribute ('id', 'UitgaandStyle');
	if (uitgaand != 0)
	{
		uitgaandDiv.innerHTML = KleurStyleOut + naarKB(uitgaand) + "</font>";
	} else {
		uitgaandDiv.innerHTML = "";
	}
	styledrij.appendChild (uitgaandDiv);
	
	return styledrij;
}

//----------------------------------------------------------------------------------------------
//									Click on IP address
function clickOpIp(event, ipNummer)
{
	if (window.widget)
	{
		if (stretcher.isStretched())
		{
			ToonData(ipNummer);
		} else {
			stretcher.stretch(event);
			ToonData(ipNummer);
		}
	}
}

//----------------------------------------------------------------------------------------------
//									Create name of port or return number back
function maakPoortNaam(poortNummer)
{
	var poortNaam;
	if (!poortTabel[poortNummer])
	{
		poortNaam = poortNummer;
	} else {
		poortNaam = poortTabel[poortNummer];
	}
	return poortNaam;
}

//----------------------------------------------------------------------------------------------
//									Show whois data
function ToonData(gevraagdIpNummer)
{
	document.getElementById('DataContainer').innerHTML = "";
	DatascrollArea.refresh();
	var opgegeven = gevraagdIpNummer.ipNumber + "";
	document.getElementById('DataTitel').innerHTML = opgegeven;
	var whoisCommandoLijn = widget.system("whois " + opgegeven + " | awk '{print $0, \"---\"}'", null);
	var dataText = whoisCommandoLijn.outputString;
	if (dataText == "undefined")
	{
		dataText = whoisCommandoLijn.errorString;
	} else {
		dataText = dataText.replace(/---/g,"<br>");
	}
	document.getElementById('DataContainer').innerHTML = dataText;
	DatascrollArea.refresh();
}

//----------------------------------------------------------------------------------------------
//									Close the drawer
function SluitStretcher(event)
{
	if (stretcher.isStretched())
	{
		document.getElementById('Masker').style.display = "none";
		stretcher.stretch(event);
	}
}
//----------------------------------------------------------------------------------------------
//									After the stretcher show the fields if needed
function ToonVelden ()
{
	document.getElementById('Masker').style.display = stretcher.isStretched() ? "block" : "none";
}

//----------------------------------------------------------------------------------------------
//									Converts to KiloBytes if possible
function naarKB(uitgaand)
{
	if (uitgaand > 1024)
	{
		var opgegeven = Math.round((uitgaand / 1024));
		opgegeven = opgegeven + " KB";
	} else {
		var opgegeven = uitgaand + " B";
	}
	return opgegeven;
}