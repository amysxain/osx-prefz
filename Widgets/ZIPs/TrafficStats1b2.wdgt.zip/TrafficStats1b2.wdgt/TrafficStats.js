widget.onremove = lastFunctionsBeforeQuit;

var oldContent;
var oldControl;

function showContent(newContent, newControl) {	// OK
	if (oldContent != null) {
		oldContent.style.display = 'none';
		oldControl.style.textDecoration = 'none';
	}
	newControl.style.textDecoration = 'underline';
	newContent.style.display = 'block';


	oldContent = newContent;
	oldControl = newControl;
}	

function stopScroll() { if (time) clearTimeout(time); }

function doScroll(){
	clipTop += amount;
	clipBottom += amount;
	topper -= amount;
	if (clipTop < 6 || clipBottom > lyrheight)
	{
		clipTop -= amount;
		clipBottom -= amount;
		topper += amount;
		return;
	}

	clipstring = 'rect('+clipTop+'px,'+clipWidth+'px,'+clipBottom+'px,0px)';
	document.getElementById("scrollDiv").style.clip = clipstring;
	document.getElementById("scrollDiv").style.top = topper + 'px';
	time = setTimeout('doScroll()',theTime);
}

var time,amount,theTime,theHeight;

function initClip(){
	var myDummyClipData = document.getElementById("scrollDiv").style.clip.split("px ");
	clipTop = Number(myDummyClipData[0].split("(")[1]);
	clipWidth = Number(myDummyClipData[1]);
	clipBottom = Number(myDummyClipData[2]);
	topper = document.getElementById("scrollDiv").style.top;
	topper = Number(topper.substring(0,topper.length-2));
	lyrheight = 320;	// should be found out by using computedStyle
}

function scrollInfoText(amt,tim){
	amount = amt;
	theTime = tim;
	doScroll();
}

function switchContent(myArg){	// OK
	var myDummyArray = new Array("IpPrefs", "TrafficPrefs","InfoPrefs","SkinPrefs","DataPrefs","Author");
	showContent(document.getElementById(myDummyArray[myArg]), document.getElementById('Bt' + myArg + 'Control'));
}

function init(){
	fillList("sl_refreshTrafficAmount",1,59);	fillList("sl_periodStartDay",1,31);
	myO = new tsObject();
	tObject = new themesObject();
	switchContent(0); // shows first section (tab?) on backside
	readPrefs();
	if (myO.ipRefreshStatus == 1) getIp();
	collectInterfaces();
	setFormFieldsOnBack();   // Set refresh-fields (on prefs page)
	setRefreshFieldsOnFront();
	getTraffic();	// Get Traffic for the first time
	setRefreshTimer();	// Sets Timer for Traffic-Calc-function
	initClip();
}

function setRefreshVars(){	// Called by Done-Button; Set Refreshtime according to backside-prefs-elements
	for (var i = 0; i<document.getElementsByName("rb_IpRefresh").length; i++) {
		if (document.getElementsByName("rb_IpRefresh")[i].checked == true){
			myO.ipRefreshStatus = document.getElementById("rb_IpRefresh" + i).value;
		}
	}
	myO.trafficRefreshAmount = document.getElementById("sl_refreshTrafficAmount").selectedIndex+1;
	myO.trafficRefreshRate = document.getElementById("sl_refreshTrafficRate").selectedIndex;
	myO.setTrafficRefreshData(Math.pow(60,myO.trafficRefreshRate) * 1000 * myO.trafficRefreshAmount);
	myO.periodStartDay = document.getElementById("sl_periodStartDay").selectedIndex + 1;
	myO.interfaceIndex = document.getElementById("sl_interfaces").selectedIndex;
	myO.stdInterface = myO.savedInterface = document.getElementById("sl_interfaces").options[myO.interfaceIndex].value;
	setRefreshFieldsOnFront();
	myO.setNextPeriodStart(myO.periodStartDay);
	setRefreshTimer();
	setPrefs();
}
function readPrefs(){
	myO.setIpRefreshStatus(widget.preferenceForKey("ipRefreshStatus"));
	myO.setTrafficRefreshData(widget.preferenceForKey("TrafficRefreshData"));

	myO.setPeriodStartDay(widget.preferenceForKey("PeriodStartDay"));

	myO.setStdInterface(widget.preferenceForKey("StdInterface"));
	myO.setNewPeriodBool(widget.preferenceForKey("NewPeriodBool"));

	tObject.setTheme(widget.preferenceForKey("Theme"));
	var myDummy = widget.preferenceForKey("SavedBytes");		myO.setSavedBytes(myDummy);
	var myDummy = widget.preferenceForKey("ActPeriodBytes");	myO.setActPeriodBytes(myDummy);
	var myDummy = widget.preferenceForKey("LastPeriodBytes");	myO.setLastPeriodBytes(myDummy);
	showStatus("Prefs read");
}
function showStatus(myMsg){
	var myDummyVar = document.getElementById("tf_Status").title.lastIndexOf("\n");
	if (myDummyVar != -1) myDummyVar = document.getElementById("tf_Status").title.substring(myDummyVar+1,document.getElementById("tf_Status").title.length);
	if (myDummyVar != myMsg) document.getElementById("tf_Status").title = document.getElementById("tf_Status").title + "\n" + myMsg;
	document.getElementById("tf_Status").innerHTML = myMsg;
}

function lastFunctionsBeforeQuit(){
	showStatus("lastFunctionsBeforeQuit")
	setPrefs();
}
function setTrafficFieldsOnFront(){	// OK
	var myDummy = myO.getDispSessionInBytes();
	document.getElementById("tf_SessionInBytes").innerHTML=myDummy[0]; document.getElementById("tf_SessionInRate").innerHTML = myDummy[1];
	var myDummy = myO.getDispSessionOutBytes();
	document.getElementById("tf_SessionOutBytes").innerHTML=myDummy[0];	document.getElementById("tf_SessionOutRate").innerHTML=myDummy[1];
	var myDummy = myO.getDispSessionBytes();
	document.getElementById("tf_SessionAllBytes").innerHTML=myDummy[0];	document.getElementById("tf_SessionAllRate").innerHTML=myDummy[1];
	
	var myDummy = myO.getDispActPeriodInBytes();
	document.getElementById("tf_ThisPeriodInBytes").innerHTML=myDummy[0];
	document.getElementById("tf_ThisPeriodInRate").innerHTML=myDummy[1];
	var myDummy = myO.getDispActPeriodOutBytes();
	document.getElementById("tf_ThisPeriodOutBytes").innerHTML=myDummy[0];
	document.getElementById("tf_ThisPeriodOutRate").innerHTML=myDummy[1];
	var myDummy = myO.getDispActPeriodBytes();
	document.getElementById("tf_ThisPeriodAllBytes").innerHTML=myDummy[0];
	document.getElementById("tf_ThisPeriodRate").innerHTML=myDummy[1];
	var myDummy = myO.getDispLastPeriodInBytes();
	document.getElementById("tf_LastPeriodInBytes").innerHTML=myDummy[0];
	document.getElementById("tf_LastPeriodInRate").innerHTML=myDummy[1];
	var myDummy = myO.getDispLastPeriodOutBytes();
	document.getElementById("tf_LastPeriodOutBytes").innerHTML=myDummy[0];
	document.getElementById("tf_LastPeriodOutRate").innerHTML=myDummy[1];
	var myDummy = myO.getDispLastPeriodBytes();
	document.getElementById("tf_LastPeriodAllBytes").innerHTML=myDummy[0];
	document.getElementById("tf_LastPeriodRate").innerHTML=myDummy[1];
	setNextUpdate();
}
function setFormFieldsOnBack(){	// OK
	// Called by Cancel-Button (set Refresh-Fields to last saved state)
	document.getElementById("rb_IpRefresh" + myO.ipRefreshStatus).checked = true;
	document.getElementById("sl_refreshTrafficAmount").options[myO.trafficRefreshAmount-1].selected = true;
	document.getElementById("sl_refreshTrafficRate").options[myO.trafficRefreshRate].selected = true;
	document.getElementById("sl_interfaces").options[myO.interfaceIndex].selected = true;
	document.getElementById("sl_periodStartDay").options[myO.periodStartDay-1].selected = true;
	document.getElementById("sl_switchControl").options[tObject.getThemeIndex()].selected = true;
}
function setPrefs(){
	widget.setPreferenceForKey(Number(myO.ipRefreshStatus).toFixed(0),"ipRefreshStatus");
	widget.setPreferenceForKey(Number(myO.trafficRefreshMilliSeconds).toFixed(0),"TrafficRefreshData");

	widget.setPreferenceForKey(Number(myO.periodStartDay).toFixed(0), "PeriodStartDay");

	widget.setPreferenceForKey(myO.getNewPeriodBool(), "NewPeriodBool");
	widget.setPreferenceForKey(tObject.getTheme(), "Theme");

	widget.setPreferenceForKey(myO.stdInterface, "StdInterface");
	widget.setPreferenceForKey(Number(myO.getSavedInBytes()).toFixed(2)     + "|" + Number(myO.getSavedOutBytes()).toFixed(2), "SavedBytes");
	widget.setPreferenceForKey(Number(myO.getActPeriodInBytes()).toFixed(2)  + "|" + Number(myO.getActPeriodOutBytes()).toFixed(2), "ActPeriodBytes");
	widget.setPreferenceForKey(Number(myO.getLastPeriodInBytes()).toFixed(2) + "|" + Number(myO.getLastPeriodOutBytes()).toFixed(2),"LastPeriodBytes");
	showStatus("Prefs written");
}
function setRefreshFieldsOnFront(){	// OK
	document.getElementById("tf_interfaceType").innerHTML = myO.interfaceName[myO.interfaceIndex];
	document.getElementById("tf_trafficTimerDisp").innerHTML = myO.getRealTrafficTime();
}
function setRefreshTimer(){	// OK
	// Called after Init or after a new timerate was set
	if (myO.refreshTrafficTimer != null) clearInterval(myO.refreshTrafficTimer);
	myO.refreshTrafficTimer = setInterval("getTraffic();", myO.trafficRefreshMilliSeconds);
	setNextUpdate();
}
function setNextUpdate(){	// OK
	// time till next Traffic-calculation
	var nextUpdateTime = new Date(); var myTime = nextUpdateTime.getTime();
	myTime = Number(myO.trafficRefreshMilliSeconds) + Number(myTime);
	nextUpdateTime.setTime(myTime);
	var myHour = String(nextUpdateTime.getHours())   ; if (myHour.length == 1) { myHour = "0" + myHour };
	var myMinute = String(nextUpdateTime.getMinutes()) ; if (myMinute.length == 1) { myMinute = "0" + myMinute };
	var mySecond = String(nextUpdateTime.getSeconds()) ; if (mySecond.length == 1) { mySecond = "0" + mySecond };
	document.getElementById("tf_time").innerHTML = myHour + ":" + myMinute + ":" + mySecond;
}
function fillList(myList,listStart,listEnd){ // OK
	for (var i=listStart;i<=listEnd;i++){	document.getElementById(myList).options[i-1] = new Option(i,i);	}
}