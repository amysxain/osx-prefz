function getIp(){	// collect IP
	var conn = new XMLHttpRequest();
	conn.open("GET", "http://www.whatismyip.com/",false);
	conn.onreadystatechange=function() {
		if (conn.readyState==4){
			response=conn.responseText;
			if (response==null) { myO.extIp="---"; }
			else                {
				myO.extIp = response.match(/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/);
			}
		}
	}
	conn.send(null);
	document.getElementById("tf_externalIp").innerHTML = myO.extIp;
}

function collectInterfaces(){
	var myInterfaceData = "";	// result of ifconfig-command
	var myInterfaces = new Array();	// Array of found interfaces
	var myInterfaceType = new Array();	// i.e. env0
	
	myInterfaceData=widget.system("/sbin/ifconfig",null).outputString;
	myInterfaces=myInterfaceData.split(/(\n)[^\s]/);
	for( var x=0 ; x<myInterfaces.length ; x++){
		myInterfaceType[x] = myInterfaces[x].slice(0,(myInterfaces[x].indexOf(":")));

		if(myInterfaces[x].match("status: active")) {
			myO.interfaceStatus[x] = "(active)";
		} else {
			myO.interfaceStatus[x] = "";
		}
		if      (myInterfaceType[x].substring(0,1)=="n") { myInterfaceType[x] = "e".concat(myInterfaceType[x]); }
		else if (myInterfaceType[x].substring(0,1)=="w") { myInterfaceType[x] = "f".concat(myInterfaceType[x]); }
		else if (myInterfaceType[x].substring(0,1)=="p") { myInterfaceType[x] = "p".concat(myInterfaceType[x]); }
		if      (myInterfaces[x].match("baseT"))      { myO.interfaceName[x]="Ethernet"; }
		else if (myInterfaces[x].substring(0,1)=="w") { myO.interfaceName[x]="Firewire"; }
		else                                          { myO.interfaceName[x]="Airport";  }

		// fill interface-list
		var myDummyText = myO.interfaceName[x] + " - " + myInterfaceType[x] + ": " + myO.interfaceStatus[x];
		var myLength = document.getElementById("sl_interfaces").length;
		document.getElementById("sl_interfaces").options[myLength] = (new Option(myDummyText,myInterfaceType[x]));
		if (myO.savedInterface == myInterfaceType[x] || (myO.savedInterface == "" && myO.interfaceStatus[x] == "(active)")){
			myO.stdInterface = myInterfaceType[x];
			document.getElementById("sl_interfaces").options[myLength].selected = true;
			myO.interfaceIndex = x;
		}
	}
}

function getTraffic(){
	if(myO.stdInterface != "" && myO.stdInterface.substring(0,1)!="p"){
		netstat=widget.system("/usr/sbin/netstat -b -I " + myO.stdInterface,null).outputString;
		netstat1=netstat.replace(/\s+/g," ");
		data=netstat1.split(" ");
		myO.setSessionBytes(Number(data[17]) , Number(data[20]))
	} else {
		myO.setSessionBytes(myO.savedInBytes , myO.savedOutBytes);
	}
	myO.setNextPeriodStart(myO.periodStartDay);
	setTrafficFieldsOnFront();
}