function themesObject(){
	var myThemesArray = new Array()
	var myThemeObject;
	var myThemeIndex = -1;
	var myOldThemeIndex = -1;

	this.setTheme = setTheme;
	this.getTheme = getTheme;
	this.getThemeIndex = getThemeIndex;
	
	for(var i=0; (myThemeObject=document.getElementsByTagName("link")[i]); i++) {
		if(myThemeObject.getAttribute("rel").indexOf("style") != -1 && myThemeObject.getAttribute("title")) {
			myThemesArray[myThemesArray.length] = myThemeObject;
		}
	}

	function setTheme(myThemeTitle){
		if (myThemeTitle != undefined && myThemesArray.length > 0){
			for (var i=0 ; i<myThemesArray.length ; i++){
				if (myThemesArray[i].getAttribute("title") == myThemeTitle) myThemeIndex = i;
			}
		}
		if (myThemeIndex != -1){	// we found a valid theme
			myThemesArray[myThemeIndex].disabled = false;
			if (myOldThemeIndex != -1) myThemesArray[myOldThemeIndex].disabled = true;
			myOldThemeIndex = myThemeIndex;
		} else showStatus("no theme found. using standard-theme");
	}
	
	function getTheme(){ return myThemesArray[myThemeIndex].title }
	function getThemeIndex(){ return myThemeIndex; }
}

function tsObject(){

	/*** Ip-refresh ***/
	this.extIp = "---";
	this.ipRefreshStatus = 0;				// 1 = refresh at start, 0 = refresh never
	this.setIpRefreshStatus = setIpRefreshStatus;

	function setIpRefreshStatus(myIpRefreshStatus){	// -1 = never, 0 = on start, any higher number = time
		if (myIpRefreshStatus != undefined && !isNaN(myIpRefreshStatus)) this.ipRefreshStatus = myIpRefreshStatus;
	}
	
	/*** Traffic-Refresh ***/
	this.refreshTrafficTimer = null;	// Timer for traffic-refresh
	this.trafficRefreshAmount = 5;		//	When to refresh traffic
	this.trafficRefreshRate = 1;		// When to refresh traffic (0 = secs, 1 = mins)
	this.trafficRefreshMilliSeconds = 300000;
	this.setTrafficRefreshData = setTrafficRefreshData;
	this.getRealTrafficTime = getRealTrafficTime;
	
	function setTrafficRefreshData(myTrafficRefreshData){
		if (myTrafficRefreshData != undefined && !isNaN(myTrafficRefreshData) ) this.trafficRefreshMilliSeconds = myTrafficRefreshData;
		var myRRate = 0;
		var myRAmount = this.trafficRefreshMilliSeconds / 1000;
		while (myRAmount > 59){
			myRRate++;
			myRAmount /= 60;
		}
		this.trafficRefreshAmount = myRAmount;
		this.trafficRefreshRate = myRRate;
	}
	function getRealTrafficTime(){
		var myTimeUnitArray = new Array("seconds", "minutes", "hours");
		return this.trafficRefreshAmount + " " + myTimeUnitArray[this.trafficRefreshRate];
	}

	/*** interfaces ***/
	this.interfaceIndex = -1
	this.interfaceName = new Array();
	this.interfaceStatus = new Array();
	this.stdInterface = this.savedInterface = "";
	this.setStdInterface = setStdInterface;

	function setStdInterface(myStdInterface){
		myStdInterface == undefined ? this.stdInterface = this.savedInterface = "" : this.stdInterface = this.savedInterface = myStdInterface;
	}

	/*** savedBytes-section ***/
	var savedInBytes = 0; var savedOutBytes = 0;

	this.setSavedInBytes = setSavedInBytes;
	this.setSavedOutBytes = setSavedOutBytes;
	this.setSavedBytes = setSavedBytes;
	
	this.getSavedInBytes = getSavedInBytes;
	this.getSavedOutBytes = getSavedOutBytes;

	function setSavedInBytes(myBytes){	// OK
		isNaN(myBytes) || myBytes == undefined ? savedInBytes = 0 : savedInBytes = myBytes;
	}
	function setSavedOutBytes(myBytes){	// OK
		isNaN(myBytes) || myBytes == undefined ? savedOutBytes = 0 : savedOutBytes = myBytes;
	}
	function setSavedBytes(myBytes){
		myBytes == undefined ? myBytes = new Array(0,0) : myBytes = myBytes.split("|");
		setSavedInBytes(myBytes[0]); setSavedOutBytes(myBytes[1]);
	}
	function getSavedInBytes(){ return savedInBytes; }
	function getSavedOutBytes(){ return savedOutBytes; }

	/*** actPeriodBytes-Section ***/
	var actPeriodInBytes = 0; var actPeriodOutBytes = 0;

	this.setActPeriodInBytes = setActPeriodInBytes;
	this.setActPeriodOutBytes = setActPeriodOutBytes;
	this.setActPeriodBytes = setActPeriodBytes;
	
	this.getActPeriodInBytes = getActPeriodInBytes;
	this.getActPeriodOutBytes = getActPeriodOutBytes;
	this.getActPeriodBytes = getActPeriodBytes;

	function setActPeriodInBytes(myBytes){	// OK
		isNaN(myBytes) ? actPeriodInBytes = 0 : actPeriodInBytes  = myBytes;
	}
	function setActPeriodOutBytes(myBytes){	// OK
		isNaN(myBytes) ? actPeriodOutBytes = 0 : actPeriodOutBytes  = myBytes;
	}
	function setActPeriodBytes(myBytes){
		myBytes == undefined ? myBytes = new Array(0,0) : myBytes = myBytes.split("|");
		setActPeriodInBytes(myBytes[0]); setActPeriodOutBytes(myBytes[1]);
	}
	function getActPeriodInBytes (){ return actPeriodInBytes; }
	function getActPeriodOutBytes (){ return actPeriodOutBytes; }
	function getActPeriodBytes (){ return Number(getActPeriodInBytes()) + Number(getActPeriodOutBytes()); }
	
	/*** lastPeriod-Section ***/
	var lastPeriodInBytes = 0; var lastPeriodOutBytes = 0;
	this.setLastPeriodInBytes = setLastPeriodInBytes;
	this.setLastPeriodOutBytes = setLastPeriodOutBytes;
	this.setLastPeriodBytes = setLastPeriodBytes;

	this.getLastPeriodInBytes = getLastPeriodInBytes;
	this.getLastPeriodOutBytes = getLastPeriodOutBytes;
	this.getLastPeriodBytes = getLastPeriodBytes;

	function setLastPeriodInBytes(myBytes){	// OK
		isNaN(myBytes) ? lastPeriodInBytes = 0 : lastPeriodInBytes  = myBytes;
	}
	function setLastPeriodOutBytes(myBytes){	// OK
		isNaN(myBytes) ? lastPeriodOutBytes  = 0 : lastPeriodOutBytes  = myBytes;
	}
	function setLastPeriodBytes(myBytes){	// OK
		myBytes == undefined ? myBytes = new Array(0,0) : myBytes = myBytes.split("|");
		setLastPeriodInBytes(myBytes[0]); setLastPeriodOutBytes(myBytes[1]);
	}
	function getLastPeriodInBytes () { return lastPeriodInBytes; }
	function getLastPeriodOutBytes () { return lastPeriodOutBytes; }
	function getLastPeriodBytes () { return Number(getLastPeriodInBytes()) + Number(getLastPeriodOutBytes()); }

	/*** sessionBytes-section ***/
	var sessionInBytes = 0;	var sessionOutBytes = 0;
	this.setSessionBytes = setSessionBytes;
	
	this.getSessionInBytes = getSessionInBytes;
	this.getSessionOutBytes = getSessionOutBytes;
	this.getSessionBytes = getSessionBytes;

	function setSessionBytes(myInBytes, myOutBytes){
		sessionInBytes = myInBytes; sessionOutBytes = myOutBytes;
	}
	function getSessionInBytes(){ return sessionInBytes; }
	function getSessionOutBytes(){ return sessionOutBytes; }
	function getSessionBytes(){ return Number(sessionInBytes) + Number(sessionOutBytes); }

	/*** DispBytes-section ***/
	this.getDispSessionInBytes = getDispSessionInBytes;
	this.getDispSessionOutBytes = getDispSessionOutBytes;
	this.getDispSessionBytes = getDispSessionBytes;
	this.getDispActPeriodInBytes = getDispActPeriodInBytes;
	this.getDispActPeriodOutBytes = getDispActPeriodOutBytes;
	this.getDispActPeriodBytes = getDispActPeriodBytes;
	this.getDispLastPeriodInBytes = getDispLastPeriodInBytes;
	this.getDispLastPeriodOutBytes = getDispLastPeriodOutBytes;
	this.getDispLastPeriodBytes = getDispLastPeriodBytes;

	function getDispSessionInBytes()	{ return returnDispBytes( getSessionInBytes()		);}
	function getDispSessionOutBytes()	{ return returnDispBytes( getSessionOutBytes()		);}
	function getDispSessionBytes()		{ return returnDispBytes( getSessionBytes()			);}
	function getDispActPeriodInBytes()	{ return returnDispBytes( getActPeriodInBytes()		);}
	function getDispActPeriodOutBytes()	{ return returnDispBytes( getActPeriodOutBytes()	);}
	function getDispActPeriodBytes()	{ return returnDispBytes( getActPeriodBytes()		);}
	function getDispLastPeriodInBytes()	{ return returnDispBytes( getLastPeriodInBytes()	);}
	function getDispLastPeriodOutBytes(){ return returnDispBytes( getLastPeriodOutBytes()	);}
	function getDispLastPeriodBytes()	{ return returnDispBytes( getLastPeriodBytes()		);}

	function returnDispBytes(myBytes){
		var myBitNames = new Array(" Byte", " KByte", " MByte", " GByte");
		for( var myScale=0 ; myBytes >= 1024; myScale++) { myBytes/= 1024; }
		return ( new Array(Number(myBytes).toFixed(2), myBitNames[myScale]) );
	}

	// *** savedInBytes > InBytes ? Mac was restarted after last Calc and netstats where "reset" ***
	this.archiveTrafficData = archiveTrafficData;

	function archiveTrafficData(myBool){
		// set Saved bytes
		savedInBytes  > sessionInBytes  ? savedInBytes  = sessionInBytes  : savedInBytes  = Number(sessionInBytes) - Number(savedInBytes);
		savedOutBytes > sessionOutBytes ? savedOutBytes = sessionOutBytes : savedOutBytes = Number(sessionOutBytes) - Number(savedOutBytes);
		// set actperiod - bytes
		actPeriodInBytes = Number(actPeriodInBytes) + Number(savedInBytes);
		actPeriodOutBytes = Number(actPeriodOutBytes) + Number(savedOutBytes);
		savedInBytes = sessionInBytes;
		savedOutBytes = sessionOutBytes;
		if (myBool == true){ // a new Period has begun, so ...
			lastPeriodInBytes = actPeriodInBytes;
			lastPeriodOutBytes = actPeriodOutBytes;
			savedInBytes = sessionInBytes = actPeriodInBytes = 0;
			savedOutBytes = sessionOutBytes = actPeriodOutBytes = 0;
		}
	}

	/*** startday-section ***/
	this.periodStartDay = 1;
	this.setPeriodStartDay = setPeriodStartDay;
	this.setNewPeriodBool = setNewPeriodBool;
	this.getNewPeriodBool = getNewPeriodBool;

	function setNewPeriodBool(myNewPeriodBool){
		if (myNewPeriodBool != undefined && (myNewPeriodBool == true || myNewPeriodBool == false)) newPeriodBool = myNewPeriodBool;
	}
	function getNewPeriodBool(){ return newPeriodBool; }
	
	function setPeriodStartDay(myPeriodStartDay){
		if (myPeriodStartDay != undefined && !isNaN(myPeriodStartDay)) this.periodStartDay = myPeriodStartDay;
	}

	var newPeriodBool = false;
	this.setNextPeriodStart = setNextPeriodStart;
	var myCompareDate = "";

	function setNextPeriodStart(){
		var today = new Date();
		today = new Date(today.getFullYear() , today.getMonth() , today.getDate());

		var myDaysInMonth = new Array(31,28,31,30,31,30,31,31,30,31,30,31)
		if (new Date(today.getYear(),1,29).getDate()==29) myDaysInMonth[1] = 29;

	 	myCompareDate = new Date(today.getFullYear(), today.getMonth(), this.periodStartDay);
		if (myCompareDate.getMonth() != today.getMonth() )	// set VglDate to last day of actual month
			myCompareDate = new Date(today.getFullYear(), today.getMonth(), myDaysInMonth[today.getMonth()]);

		if (today.getDate() == myCompareDate.getDate()){
			showStatus("refreshDate reached");
		 	if (newPeriodBool == false){
				showStatus("new Period begins - reset traffic");
				archiveTrafficData(true);	// arg=1 -> reset traffic-data to a new period
			} else archiveTrafficData(false);
			myCompareDate = setDateToNextMonth(today,this.periodStartDay);
			calcDaysUntilNextPeriodStart(today,myCompareDate);
			newPeriodBool = true;
		} else if (today.getDate() < myCompareDate.getDate()){
			showStatus("today < refreshdate")
			calcDaysUntilNextPeriodStart(today,myCompareDate);
			newPeriodBool = false;
			archiveTrafficData(false);
		} else if (today.getDate() > myCompareDate.getDate()){	// today > myCompareDate
			showStatus("today > refreshdate")
			myCompareDate = setDateToNextMonth(today,this.periodStartDay);
			calcDaysUntilNextPeriodStart(today,myCompareDate);
			newPeriodBool = false;
			archiveTrafficData(false);
		}
	}
	
	function setDateToNextMonth(myDate,myDay){
		var myDaysInMonth = new Array(31,28,31,30,31,30,31,31,30,31,30,31)
		if (new Date(myDate.getYear(),1,29).getDate()==29) myDaysInMonth[1] = 29;

		if (myDate.getMonth() != 11){
			myDummyDate = new Date(myDate.getFullYear(), Number(myDate.getMonth()+1), myDay);
			if (myDummyDate.getMonth()-1 != myDate.getMonth() )
				myDummyDate = new Date(myDate.getFullYear(), myDate.getMonth()+1, myDaysInMonth[myDate.getMonth()+1]);
		} else myDummyDate = new Date( Number(myDate.getFullYear()+1), 0, myDay );
		return myDummyDate;
	}

	function calcDaysUntilNextPeriodStart(myStartDate, myEndDate){
		var myNoOfDays = 0;
		myNoOfDays = Number(myEndDate - myStartDate);
		myNoOfDays = Math.abs(Math.round(myNoOfDays/86400000));
		var myDummyDate = new Date();
		var myDummyDate = new Date(Number(myDummyDate) + (myNoOfDays * 86400000))
		document.getElementById("tf_resetOn").innerHTML= myDummyDate.getDate() + "." + Number(myDummyDate.getMonth()+1) + "." + myDummyDate.getFullYear() + " (" + myNoOfDays + " days" + ")";
		return myNoOfDays;
	}
}