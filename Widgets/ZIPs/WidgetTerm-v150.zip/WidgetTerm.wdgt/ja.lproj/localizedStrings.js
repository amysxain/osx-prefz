
var localizedStrings = {
    "About": "情報",
    "Credit": "クレジット",
    "Done": "完了",
    "License": "ライセンス",
    "Preferences": "設定"
};
