/*
    Loosely based on examples in the Dashboard Programming Guide by Apple Computer Inc.
    Copyright (C) 2005 Ippei Ukai
    Copyright (C) 2005-2009 WidgetTerm Project
    
    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

// - Resizer Class -
// (This class should be used statically)

var Resizer = new function() {

    this.growboxInset = { x: 0, y: 0 };
    
    this.minWidth = 9999;
    this.minHeight = 9999;

    // initialiser
    this.initResizer = Resizer_initResizer;

    // functions
    this.mouseDown = Resizer_mouseDown;
    this.mouseMove = Resizer_mouseMove;
    this.mouseUp = Resizer_mouseUp;
    
    this.onStart = function() {};
    this.onEnd = function() {};

};


function Resizer_initResizer(minWidth, minHeight, onStartHandler, onEndHandler)
{
    Resizer.minWidth  = minWidth;
    Resizer.minHeight = minHeight;
    
    if(onStartHandler != null)
        Resizer.onStart = onStartHandler;
        
    if(onEndHandler != null)
        Resizer.onEnd = onEndHandler;
}


function Resizer_mouseDown(event)
{       
    document.addEventListener("mousemove", Resizer.mouseMove, true);
    document.addEventListener("mouseup", Resizer.mouseUp, true);
    Resizer.growboxInset = { x: (window.innerWidth - event.x), y: (window.innerHeight - event.y) };
    
    Resizer.onStart();
    
    event.stopPropagation();
    event.preventDefault();
}

function Resizer_mouseMove(event)
{
    var x = event.x + Resizer.growboxInset.x;
    var y = event.y + Resizer.growboxInset.y;

    if(x < Resizer.minWidth)  x = Resizer.minWidth;
    if(y < Resizer.minHeight) y = Resizer.minHeight;
    
    window.resizeTo(x,y);
        
    event.stopPropagation();
    event.preventDefault();
}

function Resizer_mouseUp(event)
{
    document.removeEventListener("mousemove", Resizer.mouseMove, true);
    document.removeEventListener("mouseup", Resizer.mouseUp, true); 
    
    Resizer.onEnd();
                
    event.stopPropagation();
    event.preventDefault();
}
