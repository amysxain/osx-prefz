/*
    Loosely based on the Stretcher example by Apple Computer Inc.
    Copyright (C) 2005 Ippei Ukai
    Copyright (C) 2005-2009 WidgetTerm Project
    
    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

// - Stretcher Class -
// (This class should be instantiiated)

/*
 * Stretcher constructor
 * 
 * Parameters:
 *  - element: The element to stretch
 *  - doneNotification: A callback (if no callback is needed, pass null)
 *
 */
function Stretcher(element, collapsed)
{
	this.element = element;

	this.startTime = 0;
	this.timer = null;
	
	// min and max position can be changed to alter the stretched/shrunk sizes.
	this.minPosition = 0.0;
	this.maxPosition = 1.0;
    
	if(collapsed){
        this.positionFrom = this.maxPosition;
        this.positionTo = this.minPosition;
    } else {
        this.positionFrom = this.minPosition;
        this.positionTo = this.maxPosition;
    }
    this.positionNow = this.positionFrom;
	
    this.isCollapsed = collapsed;
	this.stretching = false;
	
	//functions
	// -public
	this.stretch = Stretcher_stretch;
	
	// -private	
	this.doneNotification = null;
	
	this.tick = Stretcher_tick;
	this.limit_3 = Stretcher_limit_3;
	this.computeNextFloat = Stretcher_computeNextFloat;
    
/*
    // bug in WebKit? NSView gets rendered incorrectly after transforming and back.
    this.element.style.webkitTransformOrigin='50% 100%';
    this.updatePosition = function() {
        this.element.style.webkitTransform='scale(1,'+this.positionNow+')';
    };
*/
    // transparent instead of scaling
    this.updatePosition = function() {
        this.element.style.opacity = this.positionNow;
    };
        
    this.updatePosition();
}

/*
 * function stretch
 * 
 * Parameters:
 *  - event: the mouse click that starts everything off (from an onclick handler).
 *		We check for the shift key to do a slo-mo stretch.
 */
function Stretcher_stretch(event, doneNotification) {
	if (this.stretching) return;
    
	this.doneNotification = doneNotification;
	
	var timeNow = (new Date).getTime();
	var multiplier = (event.shiftKey ? 10 : 1); // enable slo-mo
	
	this.stretchTime = 250 * multiplier;
	this.positionFrom = this.positionNow;

	this.positionTo = this.isCollapsed ? this.minPosition : this.maxPosition;
	this.startTime = timeNow - 13; // set it back one frame.
	
	// We need to store this in a local variable so the timer does not lose scope
	// when invoking tick.
	var localThis = this;
	this.stretching = true;
	this.timer = setInterval (function() { localThis.tick(); }, 13);
	this.tick();
}
		
/*
 * Tick does all the incremental resize work.
 */
function Stretcher_tick() {
	var T;
	var ease;
	var time  = (new Date).getTime();
	var yLoc;
	var frame;
		
	T = this.limit_3(time-this.startTime, 0, this.stretchTime);
	ease = 0.5 - (0.5 * Math.cos(Math.PI * T / this.stretchTime));

	if (T >= this.stretchTime) {
		this.positionNow = this.positionTo;
		this.updatePosition();
		
		clearInterval (this.timer);
		this.timer = null;
		this.isCollapsed = !this.isCollapsed;
		if (this.doneNotification) {
			// call after the last frame is drawn
			var localThis = this;
			setTimeout (function() { localThis.doneNotification(); localThis.doneNotification = null;}, 0);
		}
		this.stretching = false;
	} else {
		this.positionNow = this.computeNextFloat(this.positionFrom, this.positionTo, ease);
		this.updatePosition();
	}
}

/*
 * Support functions for the stretch animation
 */
function Stretcher_limit_3(a, b, c) {
    return a < b ? b : (a > c ? c : a);
}

function Stretcher_computeNextFloat(from, to, ease) {
    return from + (to - from) * ease;
}


