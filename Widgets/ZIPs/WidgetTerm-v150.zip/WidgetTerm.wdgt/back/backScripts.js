/*
    Copyright (C) 2005 Ippei Ukai
    Copyright (C) 2005-2009 WidgetTerm Project
    
    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

function link(theLink)
{
    if(parent.widget)
        parent.widget.openURL(theLink);
    else
        window.open(theLink,"");
}

function getProperty(theProperty)
{
    if(!parent.widget)
        return "";
    
    var output = parent.widget.system('/bin/sh -c "defaults read `pwd`/Info '+theProperty+'"', null).outputString;
    output = output.replace(new RegExp ('[\r\n]', 'gi'), '');
    output = unescape(output.replace(new RegExp ('\\\\', 'g'), '%'));
    return output;
}

function getVersionString()
{
    return (parent.widget)? getProperty("CFBundleShortVersionString") : "-.--";
}

function getVersion()
{
    return (parent.widget)? getProperty("CFBundleVersion") : "-.--";
}

function checkWebVersion()
{
    if(getVersion() != '')
    {
        try {
            var webVersion = WT_currentVersion();
            return (webVersion > getVersion())? 1 : 0;
        } catch(e) {}
    }
    
    return -1;
}


function writeVersion()
{
    document.write(getVersionString());
}

function writeUpdateMessage(newestMsg, olderMsg)
{
    switch(checkWebVersion())
    {
        case 0:
            document.write(newestMsg);
            break;
        case 1:
            document.write('<a href="http://sourceforge.net/projects/widgetterm/download">' + olderMsg + '</a>');
            break;
        case -1:
            break;
    }
}