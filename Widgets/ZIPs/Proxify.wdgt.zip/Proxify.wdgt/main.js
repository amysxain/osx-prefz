var aff			= 'widget';
var xkeys		= new Array('rs','fa','br','rt','hb','hc','rc','ri','ff','mc','pc','dm','un','pw');
var defaults	= new Array(0,1,0,0,1,1,0,0,1,0,'https','proxify.com','','');
var rs;
var fa;
var br;
var rt;
var hb;
var hc;
var rc;
var ri;
var ff;
var mc;
var pc;
var dm;
var un;
var pw;

function SaveSettings() {
	if (window.widget) {
		for (var i=0; i<xkeys.length; i++) {
			if (i<10) {
				widget.setPreferenceForKey(gob(xkeys[i]).checked,xkeys[i]);
			} else {
				widget.setPreferenceForKey(gob(xkeys[i]).value,xkeys[i]);
			}
		}
	}
}

function FetchSettings() {
	var pre = new Array();
	if (window.widget) {
		for (var i=0; i<xkeys.length; i++) {
			if (!(widget.preferenceForKey(xkeys[i]) === undefined)) pre.push(widget.preferenceForKey(xkeys[i]));
		}
		if (pre.length !== xkeys.length) pre = false;
	} else {
		pre = false;
	}
	return pre;
}

function gob(id) {
	return document.getElementById(id);
}

function proxify(){
	var pc = gob('pc').value;
	var dm = gob('dm').value;
	var un = gob('un').value;
	var pw = gob('pw').value;
	var url	= gob('url').value;
	var rs_on = (rs.checked)? rs_on=1 : rs_on=0;
	var fa_on = (fa.checked)? fa_on=1 : fa_on=0;
	var br_on = (br.checked)? br_on=1 : br_on=0;
	var rt_on = (rt.checked)? rt_on=1 : rt_on=0;
	var hb_on = (hb.checked)? hb_on=1 : hb_on=0;
	var hc_on = (hc.checked)? hc_on=1 : hc_on=0;
	var rc_on = (rc.checked)? rc_on=1 : rc_on=0;
	var ri_on = (ri.checked)? ri_on=1 : ri_on=0;
	var if_on = (ff.checked)? if_on=1 : if_on=0;
	var mc_on = (mc.checked)? mc_on=1 : mc_on=0;
	if (un&&pw) {pc='https';}
	if (!url.match(/^(http|https|ftp)/i)) {url='http://'+url;}
	var prx	= pc+'://'+dm+'/p/011010A0000110/proxify/widget?rc='+rc_on+'&ri='+ri_on+'&rs='+rs_on+'&fa='+fa_on+'&br='+br_on+'&tr=-&if='+if_on+'&rt='+rt_on+'&mc='+mc_on+'&hb='+hb_on+'&so=0&ov=0&hc='+hc_on+'&af='+aff+'&un='+un+'&pw='+pw+'&url='+url;
	if (window.widget) {
		widget.openURL(prx);
	} else {
		location.href = prx;
	}
}

function showPrefs(){
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	if (window.widget)
		widget.prepareForTransition("ToBack");
	front.style.display="none";
	back.style.display="block";
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);
	document.getElementById('fliprollie').style.display = 'none';
}

function hidePrefs(){
	SaveSettings();
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	if (window.widget)
		widget.prepareForTransition("ToFront");
		back.style.display="none";
		front.style.display="block";
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);
	if(document.pform){document.pform.url.focus();}
}

var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};

function mousemove(event) {
	if (!flipShown) {
		if (animation.timer != null) {
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		var starttime = (new Date).getTime() - 13;
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ("flip");
		animation.timer = setInterval ("animate()", 13);
		animation.from = animation.now;
		animation.to = 1.0;
		animate();
		flipShown = true;
	}
}

function mouseexit(event) {
	if (flipShown) {
		if (animation.timer != null) {
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		var starttime = (new Date).getTime() - 13;
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ("flip");
		animation.timer = setInterval ("animate()", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}

function animate() {
	var T;
	var ease;
	var time = (new Date).getTime();
	T = limit_3(time-animation.starttime, 0, animation.duration);
	if (T >= animation.duration) {
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	} else {
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}
	animation.firstElement.style.opacity = animation.now;
}

function limit_3 (a, b, c) {
	return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease) {
	return from + (to - from) * ease;
}

function enterflip(event) {
	document.getElementById("fliprollie").style.display = "block";
}

function exitflip(event) {
	document.getElementById("fliprollie").style.display = "none";
}

function init() {
	rs	= gob('rs');
	fa 	= gob('fa');
	br 	= gob('br');
	rt 	= gob('rt');
	hb 	= gob('hb');
	hc 	= gob('hc');
	rc 	= gob('rc');
	ri 	= gob('ri');
	ff 	= gob('ff');
	pc 	= gob('pc');
	dm 	= gob('dm');
	un 	= gob('un');
	pw 	= gob('pw');
	mc 	= gob('mc');
	var settings = new Array();
	var prefs	= FetchSettings(); (prefs)? settings=prefs : settings=defaults;
	rs.checked = settings[0];
	fa.checked = settings[1];
	br.checked = settings[2];
	rt.checked = settings[3];
	hb.checked = settings[4];
	hc.checked = settings[5];
	rc.checked = settings[6];
	ri.checked = settings[7];
	ff.checked = settings[8];
	mc.checked = settings[9];
	pc.value   = settings[10];
	dm.value   = settings[11];
	un.value   = settings[12];
	pw.value   = settings[13];
	var submitbt = document.getElementById('submitbt'); createGenericButton(submitbt, 'Go', proxify);
	var donebt = document.getElementById('donebt'); 	createGenericButton(donebt, 'Done', hidePrefs);
	var resetbt = document.getElementById('resetbt');	createGenericButton(resetbt, 'Restore Defaults', reset_to_defaults);
}

function reset_to_defaults() {
	rs.checked = defaults[0];
	fa.checked = defaults[1];
	br.checked = defaults[2];
	rt.checked = defaults[3];
	hb.checked = defaults[4];
	hc.checked = defaults[5];
	rc.checked = defaults[6];
	ri.checked = defaults[7];
	ff.checked = defaults[8];
	mc.checked = defaults[9];
	pc.value   = defaults[10];
	dm.value   = defaults[11];
	un.value   = defaults[12];
	pw.value   = defaults[13];
}

function handleHide() {
	SaveSettings();
}

window.onload = init;

if (window.widget) {
	widget.onhide = handleHide;
}
