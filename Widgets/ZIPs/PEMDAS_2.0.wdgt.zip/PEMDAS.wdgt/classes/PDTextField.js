function PDTextField()
{
var cursorDiv;
var displayDiv;
var parentDiv;
var hiddenSpan;
var canvas;
var lengthToCursorIndex=new Array();
lengthToCursorIndex[0]=0.0;
var boxOffset=0; 
var boxLeftOrigin=0; 
var parentBoxWidth=0;
var selectionLocation=0;
var selectionLength=0; 
var formulaHasChanged=true; 
var mainString="";
var yankedString="";
var displaySize=0;
var self=this;
var previousKeyEntered=0; 
var previousKeyTimer=0;
var isEnabled=1; 
var useMultiplicationDot=0;
var cursorWidth=1;
var fontSize;
var hasBodyDelegate=0;
var commaLocale=0;
var justCalculatedEquation=0;
this.initWithDivsAndSize=function(newCursorDiv, newDisplayDiv, newParentDiv, newHiddenSpan, newFontSize, newCanvas) {
cursorDiv=newCursorDiv;
displayDiv=newDisplayDiv;
parentDiv=newParentDiv;
hiddenSpan=newHiddenSpan;
canvas=newCanvas;
fontSize=newFontSize;
parentBoxWidth=parseInt(parentDiv.style.width);
cursorDiv.style.width=1;
cursorDiv.style.height=fontSize+2; 
cursorDiv.style.top=parseInt(parentDiv.style.top, 10); 
boxLeftOrigin=parseInt(parentDiv.style.left);
cursorDiv.style.left=boxLeftOrigin;
displayDiv.style.fontSize=newFontSize+'px';
hiddenSpan.style.fontSize=newFontSize+'px';
document.addEventListener("keydown", self.keyDowned, true);
document.addEventListener("keypress", self.keyPressed, true); 
parentDiv.addEventListener("mousedown", self.handleMouseDownEvent, true);
cursorDiv.addEventListener("mousedown", self.handleMouseDownEvent, true);
}
this.setCommaLocale=function(newCommaLocale) {
if (newCommaLocale==commaLocale) {
return;
}
commaLocale=newCommaLocale;
}
this.insertString=function(newString) {
if (isEnabled!=1) { 
return;
}
var mainStringLength=mainString.length;
hiddenSpan.innerHTML=newString;
newString=hiddenSpan.innerHTML;
var tempWidth=displayDiv.offsetWidth; 
mainString=mainString.substring(0, selectionLocation)+newString.toString()+mainString.substring(selectionLocation+selectionLength, mainStringLength);
selectionLocation+=newString.length;
selectionLength=0;
formulaHasChanged=true;
justCalculatedEquation=0;
self.refreshArrayValuesForNewString();
self.mainStringValueChanged();
self.refreshDisplay();
}
this.replaceStringWithString=function(newString) {
if (isEnabled!=1) {
return;
}
hiddenSpan.innerHTML=newString;
newString=hiddenSpan.innerHTML;
mainString=newString;
selectionLocation=mainString.length;
selectionLength=0;
formulaHasChanged=true;
self.refreshArrayValuesForNewString();
self.mainStringValueChanged();
self.refreshDisplay();
}
this.deleteForward=function() {
if (selectionLength!=0) {
self.insertString("");
return;
}
if (selectionLocation<mainString.length) {
mainString=mainString.substring(0,selectionLocation)+mainString.substring(selectionLocation+1, mainString.length); 
}
formulaHasChanged=true;
self.refreshArrayValuesForNewString();
self.mainStringValueChanged();
self.refreshDisplay();
}
this.deleteBackward=function() { 
if (selectionLength!=0) {
self.insertString("");
return;
}
if (mainString.length>0 && selectionLocation>0) {
mainString=mainString.substring(0,selectionLocation-1)+mainString.substring(selectionLocation, mainString.length); 
selectionLocation--; 
}
formulaHasChanged=true;
self.refreshArrayValuesForNewString();
self.mainStringValueChanged();
self.refreshDisplay();
}
this.mainStringValueChanged=function() { 
self.refreshMainStringDisplay();
if (hasBodyDelegate) {
formulaDidChange();
}
}
this.stringValue=function() {
return mainString;
}
this.stringForCopying=function() { 
if (selectionLength) {
return mainString.substr(selectionLocation,selectionLength);
}
return mainString;
}
this.refreshArrayValuesForNewString = function() {
var i, iLength=mainString.length;
var currentChar;
hiddenSpan.innerHTML='';
for (i=0; i<iLength; i++) {
currentChar=mainString.charAt(i);
if (currentChar==' ') {
hiddenSpan.innerHTML+='&nbsp;';
} else {
hiddenSpan.innerHTML+=currentChar;
}
lengthToCursorIndex[i+1]=hiddenSpan.offsetWidth;
}
}
this.refreshArrayValuesForStringAddedToEndOfPreviousString = function(previousStringLength) {
var i, iLength=mainString.length;
for (i=previousStringLength+1; i<=iLength; i++) {
hiddenSpan.innerHTML=mainString.substring(0,i);
lengthToCursorIndex[i]=hiddenSpan.offsetWidth;
}
}
this.refreshArrayValuesAfterInsertingStringLength = function(newStringLength, insertionIndex, previousStringLength) {
if (previousStringLength==0) { 
self.refreshArrayValuesForNewString();
return;
}
if (insertionIndex==previousStringLength) { 
self.refreshArrayValuesForStringAddedToEndOfPreviousString(previousStringLength);
return;
}
self.refreshArrayValuesForNewString();
}
this.moveCursorForward=function() {
if (selectionLength>0) { 
selectionLocation+=selectionLength;
selectionLength=0;
} else if (selectionLocation<mainString.length) { 
selectionLocation++;
}
self.refreshDisplay();
}
this.moveCursorBackward=function() {
if (selectionLength>0) { 
selectionLength=0;
} else if (selectionLocation>0) { 
selectionLocation--;
}
self.refreshDisplay();
}
this.moveCursorToBeginning=function() {
if (selectionLength!=0) { 
selectionLength=0;
}
selectionLocation=0;
self.refreshDisplay();
}
this.moveCursorToEnd=function() {
if (selectionLength!=0) { 
selectionLength=0;
}
selectionLocation=mainString.length;
self.refreshDisplay();
}
this.refreshDisplay=function() {
var cursorPixelLocation=0;
cursorPixelLocation=Math.round(lengthToCursorIndex[selectionLocation]-boxOffset);
if (selectionLength) {
} else if (cursorPixelLocation<0) { 
boxOffset=Math.round(lengthToCursorIndex[selectionLocation]);
cursorPixelLocation=Math.round(lengthToCursorIndex[selectionLocation]-boxOffset);
if (cursorPixelLocation<0) { 
boxOffset=boxOffset-1;
}
} else if (cursorPixelLocation>(parentBoxWidth-1)) { 
boxOffset=Math.round(lengthToCursorIndex[selectionLocation]-(parentBoxWidth-1));
cursorPixelLocation=Math.round(lengthToCursorIndex[selectionLocation]-boxOffset);
if (cursorPixelLocation>(parentBoxWidth-1)) { 
boxOffset=boxOffset+1;
}
}
cursorPixelLocation=Math.round(boxLeftOrigin+lengthToCursorIndex[selectionLocation]-boxOffset);
cursorDiv.style.left=cursorPixelLocation;
displayDiv.style.left=-boxOffset;
if (selectionLength!=0) {
self.hideCursor();
} else {
self.showCursor();
}
self.drawSelectedRange(); 
}
this.refreshMainStringDisplay=function() { 
displayDiv.innerHTML=mainString.replace(/ /g, '&nbsp;');;
}
this.drawSelectedRange=function() {
var context = canvas.getContext("2d");
if (selectionLength==0) {
context.clearRect(0, 0, parentBoxWidth, 30);
return;
}
var startLocation=Math.round(lengthToCursorIndex[selectionLocation]-boxOffset);
var endLocation=Math.round(lengthToCursorIndex[selectionLocation+selectionLength]-boxOffset);
context.fillStyle = "rgba(0, 0, 0, 1.0)";
var drawingRadius=3.0;
var boxYOrigin=0.0;
var boxHeight=17.0;
context.fillRect(startLocation, boxYOrigin, endLocation-startLocation, boxHeight);  
}
this.showCursor=function(number) {
cursorDiv.style.display="block";
}
this.hideCursor=function(number) {
cursorDiv.style.display="none";
}
this.setWidth=function(newWidth) { 
var oldWidth=parentBoxWidth;
var deltaWidth=newWidth-oldWidth;
var mainStringLength=mainString.length;
if (deltaWidth==0) { 
return;
}
if (deltaWidth>0 && boxOffset>0 && Math.round(lengthToCursorIndex[mainStringLength]-lengthToCursorIndex[selectionLocation])<newWidth) { 
boxOffset-=deltaWidth; 
if (boxOffset<0) {
boxOffset=0;
}
} else if (deltaWidth<0 && Math.round(lengthToCursorIndex[selectionLocation]-boxOffset+cursorWidth)>newWidth) {
boxOffset+=Math.round(lengthToCursorIndex[selectionLocation]-boxOffset+cursorWidth)-newWidth; 
}
parentDiv.style.width=newWidth+'px';
canvas.width=newWidth;
parentBoxWidth=newWidth;
self.refreshDisplay();
}
this.recievedFocus=function() {
if (selectionLength==0) { 
self.showCursor();
}
canvas.style.opacity=1.0; 
}
this.lostFocus=function () {
if (selectionLength==0) {
self.hideCursor();
} else {
canvas.style.opacity=0.3;
}
}
this.hideSelectedRange=function() {
cursorDiv.style.visibility="hidden";
canvas.style.visibility="hidden";
}
this.showSelectedRange=function() {
cursorDiv.style.visibility="visible";
canvas.style.visibility="visible";
}
this.keyDowned=function(event) {
if (isEnabled!=1) {
return;
}
var recognizedKey=0;
if (event.shiftKey) {
switch (event.keyCode) {
case 38:
self.handleKeyPressCode(-63232); 
recognizedKey=1;
break;
case 40:
self.handleKeyPressCode(-63233); 
recognizedKey=1;
break;
case 37: 
self.handleKeyPressCode(-63234);
recognizedKey=1;
break;
case 39: 
self.handleKeyPressCode(-63235);
recognizedKey=1;
break;
}
} else {
switch(event.keyCode) {
case 37: 
self.handleKeyPressCode(2); 
recognizedKey=1;
break;
case 38: 
self.handleKeyPressCode(1); 
recognizedKey=1;
break;
case 39: 
self.handleKeyPressCode(6); 
recognizedKey=1;
break;
case 40: 
self.handleKeyPressCode(5); 
recognizedKey=1;
break;
}
}
if (recognizedKey) {
event.preventDefault();
}
}
this.keyPressed=function(event) {
if (isEnabled!=1) {
return;
}
if (event.metaKey && event.charCode==97) {  
selectionLocation=0;
selectionLength=mainString.length;
self.refreshDisplay();
event.preventDefault();
return;
}
if (event.metaKey) {  
return;
}
if (event.shiftKey && event.charCode==8) { 
self.handleKeyPressCode(63289);
event.preventDefault();
return;
}
self.handleKeyPressCode(event.charCode);
event.preventDefault();
}
this.addAnswerToEquationIfNecessary=function() {
if (justCalculatedEquation) {
self.replaceStringWithString("ans");
}
}
this.handleKeyPressCode=function(keyPressedCode) {
if (isEnabled!=1) {
return;
}
var formulaLength;
var stringToAdd="";
if (keyPressedCode==3 || keyPressedCode==13) {
if (hasBodyDelegate) {
debugClearConsole();
equationEntered();
}
formulaHasChanged=true;
} else if (keyPressedCode==63289 || keyPressedCode==27) { 
if (previousKeyEntered==63289 || previousKeyEntered==27) {
if (hasBodyDelegate) {
resetWidget();
}
} else {
self.replaceStringWithString("");
}
formulaHasChanged=true;
} else if (keyPressedCode==63272 || keyPressedCode==4) { 
self.deleteForward();
formulaHasChanged=true;
} else if (keyPressedCode==-63234) { 
globalPreferenceController.decrementPreferencesNumberFormattingType();
} else if (keyPressedCode==-63235) { 
globalPreferenceController.incrementPreferencesNumberFormattingType();
} else if (keyPressedCode==2) { 
self.moveCursorBackward();
} else if (keyPressedCode==6) { 
self.moveCursorForward();
} else if (keyPressedCode==1) {
self.moveCursorToBeginning();
} else if (keyPressedCode==5) { 
self.moveCursorToEnd();
} else if (keyPressedCode==-63232 || keyPressedCode==16) {
if (hasBodyDelegate) {
scrollToPreviousFormlua();
}
} else if (keyPressedCode==-63233 || keyPressedCode==14) { 
if (hasBodyDelegate) {
scrollToNextFormula();
}
} else if (keyPressedCode==8) { 
self.deleteBackward();
} else if ((keyPressedCode>47 && keyPressedCode<58) || (keyPressedCode>64 && keyPressedCode<91) || (keyPressedCode>96 && keyPressedCode<123) || (keyPressedCode>191 && keyPressedCode<256 && keyPressedCode!=215 && keyPressedCode!=237) || (keyPressedCode>=1024 && keyPressedCode<=1153) || (keyPressedCode>=1162 && keyPressedCode<=1279)) { 
stringToAdd=String.fromCharCode(keyPressedCode);
if (justCalculatedEquation && stringToAdd) {
self.replaceStringWithString("");
}
self.insertString(stringToAdd);
} else { 
if (justCalculatedEquation) {
self.replaceStringWithString("");
}
switch(keyPressedCode)
{
case 32: 
stringToAdd=' ';
break; 
case 37: stringToAdd='%'; break;
case 40: stringToAdd='('; break;
case 41: stringToAdd=')'; break;
case 42: stringToAdd='*';
self.addAnswerToEquationIfNecessary();
if (useMultiplicationDot==1) {
stringToAdd='&#8901;';
}
break;
case 43: stringToAdd='+';
self.addAnswerToEquationIfNecessary();
break;
case 44: 
if (commaLocale) {
stringToAdd=','; 
} else { 
stringToAdd='.'; 
}
break;
case 45: stringToAdd='-';
self.addAnswerToEquationIfNecessary();
break;
case 46: 
if (commaLocale) {
stringToAdd=','; 
} else { 
stringToAdd='.'; 
}
break;
case 47: stringToAdd='/'; 
self.addAnswerToEquationIfNecessary();
break;
case 61: stringToAdd='='; break;
case 94: case 0: stringToAdd='^'; 
self.addAnswerToEquationIfNecessary();
break;
}
if (stringToAdd!="") {
self.insertString(stringToAdd);
}
}
if (keyPressedCode!=3 && keyPressedCode!=13 && keyPressedCode!=61) {
self.setJustCalculatedEquation(0);
}
previousKeyEntered=keyPressedCode;
if (previousKeyTimer!=0) {
clearTimeout(previousKeyTimer);
}
previousKeyTimer=setTimeout("mainTextField.setPreviousKeyEntered(0);", 400);
}
this.setPreviousKeyEntered=function(newPreviousKeyEntered) { 
previousKeyEntered=newPreviousKeyEntered;
}
this.handleMouseDownEvent=function(event) {
self.setJustCalculatedEquation(0);
if (event.detail==2) {
self.handleDoubleMouseDownEvent(event);
return;
}
if (event.detail==3) { 
selectionLocation=0;
selectionLength=mainString.length;
self.refreshDisplay();
return;
}
var clickLocationInWindow=event.pageX;
selectionLocation=self.cursorIndexForPointInWindow(clickLocationInWindow);
selectionLength=0;
self.refreshDisplay();
if (hasBodyDelegate) {
textFieldWasClicked();
}
}
this.handleDoubleMouseDownEvent=function(event) {
var clickLocationInWindow=event.pageX;
var selectedCharacterIndex=self.characterIndexForPointInWindow(clickLocationInWindow);
var selectedRange=self.rangeToSelectFromInitialCharacter(selectedCharacterIndex)
selectionLocation=selectedRange.getLocation();
selectionLength=selectedRange.getLength();		
self.refreshDisplay();
}
this.characterIndexForPointInWindow =function (pointInWindow) {
var adjustedClickLocationInTextBox=pointInWindow+boxOffset-boxLeftOrigin;
var mainStringLength=mainString.length;
if (adjustedClickLocationInTextBox<0.0) { 
return 0;
}
var i;
for (i=mainStringLength-1; i>=0; i--) { 
if (adjustedClickLocationInTextBox>=lengthToCursorIndex[i]) {
return i;
}
}
return 0;
}
this.cursorIndexForPointInWindow = function(pointInWindow) {
var adjustedClickLocationInTextBox=pointInWindow+boxOffset-boxLeftOrigin;
var mainStringLength=mainString.length;
if (adjustedClickLocationInTextBox<0.0) { 
return 0;
}
if (adjustedClickLocationInTextBox>=lengthToCursorIndex[mainStringLength]) { 
return mainStringLength;
}
var i;
for (i=mainStringLength-1; i>=0; i--) { 
if (adjustedClickLocationInTextBox>=lengthToCursorIndex[i]) {
if ((adjustedClickLocationInTextBox-lengthToCursorIndex[i])/(lengthToCursorIndex[i+1]-lengthToCursorIndex[i])>0.5) { 
return (i+1);
} else {
return i;
}
}
}
return 0;
}
this.setFontSize=function(newFontSize) {
}
this.setHasBodyDelegate=function(newHasBodyDelegate) {
hasBodyDelegate=newHasBodyDelegate;
}
this.setIsEnabled = function(newIsEnabled) {
isEnabled=newIsEnabled;
}
this.getIsEnabled = function() {
return isEnabled;
}
this.setUseMultiplicationDot=function(newUseMultiplicationDot) {
useMultiplicationDot=newUseMultiplicationDot;
}
this.getUseMultiplicationDot = function() {
return useMultiplicationDot;
}
this.setJustCalculatedEquation=function(newJustCalculatedEquation) {
if (justCalculatedEquation!=newJustCalculatedEquation) { 
justCalculatedEquation=newJustCalculatedEquation
if (hasBodyDelegate) { 
justCalculatedEquationDidChange();
}
}
}
this.getJustCalculatedEquation=function() {
return justCalculatedEquation;
}
this.rangeToSelectFromInitialCharacter=function(initialCharacterIndex) {
var rangeToReturn=new PDRange();
var i, endLocation
var currentCharCode=mainString.charCodeAt(initialCharacterIndex);
if (self.textFieldIsVariableDelimiter(currentCharCode)) {
rangeToReturn.location=initialCharacterIndex;
rangeToReturn.length=1;
return rangeToReturn;
}
endLocation=self.nextDelimiterFromInitialLocation(initialCharacterIndex+1)-1;
rangeToReturn.location=self.previousDelimiterFromInitialLocation(initialCharacterIndex-1)+1;
rangeToReturn.length=endLocation-rangeToReturn.location+1;
return rangeToReturn;
}
this.rangeInWindowForSelectedRange=function(selectedRangeToLookAt) {
var rangeToReturn=new PDRange();
rangeToReturn.location=lengthToCursorIndex[selectedRangeToLookAt.location]-boxOffset+boxLeftOrigin;
rangeToReturn.length=lengthToCursorIndex[selectedRangeToLookAt.location+selectedRangeToLookAt.length]-lengthToCursorIndex[selectedRangeToLookAt.location];
return rangeToReturn;
}
this.nextDelimiterFromInitialLocation=function(initialCharacterIndex) { 
var i, currentCharCode;
var mainStringLength=mainString.length;
for (i=initialCharacterIndex; i<mainStringLength; i++) {
currentCharCode=mainString.charCodeAt(i);
if (self.textFieldIsVariableDelimiter(currentCharCode)) {
return i;
}
}
return 	mainStringLength;
}
this.previousDelimiterFromInitialLocation=function(initialCharacterIndex) {
var i, currentCharCode;
for (i=initialCharacterIndex; i>=0; i--) {
currentCharCode=mainString.charCodeAt(i);
if (self.textFieldIsVariableDelimiter(currentCharCode)) {
return i;
}
}
return -1; 
}
this.textFieldIsVariableDelimiter=function(charCodeToCheck) { 
if (charCodeToCheck==42 || charCodeToCheck==43 || charCodeToCheck==45 || charCodeToCheck==47 || charCodeToCheck==94 || charCodeToCheck==37 || charCodeToCheck==8901) {
return 1;
}
if (charCodeToCheck==40 || charCodeToCheck==41 || charCodeToCheck==61 || charCodeToCheck==44 || charCodeToCheck==37 || charCodeToCheck==32 || charCodeToCheck==160) {
return 1;
}
return 0;
}
}