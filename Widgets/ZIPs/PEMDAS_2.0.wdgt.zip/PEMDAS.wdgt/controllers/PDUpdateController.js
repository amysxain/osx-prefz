var globalUpdateController;
function PDUpdateController() {
var newestRevision;
var lastCheckedTime=0, updateXMLHttpRequest;
var newestRevesionReleaseMessage="", currentReleaseURL="";
var newestRevisionNumber=1000000;
var self=this;
var preferencesCheckForUpdates=1;
var preferencesSkipUpdateToRevision=-1;
this.setPreferencesCheckForUpdates=function(newPreferencesCheckForUpdates) {
preferencesCheckForUpdates=newPreferencesCheckForUpdates;
}
this.setPreferencesSkipUpdateToRevision=function(newPreferencesSkipUpdateToRevision) {
preferencesSkipUpdateToRevision=newPreferencesSkipUpdateToRevision;
}
this.checkForUpdates=function() {
if (!preferencesCheckForUpdates) {
return;
}
var currentTime=new Date();
currentTime=parseFloat(currentTime.getTime())/1000;
if ((currentTime-lastCheckedTime)>259200) { 
self.startXMLRequest();
lastCheckedTime=new Date();
lastCheckedTime=parseFloat(lastCheckedTime.getTime())/1000; 
}
}
this.startXMLRequest=function()
{
updateXMLHttpRequest = new XMLHttpRequest();
updateXMLHttpRequest.onreadystatechange = self.finishXMLRequest; 
updateXMLHttpRequest.overrideMimeType("text/xml");
updateXMLHttpRequest.open("GET", "http://updates.donkeyengineering.com/pemdaswidget/pemdas2_0.php?r=200");
updateXMLHttpRequest.send();
}
this.finishXMLRequest=function()
{
if (updateXMLHttpRequest.readyState == 4) {
if (updateXMLHttpRequest.status == 200) { 
self.parseXMLData();
}
}	
}
this.parseXMLData=function() {	
var pemdasVersionData = self.findXMLChild(updateXMLHttpRequest.responseXML, "pemdasVersionData");
if (!pemdasVersionData) { 
return;
}
var currentVersionInfo = self.findXMLChild(pemdasVersionData, "currentVersionInfo");
if (!currentVersionInfo) { 
return;
}
var xmlElementArray=currentVersionInfo.attributes;
var attributesArray=new Array();
var i;
var iLength=xmlElementArray.length;
for (i=0; i<iLength; i++) {
attributesArray[xmlElementArray[i].name]=xmlElementArray[i].value;
}
newestRevisionNumber=parseInt(attributesArray["revision"]);
PDULatestRevision=newestRevisionNumber;
newestRevesionReleaseMessage=attributesArray["updatemessage"];
currentReleaseURL=attributesArray["releaseurl"];
if (globalRevisionNumber<newestRevisionNumber && newestRevisionNumber!=preferencesSkipUpdateToRevision) {
PDUShowUpdateDiv();
}
}
this.findXMLChild=function(element, nodeName) {
var child;
for (child = element.firstChild; child != null; child = child.nextSibling) {
if (child.nodeName == nodeName) {
return child;
}
}
return false;
}
this.getNewestRevesionReleaseMessage=function() {
return newestRevesionReleaseMessage;
}
this.getCurrentReleaseURL=function() {
return currentReleaseURL;
}
this.getNewestRevisionNumber=function() {
return newestRevisionNumber;
}
}