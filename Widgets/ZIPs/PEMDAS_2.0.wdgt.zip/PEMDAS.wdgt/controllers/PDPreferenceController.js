var globalPreferenceController;
function PDPreferenceController() {
var preferencesRadians=1; 
var preferencesPercentIsModulus=0;
var preferencesMultiplicationSymbol=0; 
var preferencesNumberFormattingType=1; 
var preferencesSigfigDecimalComboIndex=0; 
var preferencesThousandsSeperators=1; 
var preferencesCheckForUpdates=1;
var preferencesSkipUpdateToRevision=-1; 
var runtimePreferencesWhatToCopy=1; 
var preferencesExpandedWidth=323;
var preferencesExpandedHeight=235;
var preferencesKeypadIsHidden=0;
var runtimePreferenceCommaLocale=0; 
var preferencesDecimalCharacter='.';
var preferencesSeperatorCharacter=',';
var globalEquationControllerExists=1;
var globalNumberFormatterExists=1;
var self=this;
var hasBodyDelegate=1;
this.loadPreferences=function() {
var tempPreference=-1;
var upgradingFromVersion1=0;
if (!window.widget) { 
return;
}
tempPreference=parseInt(widget.preferenceForKey("thisVersionNumber"));
if (!isNaN(tempPreference) && tempPreference!=-1 && tempPreference!=0) {
upgradingFromVersion1=1;
widget.setPreferenceForKey(-1,"thisVersionNumber");
}
widget.setPreferenceForKey(globalVersionNumber,"versionNumber");
widget.setPreferenceForKey(globalRevisionNumber,"revisionNumber");
if (upgradingFromVersion1) {
tempPreference=parseInt(widget.preferenceForKey("preferencesAnswerFormatting"));
widget.setPreferenceForKey(-1,"preferencesAnswerFormatting");
} else {
tempPreference=parseInt(widget.preferenceForKey("preferencesNumberFormattingType"));
}
if (!isNaN(tempPreference) && tempPreference>=1 && tempPreference<=7) { 
preferencesNumberFormattingType=tempPreference;
syncNumberFormattingTypeWithPreferences(0);
}
if (upgradingFromVersion1) {
tempPreference=parseInt(widget.preferenceForKey("preferencesPrecision"));
widget.setPreferenceForKey(-1,"preferencesPrecision");
} else {
tempPreference=parseInt(widget.preferenceForKey("preferencesSigfigDecimalComboIndex"));
}
if (!isNaN(tempPreference) && (tempPreference>=0 && tempPreference<=21)) {
preferencesSigfigDecimalComboIndex=tempPreference;
syncSigfigDecimalComboWithPreferences(0);
}
tempPreference=parseInt(widget.preferenceForKey("preferencesRadians"));
if (!isNaN(tempPreference) && (tempPreference==0 || tempPreference==1)) {
preferencesRadians=tempPreference;
syncDegreesRadiansWithPreferences();			
}
if (upgradingFromVersion1) {
tempPreference=parseInt(widget.preferenceForKey("preferencesProgrammerMode"));
widget.setPreferenceForKey(-1,"preferencesProgrammerMode");
} else {
tempPreference=parseInt(widget.preferenceForKey("preferencesPercentIsModulus"));
}
if (!isNaN(tempPreference) && (tempPreference==0 || tempPreference==1)) {
preferencesPercentIsModulus=tempPreference;
syncePercentIsModulusWithPreferences();			
}
tempPreference=parseInt(widget.preferenceForKey("preferencesThousandsSeperators"));
if (!isNaN(tempPreference) && (tempPreference==0 || tempPreference==1)) { 
preferencesThousandsSeperators=tempPreference;
syncThousandsSeparatorWithPreferences(0); 
}
tempPreference=parseInt(widget.preferenceForKey("preferencesCheckForUpdates"));
if (!isNaN(tempPreference) && (tempPreference==0 || tempPreference==1)) { 
preferencesCheckForUpdates=tempPreference;
syncCheckForUpdatesWithPreferences();
globalUpdateController.setPreferencesCheckForUpdates(preferencesCheckForUpdates);
}
tempPreference=parseInt(widget.preferenceForKey("preferencesSkipUpdateToRevision"));
if (!isNaN(tempPreference)) { 
preferencesSkipUpdateToRevision=tempPreference;
globalUpdateController.setPreferencesSkipUpdateToRevision(preferencesSkipUpdateToRevision);
}
tempPreference=parseInt(widget.preferenceForKey("preferencesMultiplicationSymbol"));
if (!isNaN(tempPreference) && (tempPreference==0 || tempPreference==1)) { 
preferencesMultiplicationSymbol=tempPreference;
syncMultiplicationSymbolWithPreferences();
}
self.loadPreferencesCommaLocale();
self.setPreferencesCommaLocale(runtimePreferenceCommaLocale);
numberFormattingDidChange();
}
this.setPreferencesRadians=function(newPreferencesRadians) {
if(newPreferencesRadians!=0 && newPreferencesRadians!=1) { 
return;
}
preferencesRadians=newPreferencesRadians;
if (window.widget) {
widget.setPreferenceForKey(preferencesRadians,"preferencesRadians");
}
}
this.getPreferencesRadians=function() {
return preferencesRadians;
}
this.setPreferencesNumberFormattingType=function(newNumberFormattingType) { 
if(isNaN(newNumberFormattingType) || newNumberFormattingType<1 || newNumberFormattingType>7) {
return;
}
preferencesNumberFormattingType=newNumberFormattingType;
if (window.widget) {
widget.setPreferenceForKey(preferencesNumberFormattingType,"preferencesNumberFormattingType");
}
}
this.getPreferencesNumberFormattingType=function() {
return preferencesNumberFormattingType;
}
this.incrementPreferencesNumberFormattingType=function() {
var newPreferencesNumberFormattingType=preferencesNumberFormattingType+1;
if (newPreferencesNumberFormattingType>7) {
newPreferencesNumberFormattingType=1;
}
self.setPreferencesNumberFormattingType(newPreferencesNumberFormattingType)
if (hasBodyDelegate) {
syncNumberFormattingTypeWithPreferences(1);
}
}
this.decrementPreferencesNumberFormattingType=function() {
var newPreferencesNumberFormattingType=preferencesNumberFormattingType-1;
if (newPreferencesNumberFormattingType<1) {
newPreferencesNumberFormattingType=7;
}
self.setPreferencesNumberFormattingType(newPreferencesNumberFormattingType)
if (hasBodyDelegate) {
syncNumberFormattingTypeWithPreferences(1);
}
}
this.setPreferencesPercentIsModulus=function(newPreferencesPercentIsModulus) {
if(newPreferencesPercentIsModulus!=0 && newPreferencesPercentIsModulus!=1) {
newPreferencesPercentIsModulus=0;
}
preferencesPercentIsModulus=newPreferencesPercentIsModulus;
if (window.widget) {
widget.setPreferenceForKey(preferencesPercentIsModulus,"preferencesPercentIsModulus");
}
}
this.getPreferencesPercentIsModulus=function() {
return preferencesPercentIsModulus;
}
this.setPreferencesMultiplicationSymbol=function(newPreferencesMultiplicationSymbol) {
if(newPreferencesMultiplicationSymbol!=0 && newPreferencesMultiplicationSymbol!=1) {
newPreferencesMultiplicationSymbol=0;
}
preferencesMultiplicationSymbol=newPreferencesMultiplicationSymbol;
if (window.widget) {
widget.setPreferenceForKey(preferencesMultiplicationSymbol,"preferencesMultiplicationSymbol");
}
}
this.getPreferencesMultiplicationSymbol=function() {
return preferencesMultiplicationSymbol;
}
this.setPreferencesCheckForUpdates=function(newPreferencesCheckForUpdates) {
if (newPreferencesCheckForUpdates!=0 && newPreferencesCheckForUpdates!=1) {
return; 
}
preferencesCheckForUpdates=newPreferencesCheckForUpdates;
globalUpdateController.setPreferencesCheckForUpdates(preferencesCheckForUpdates);
if (window.widget) {
widget.setPreferenceForKey(preferencesCheckForUpdates,"preferencesCheckForUpdates");
if (newPreferencesCheckForUpdates==1) {
self.setPreferencesSkipUpdateToRevision(-1);
}
}
}
this.getPreferencesCheckForUpdates=function() {
return preferencesCheckForUpdates;
}
this.setPreferencesSkipUpdateToRevision=function(newPreferencesSkipUpdateToRevision) {
preferencesSkipUpdateToRevision=newPreferencesSkipUpdateToRevision;
globalUpdateController.setPreferencesSkipUpdateToRevision(preferencesSkipUpdateToRevision);
if (window.widget) {
widget.setPreferenceForKey(preferencesSkipUpdateToRevision,"preferencesSkipUpdateToRevision");
}
}
this.getPreferencesSkipUpdateToRevision=function() {
return preferencesSkipUpdateToRevision;
}
this.setPreferencesSigfigDecimalComboIndex=function(newPreferencesSigfigDecimalComboIndex) {
if (newPreferencesSigfigDecimalComboIndex<0 || newPreferencesSigfigDecimalComboIndex>21) { 
return;
}
preferencesSigfigDecimalComboIndex=newPreferencesSigfigDecimalComboIndex;
if (window.widget) {
widget.setPreferenceForKey(preferencesSigfigDecimalComboIndex,"preferencesSigfigDecimalComboIndex");
}
}
this.getPreferencesSigfigDecimalComboIndex=function() {
return preferencesSigfigDecimalComboIndex;
}
this.getPreferencesSignificantFigures=function() { 
var preferencesSignificantFiguresReference=-1;
if (preferencesSigfigDecimalComboIndex>0 && preferencesSigfigDecimalComboIndex<11) { 
preferencesSignificantFiguresReference=preferencesSigfigDecimalComboIndex;
}
return preferencesSignificantFiguresReference;
}
this.getPreferencesDecimalPlaces=function() { 
var preferencesDecimalPlacesReference=-1;
if (preferencesSigfigDecimalComboIndex>10 && preferencesSigfigDecimalComboIndex<22) {
preferencesDecimalPlacesReference=preferencesSigfigDecimalComboIndex-11;
}
return preferencesDecimalPlacesReference;
}
this.setPreferencesThousandsSeparators=function(newPreferencesThousandsSeperators) {
if (newPreferencesThousandsSeperators!=0 && newPreferencesThousandsSeperators!=1) { 
return;
}
preferencesThousandsSeperators=newPreferencesThousandsSeperators;
if (window.widget) {
widget.setPreferenceForKey(preferencesThousandsSeperators,"preferencesThousandsSeperators");
}
}
this.getPreferencesThousandsSeparators=function() {
return preferencesThousandsSeperators;
}
this.setPreferencesExpandedWidth=function(newPreferencesExpandedWidth) {
preferencesExpandedWidth=newPreferencesExpandedWidth;
if (window.widget) {
widget.setPreferenceForKey(preferencesExpandedWidth,"preferencesExpandedWidth");
}
}
this.getPreferencesExpandedWidth=function() {
return preferencesExpandedWidth;
}
this.setPreferencesExpandedHeight=function(newPreferencesExpandedHeight) {
preferencesExpandedHeight=newPreferencesExpandedHeight;
if (window.widget) {
widget.setPreferenceForKey(preferencesExpandedHeight,"preferencesExpandedHeight");
}
}
this.getPreferencesExpandedHeight=function() {
return preferencesExpandedHeight;
}
this.setPreferencesKeypadIsHidden=function(newPreferencesKeypadIsHidden) {
if (newPreferencesKeypadIsHidden!=0 && newPreferencesKeypadIsHidden!=1) {
newPreferencesKeypadIsHidden=0;
}
preferencesKeypadIsHidden=newPreferencesKeypadIsHidden;
if (window.widget) {
widget.setPreferenceForKey(preferencesKeypadIsHidden,"preferencesKeypadIsHidden");
}
}
this.getPreferencesKeypadIsHidden=function() {
return preferencesKeypadIsHidden;
}
this.loadPreferencesCommaLocale=function() { 
if (window.widget) {
try {
var calc=widget.calculator;
gDecimalSeparator = calc.evaluateExpression("decimal_string", 16);
if (gDecimalSeparator==',') {
runtimePreferenceCommaLocale=1;
}
} catch (ex) {
}
}
}
this.setPreferencesCommaLocale=function(newRuntimePreferenceCommaLocale) {
runtimePreferenceCommaLocale=newRuntimePreferenceCommaLocale;
if (runtimePreferenceCommaLocale==1) {
globalNumberFormatter.setDecimalCharacter(',');
globalNumberFormatter.setThousandsSeparatorCharacter(' ');
} else {
globalNumberFormatter.setDecimalCharacter('.');
globalNumberFormatter.setThousandsSeparatorCharacter(',');
}
mainTextField.setCommaLocale(runtimePreferenceCommaLocale);
globalEquationController.setCommaLocale(runtimePreferenceCommaLocale);
refreshVariableCache();
}
this.getPreferencesCommaLocale=function() {
return runtimePreferenceCommaLocale;
}
this.setPreferencesWhatToCopy=function(newRuntimePreferencesWhatToCopy) {
runtimePreferencesWhatToCopy=newRuntimePreferencesWhatToCopy;
}
this.getPreferencesWhatToCopy=function() {
return runtimePreferencesWhatToCopy;
}
}
