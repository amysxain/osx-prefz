var globalVersionNumber=2.0;
var globalRevisionNumber=200; 
var mainTextField;
var globalEquationController;
var globalNumberFormatter;
var globalFormulaScrollerController;
var globalQuickLookController;
var answerDiv, formulaCacheDiv, formulaCacheParentDiv, variableCacheDiv;
var variableCacheWidth=110;
var isKeyboardHidden=0;
var isCurrentlyResizing=false;
var variablesInTheFormula=new Array();
var variableValueDivParentWidth=244;
var quickLookMouseLocation={x:0, y:0};
var initialDivPosition={x:0, y:0};
var initialClick={x:0, y:0};
var initialValues={initialWidth:0, initialHeight:0};
var defaultSize={width:323, height:235}; 
var expandedSize={width:323, height:235}; 
var previousExpandedSize={width:323, height:235}; 
var variableCacheGroupToggleValues=new Array(0, 1, 1, 1);
var currentResizeMode=0; 
var modalDisplayType=1; 
var consoleDiv;
var interfaceControllerBackspaceTimer=0; 
function initWidget() 
{
consoleDiv = document.getElementById('consoleDiv');
debugClearConsole();
answerDiv = document.getElementById('answerDiv');
variableCacheDiv = document.getElementById('variableCacheDiv');
formulaCacheDiv = document.getElementById('formulaCacheDiv');	
formulaCacheParentDiv = document.getElementById('formulaCacheParentDiv');	
mainTextField=new PDTextField();
mainTextField.initWithDivsAndSize(document.getElementById('cursorDiv'), document.getElementById('formulaDiv'), document.getElementById('formulaParentDiv'), document.getElementById('hiddenSpanForTextField'), 14, document.getElementById('mainFieldCanvas'));
mainTextField.setHasBodyDelegate(1);
globalEquationController=new PDEquationController();
globalEquationController.init();
globalNumberFormatter=new PDNumberFormatter();
globalUpdateController=new PDUpdateController();
globalFormulaScrollerController=new PDFormulaScrollerController();
globalFormulaScrollerController.init();
globalQuickLookController=new PDQuickLookController();
globalQuickLookController.init();
glassButton = new AppleGlassButton(document.getElementById("doneButton"), "Done", showFront);
loadScrollbars();
cacheImages();
window.onfocus = widgetRecieveFocus;
window.onblur = widgetFocusGoesAway;
globalPreferenceController=new PDPreferenceController();
globalPreferenceController.loadPreferences();
globalUpdateController.checkForUpdates();
refreshVariableCache();
}
function loadScrollbars()
{
variableCacheScrollbar = new AppleVerticalScrollbar(document.getElementById("variableCacheScrollBar"));
variableCacheScrollbar.setSize(15);
variableCacheScrollbar.setTrackStart(variableCacheScrollbar.trackStartPath, 0);
variableCacheScrollbar.setTrackMiddle("images/scrollbars/scrollBarTrack.png");
variableCacheScrollbar.setTrackEnd(variableCacheScrollbar.trackEndPath, 0);
variableCacheScrollbar.setThumbStart("images/scrollbars/scrollBarTop.png", 12);
variableCacheScrollbar.setThumbMiddle("images/scrollbars/scrollBarMiddle.png");
variableCacheScrollbar.setThumbEnd("images/scrollbars/scrollBarBottom.png", 12);
variableCacheScrollArea = new AppleScrollArea(document.getElementById("variableCacheParentDiv"), variableCacheScrollbar);
variableCacheScrollArea.scrollsHorizontally = false;
variableCacheScrollArea.singlepressScrollPixels = 25;
formulaCacheScrollbar = new AppleVerticalScrollbar(document.getElementById("formulaCacheScrollBar"));
formulaCacheScrollbar.setSize(15);
formulaCacheScrollbar.setTrackStart(formulaCacheScrollbar.trackStartPath, 0);
formulaCacheScrollbar.setTrackMiddle("images/scrollbars/scrollBarTrack.png");
formulaCacheScrollbar.setTrackEnd(formulaCacheScrollbar.trackEndPath, 0);
formulaCacheScrollbar.setThumbStart("images/scrollbars/scrollBarTop.png", 12);
formulaCacheScrollbar.setThumbMiddle("images/scrollbars/scrollBarMiddle.png");
formulaCacheScrollbar.setThumbEnd("images/scrollbars/scrollBarBottom.png", 12);
formulaCacheScrollArea = new AppleScrollArea(formulaCacheParentDiv, formulaCacheScrollbar);
formulaCacheScrollArea.scrollsHorizontally = false;
formulaCacheScrollArea.singlepressScrollPixels = 25;
}
function cacheImages()
{
var imageLoader=new Image();
imageLoader.src="images/updateBox/buttonOnLeft.png";
imageLoader.src="images/updateBox/buttonOnMiddle.png";
imageLoader.src="images/updateBox/buttonOnRight.png";
imageLoader.src="images/back/generalOn.png";
imageLoader.src="images/back/middleBorder.png";
imageLoader.src="images/back/formattingDown.png";
imageLoader.src="images/back/formattingOn.png";
imageLoader.src="images/back/general.png";
imageLoader.src="images/back/formatting.png";
imageLoader.src="images/back/generalDown.png";
imageLoader.src="images/formulaBar/formulaBarLeftLight.png";
imageLoader.src="images/formulaBar/formulaBarMiddleLight.png";
imageLoader.src="images/formulaBar/formulaBarRightLight.png";
imageLoader.src="images/body/mainBodyTopBorderLight.png";
}
function resetWidget()
{
mainTextField.replaceStringWithString("");
answerDiv.innerHTML='0';
answerDiv.style.fontSize='19px';
answerDiv.style.top='35px';
formulaCacheDiv.innerHTML='';
globalEquationController.clearAll();
document.getElementById("variableCacheConstantsDiv").innerHTML="";
document.getElementById("variableCacheAutoDefinedDiv").innerHTML="";
document.getElementById("variableCacheDefinedDiv").innerHTML="";
refreshVariableCache();
variableCacheScrollArea.refresh();
variableCacheScrollbar.refresh();
formulaCacheScrollArea.refresh();
formulaCacheScrollbar.refresh();
globalUpdateController.checkForUpdates();
globalFormulaScrollerController.clearAll();
debugClearConsole();
}
function NSLog(stringToPrint)
{
}
function debugClearConsole()
{
consoleDiv.innerHTML='';
}
function flipperShowBackground(elementID, opacityValue)
{
if (isCurrentlyResizing || FPCurrentlyActivePad!=-1) {
return;
}
document.getElementById(elementID).style.opacity=opacityValue;
}
function flipperMouseDown(elementID, opacityValue)
{
document.getElementById(elementID).style.opacity=opacityValue;
}
function flipperHideBackground(elementID, opacityValue)
{
document.getElementById(elementID).style.opacity=opacityValue;
}
function showBack(event)
{
if (window.widget) {
if (isKeyboardHidden) {
window.resizeTo(max(323,expandedSize.width),max(235,expandedSize.height));
}
widget.prepareForTransition("ToBack");
}
document.getElementById("front").style.display = "none";
document.getElementById("back").style.display = "block";
if (window.widget) {
setTimeout("widget.performTransition()", 0);
window.resizeTo(323, 235); 
}
mainTextField.setIsEnabled(0);
}	
function showFront(event)
{
flipperHideBackground("flipper", .32);
if (window.widget) {
if (isKeyboardHidden) {
window.resizeTo(max(323,expandedSize.width),max(235,expandedSize.height));
}
widget.prepareForTransition("ToFront");
}
document.getElementById("back").style.display = "none";
document.getElementById("front").style.display = "block";
if (window.widget) {
setTimeout("widget.performTransition()", 0);
if (isKeyboardHidden) {
window.resizeTo(expandedSize.width,expandedSize.height);
}
}
mainTextField.setIsEnabled(1);
}
function max(value1, value2)
{	
if (value1>value2) {
return value1;
}
return value2;
}
function equationBarBackspaceButtonMouseDown()
{
mainTextField.handleKeyPressCode(8);
interfaceControllerBackspaceTimer=setTimeout("equationBarBackspaceButtonMouseDownRepeat();", 400);
}
function equationBarBackspaceButtonMouseDownRepeat()
{
mainTextField.handleKeyPressCode(8);
interfaceControllerBackspaceTimer=setTimeout("equationBarBackspaceButtonMouseDownRepeat();", 40);
}
function equationBarBackspaceButtonMouseUp()
{
clearTimeout(interfaceControllerBackspaceTimer);	
}
function equationBarClearButtonPressed()
{
mainTextField.handleKeyPressCode(27);
}
function turnNumberPadOn(numberPadNumber)
{
if (numberPadNumber==314) {
document.getElementById("numberPad"+numberPadNumber).className="numberPadOnPi";
} else if (numberPadNumber==11) {
document.getElementById("numberPad"+numberPadNumber).className="numberPadOnRadix";
} else {
document.getElementById("numberPad"+numberPadNumber).className="numberPadOn";
}
}
function turnNumberPadOff(numberPadNumber)
{
if (numberPadNumber==314) {
document.getElementById("numberPad"+numberPadNumber).className="numberPadOffPi";
} else if (numberPadNumber==11) {
document.getElementById("numberPad"+numberPadNumber).className="numberPadOffRadix";
} else {
document.getElementById("numberPad"+numberPadNumber).className="numberPadOff";
}
}
function turnNumberPadHover(numberPadNumber)
{
if (numberPadNumber==314) {
document.getElementById("numberPad"+numberPadNumber).className="numberPadHoverPi";
} else if (numberPadNumber==11) {
document.getElementById("numberPad"+numberPadNumber).className="numberPadHoverRadix";
} else {
document.getElementById("numberPad"+numberPadNumber).className="numberPadHover";
}
}
function FPChangeState(idToChange, newState)
{
var newStateArray=new Array("Off", "Hover", "On");
var padType="log";
if (idToChange<4) {
padType="exp";
} else if (idToChange<10) {
padType="trig";
} else if (idToChange<20) {
padType="log";
} else if (idToChange<30) {
padType="number";
} else if (idToChange<31) {
padType="numberRadix";
} else if (idToChange<32) {
padType="numberPi";
} else if (idToChange<36) {
padType="operatorMSA"
} else if (idToChange<38) {
padType="operatorParens"
} else if (idToChange==38) {
padType="operatorPercent"
} else if (idToChange==39) {
padType="operatorExp"
} else if (idToChange==40) {
padType="operatorDiv"
} else if (idToChange==41) {
padType="operatorEquals"
}
if (idToChange<3 || (idToChange>6 && idToChange<11) || idToChange==13) {
document.getElementById("functPad"+idToChange).className=padType+"PadSup"+newStateArray[newState];
document.getElementById("supFunctPad"+idToChange).className="functPadSup"+newStateArray[newState];
} else {
document.getElementById("functPad"+idToChange).className=padType+"Pad"+newStateArray[newState];
}
}
var FPCurrentlyActivePad=-1;
var FPCurrentlyInsideActivePad=false;
function FPMouseDown(event,functionPadID) 
{
FPCurrentlyActivePad=functionPadID;
FPCurrentlyInsideActivePad=true;
document.addEventListener("mouseup", FPDocumentMouseUp, true);
FPChangeState(functionPadID, 2);
event.preventDefault();
}
function FPMouseOver(event,functionPadID)
{
if (FPCurrentlyActivePad==-1) {
FPChangeState(functionPadID, 1);
} else if (FPCurrentlyActivePad==functionPadID) {
FPCurrentlyInsideActivePad=true;
FPChangeState(functionPadID, 2);	
}
event.preventDefault();
}
function FPMouseOut(event,functionPadID)
{
if (FPCurrentlyActivePad==-1) {
FPChangeState(functionPadID, 0);
} else if (FPCurrentlyActivePad==functionPadID) {
FPCurrentlyInsideActivePad=false;
FPChangeState(functionPadID, 0);
}
event.preventDefault();
}
function FPDocumentMouseUp(event)
{
document.removeEventListener("mouseup", FPDocumentMouseUp, true);
if (FPCurrentlyActivePad!=-1 && FPCurrentlyInsideActivePad==true) { 
FPChangeState(FPCurrentlyActivePad, 1);
FPHandleClickEventForPad(FPCurrentlyActivePad);
}
FPCurrentlyActivePad=-1;
FPCurrentlyInsideActivePad=false;
event.preventDefault();
}
function FPHandleClickEventForPad(functionPadID)
{
if (functionPadID==41) {
mainTextField.handleKeyPressCode(3);
return;
}
var stringToAdd="";
switch(functionPadID) {
case 1:
stringToAdd="^-1";
break;
case 2:
stringToAdd="^2";
break;
case 3:
stringToAdd="sqrt(";
break;
case 4:
stringToAdd="sin(";
break;
case 5:
stringToAdd="cos(";
break;
case 6:
stringToAdd="tan(";
break;
case 7:
stringToAdd="asin(";
break;
case 8:
stringToAdd="acos(";
break;
case 9:
stringToAdd="atan(";
break;
case 10:
stringToAdd="10^(";
break;
case 11:
stringToAdd="log(";
break;
case 12:
stringToAdd="ans";
break;
case 13:
stringToAdd="exp(";
break;
case 14:
stringToAdd="ln(";
break;
case 15:
stringToAdd="%";
break;
case 20:
stringToAdd="0";
break;
case 21:
stringToAdd="1";
break;
case 22:
stringToAdd="2";
break;
case 23:
stringToAdd="3";
break;
case 24:
stringToAdd="4";
break;
case 25:
stringToAdd="5";
break;
case 26:
stringToAdd="6";
break;
case 27:
stringToAdd="7";
break;
case 28:
stringToAdd="8";
break;
case 29:
stringToAdd="9";
break;
case 30:
stringToAdd=".";
break;
case 31:
stringToAdd="pi";
break;
case 33:
stringToAdd="*";
break;
case 34:
stringToAdd="-";
break;
case 35:
stringToAdd="+";
break;
case 36:
stringToAdd="(";
break;
case 37:
stringToAdd=")";
break;
case 38:
stringToAdd="%";
break;
case 39:
stringToAdd="^";
break;
case 40:
stringToAdd="/";
break;
}
mainTextField.handleKeyPressCode(stringToAdd.charCodeAt(0));
if (stringToAdd.length>1) {
mainTextField.insertString(stringToAdd.substr(1));
}
}
function turnFunctionPadOff(functionPadNumber)
{
document.getElementById("trigPad"+functionPadNumber).className="trigPadOff";
if (functionPadNumber>=4 && functionPadNumber<=6) {
document.getElementById("supTrigPad"+functionPadNumber).className="supTrigPadOff";
}
}
function turnFunctionPadHover(functionPadNumber)
{
document.getElementById("trigPad"+functionPadNumber).className="trigPadHover";
if (functionPadNumber>=4 && functionPadNumber<=6) {
document.getElementById("supTrigPad"+functionPadNumber).className="supTrigPadHover";
}
}
function widgetRecieveFocus()
{
document.getElementById("formulaBarLeft").className="formulaBarLeft";
document.getElementById("formulaBarRight").className="formulaBarRight";
document.getElementById("formulaBarMiddle").className="formulaBarMiddle";
document.getElementById("mainBodyTopBorder").className="mainBodyTopBorder";
document.getElementById('formulaDiv').style.color="#FFFFFF"; 
answerDiv.className="answerFont";
mainTextField.recievedFocus();
}
function widgetFocusGoesAway()
{
document.getElementById("formulaBarLeft").className="formulaBarLeftLight";
document.getElementById("formulaBarRight").className="formulaBarRightLight";
document.getElementById("formulaBarMiddle").className="formulaBarMiddleLight";
document.getElementById("mainBodyTopBorder").className="mainBodyTopBorderLight";
document.getElementById('formulaDiv').style.color="#DFDFDF"; 
answerDiv.className="answerFontLight";
mainTextField.lostFocus();
}
function pasteHandler(event)
{
var clipboardString=event.clipboardData.getData('Text');
var i, stringToAdd="", curkeycode, clipboardStringLength;
var commaLocale=globalPreferenceController.getPreferencesCommaLocale();
if (commaLocale) {
clipboardString=clipboardString.replace(/\./g,',');
} else {
clipboardString=clipboardString.replace(/,/g,'');
}
clipboardStringLength=clipboardString.length;
for (i=0; i<clipboardString.length; i++) {
curkeycode=clipboardString.charCodeAt(i);
if ((curkeycode>47 && curkeycode<58) || (curkeycode>64 && curkeycode<91) || (curkeycode>96 && curkeycode<123) || (curkeycode>191 && curkeycode<256 && curkeycode!=215 && curkeycode!=237) || (curkeycode>=1024 && curkeycode<=1153) || (curkeycode>=1162 && curkeycode<=1279) || curkeycode==32) {
stringToAdd=stringToAdd+''+clipboardString.charAt(i);
} else {
switch (curkeycode) {
case 37: case 40: case 41: case 42: case 43: case 44: case 45: case 46: case 47: case 61: case 94: case 8901:
stringToAdd=stringToAdd+''+clipboardString.charAt(i);
break;
}
}
if (clipboardString.charCodeAt(i)==10 || clipboardString.charCodeAt(i)==3 || clipboardString.charCodeAt(i)==13) 
break;
}
document.getElementById("tempDiv").innerHTML=stringToAdd;
stringToAdd=document.getElementById("tempDiv").innerHTML;
mainTextField.insertString(stringToAdd);
event.preventDefault();
}
function cutHandler(event)
{
event.preventDefault();
event.clipboardData.setData('Text', mainTextField.stringForCopying());
mainTextField.deleteBackward();
return;
}
function copyHandler(event)
{
event.preventDefault();
var whatToCopy=globalPreferenceController.getPreferencesWhatToCopy(); 
if (whatToCopy) {
event.clipboardData.setData('Text', mainTextField.stringForCopying());
} else {
event.clipboardData.setData('Text', answerDiv.innerHTML);
}
}
function answerDivWasClicked()
{
globalPreferenceController.setPreferencesWhatToCopy(0);
}
function textFieldWasClicked()
{
globalPreferenceController.setPreferencesWhatToCopy(1);
}
function equationEntered()
{
var equationToCalculate=mainTextField.stringValue();
var calculationResult=globalEquationController.addString(equationToCalculate);
globalFormulaScrollerController.addCalculatedString(equationToCalculate);
var formulaCacheAnswerToAdd="", answerDivAnswerToAdd="", variableIDToAssign;
var variableName="", formattedNumber="";
var resultFloat;
if (calculationResult.getIsErrorMessage()) { 
answerDiv.style.fontSize='12px';
answerDiv.style.top='40px';
formulaCacheAnswerToAdd="Error: "+calculationResult.getErrorMessage();
answerDiv.innerHTML=formulaCacheAnswerToAdd;
addFormulaToCache(equationToCalculate, formulaCacheAnswerToAdd, calculationResult);
} else { 
answerDiv.style.fontSize='19px';
answerDiv.style.top='35px';
resultFloat=calculationResult.getNumber(); 
formattedNumber=globalNumberFormatter.formattedNumberForNumber(resultFloat);
variableIDToAssign=calculationResult.getVariableToAssign();
if (variableIDToAssign!=-1 && globalVariableArray[variableIDToAssign].getType()==3) { 
variableName=globalVariableNamesArray[variableIDToAssign];
answerDivAnswerToAdd=variableName+" = "+formattedNumber;
formulaCacheAnswerToAdd=answerDivAnswerToAdd; 
} else { 
answerDivAnswerToAdd=formattedNumber;
formulaCacheAnswerToAdd="= "+formattedNumber;
}
answerDiv.innerHTML=answerDivAnswerToAdd;
addFormulaToCache(equationToCalculate, formulaCacheAnswerToAdd, calculationResult);
refreshVariableCache();
mainTextField.setJustCalculatedEquation(1);
}
formulaJustCalculated();
}
function addVariableToMainDisplay(variableIndex)
{
if (mainTextField.getJustCalculatedEquation()) {
mainTextField.replaceStringWithString("");
}
if (variableIndex==-1) {
return;
}
mainTextField.insertString(globalVariableNamesArray[variableIndex]);
}
function clearDisplay()
{
mainTextField.replaceStringWithString("");
}
function formulaJustCalculated()
{
answerDiv.style.opacity=1.0;
var numberOfEquations=globalEquationController.getNumberOfEquations();
if (numberOfEquations>1 && (numberOfEquations-1)%150 == 0) {
PDUShowEquationQuantityNote(numberOfEquations-1);
} else { 
globalUpdateController.checkForUpdates();
}
}
function formulaDidChange()
{
answerDiv.style.opacity=0.6;
globalQuickLookController.formulaDidChange();
}
function scrollToPreviousFormlua()
{
var currentString=mainTextField.stringValue();
var previousString=globalFormulaScrollerController.stringForPreviousIndexFromString(currentString);
if (previousString==null) {
return;
}
mainTextField.replaceStringWithString(previousString);
}
function scrollToNextFormula()
{
var currentString=mainTextField.stringValue();
var previousString=globalFormulaScrollerController.stringForNextIndexFromString(currentString);
if (previousString==null) {
return;
}
mainTextField.replaceStringWithString(previousString);
}
function justCalculatedEquationDidChange(newJustCalculatedEquation) 
{
globalFormulaScrollerController.setJustCalculatedEquation(newJustCalculatedEquation);
}
function formulaParentDivMouseDidMove(event)
{
if (!event.shiftKey) {
globalQuickLookController.endQuickLook();
} else { 
if (quickLookMouseLocation.x==event.pageX && quickLookMouseLocation.y==event.pageY) {
} else {
globalQuickLookController.handleVariableHighlightMouseMove(event);
}
}
quickLookMouseLocation.x=event.pageX;
quickLookMouseLocation.y=event.pageY;
}
function formulaParentDivMouseOut()
{
quickLookMouseLocation.x=0;
quickLookMouseLocation.y=0;
globalQuickLookController.endQuickLook();
}
function refreshVariableCache()
{
var i, iLength=globalVariableArray.length;
var typeDivs=new Array();
typeDivs[1]=document.getElementById("variableCacheConstantsDiv");
typeDivs[2]=document.getElementById("variableCacheAutoDefinedDiv");
typeDivs[3]=document.getElementById("variableCacheDefinedDiv");
var currentVariableType=0;
for (i=0; i<iLength; i++) {
if (globalVariableArray[i].getIsDisplayUpdated()==false) {
if (document.getElementById('cache'+i)) {
document.getElementById('cache'+i).innerHTML=globalVariableNamesArray[i]+' = '+globalNumberFormatter.formattedNumberForNumber(globalVariableArray[i].getNumber());
} else {
currentVariableType=globalVariableArray[i].getType();
typeDivs[currentVariableType].innerHTML+="<div id='cache"+i+"' class='variableCacheVariable' onclick=\"addVariableToMainDisplay("+i+");\">"+ globalVariableNamesArray[i] +' = '+globalNumberFormatter.formattedNumberForNumber(globalVariableArray[i].getNumber())+'</div>';
}
globalVariableArray[i].setIsDisplayUpdated(true);
}
}
updateVariableCacheDivScrollArea();
}
function refreshVariableCacheNumberFormatting() {
var i, iLength=globalVariableArray.length;
var typeDivs=new Array();
typeDivs[1]=document.getElementById("variableCacheConstantsDiv");
typeDivs[2]=document.getElementById("variableCacheAutoDefinedDiv");
typeDivs[3]=document.getElementById("variableCacheDefinedDiv");
var currentVariableType=0;
for (i=0; i<iLength; i++) {
if (document.getElementById('cache'+i)) {
document.getElementById('cache'+i).innerHTML=globalVariableNamesArray[i]+' = '+globalNumberFormatter.formattedNumberForNumber(globalVariableArray[i].getNumber());
} else {
currentVariableType=globalVariableArray[i].getType();
typeDivs[currentVariableType].innerHTML+="<div id='cache"+i+"' class='variableCacheVariable' onclick=\"addVariableToMainDisplay("+i+");\">"+ globalVariableNamesArray[i] +' = '+globalNumberFormatter.formattedNumberForNumber(globalVariableArray[i].getNumber())+'</div>';
}
}
updateVariableCacheDivScrollArea();
}
function toggleVariableCacheGroup(groupNumberToToggle) {
if (groupNumberToToggle<1 || groupNumberToToggle>3) { 
return;
}
var groupArrowNames=new Array("", "variableCacheConstantsArrow", "variableCacheAutoDefinedArrow", "variableCacheDefinedArrow");
var groupDivNames=new Array("", "variableCacheConstantsDiv", "variableCacheAutoDefinedDiv", "variableCacheDefinedDiv");
document.getElementById(groupArrowNames[groupNumberToToggle]).style.opacity=0.8;
if (variableCacheGroupToggleValues[groupNumberToToggle]) { 
document.getElementById(groupDivNames[groupNumberToToggle]).style.display='none';
document.getElementById(groupArrowNames[groupNumberToToggle]).src='images/variableCache/rightArrow.png';
variableCacheGroupToggleValues[groupNumberToToggle]=0;
} else {
document.getElementById(groupDivNames[groupNumberToToggle]).style.display='block';
document.getElementById(groupArrowNames[groupNumberToToggle]).src='images/variableCache/downArrow.png';
variableCacheGroupToggleValues[groupNumberToToggle]=1;
}
updateVariableCacheDivScrollArea();
}
function updateVariableCacheDivScrollArea()
{
variableCacheScrollArea.refresh();
var tempvar=variableCacheScrollArea.content.scrollHeight - variableCacheScrollArea.viewHeight-14;
if (tempvar<=0 || tempvar==variableCacheScrollArea.content.scrollTop) {
variableCacheScrollArea.verticalScrollTo(variableCacheScrollArea.content.scrollHeight - variableCacheScrollArea.viewHeight);
}
var variableCacheScrollBarWidth=0; 
if (!variableCacheScrollbar.hidden) { 
variableCacheScrollBarWidth=15;
}
document.getElementById("variableCacheParentDiv").style.width = variableCacheWidth-variableCacheScrollBarWidth;
}
function addFormulaToCache(formulaToAdd, answerToAdd, formulaResult)
{
if (formulaToAdd=="") { 
return;
}
var answerVariableID=formulaResult.getVariableToAssign();
var formulaID=formulaResult.getEquationIndex();
var formulaCacheClassToUse="formulaCacheFormula";
var currentVariable;
var currentVariableName;
var textToAdd="";
if (formulaCacheDiv.innerHTML=="") {
formulaCacheClassToUse="formulaCacheFormulaFirst";
}	
if (formulaResult.getIsErrorMessage()) { 
textToAdd="<div class='"+formulaCacheClassToUse+"' onclick=\"formulaCacheEquationWasClicked("+formulaID+");\">" + formulaToAdd + "</div><div class='formulaCacheErrorAnswer'>"+answerToAdd+"</div>";
} else { 
currentVariable=globalVariableArray[answerVariableID];
if (currentVariable.getType()==2) { 
currentVariableName=globalVariableNamesArray[answerVariableID];
textToAdd="<div class='"+formulaCacheClassToUse+"' onclick=\"formulaCacheEquationWasClicked("+formulaID+");\">" + formulaToAdd + "</div><div class='formulaCacheAnswer' onclick=\"addVariableToMainDisplay("+answerVariableID+");\"><span style='float:right' class='formulaCacheAutoDefinedAnswerName'>"+currentVariableName+"</span>"+answerToAdd+"</div>";
} else { 
textToAdd="<div class='"+formulaCacheClassToUse+"' onclick=\"formulaCacheEquationWasClicked("+formulaID+");\">" + formulaToAdd + "</div><div class='formulaCacheAnswer' onclick=\"addVariableToMainDisplay("+answerVariableID+");\">"+answerToAdd+"</div>";
}
}
var scrollBarPositionPriorToRefresh=formulaCacheScrollArea.content.scrollHeight-(formulaCacheScrollArea.content.scrollTop+formulaCacheScrollArea.viewHeight);
formulaCacheDiv.innerHTML=formulaCacheDiv.innerHTML+textToAdd;
var formulaCacheScrollBarHidden=formulaCacheScrollbar.hidden;
var formulaCacheParentDivWidth;
formulaCacheScrollArea.refresh();
if (formulaCacheScrollBarHidden!=formulaCacheScrollbar.hidden) { 
if (formulaCacheScrollbar.hidden==false) { 
formulaCacheParentDivWidth = expandedSize.width-22-15-variableCacheWidth-1; 
} else { 
formulaCacheParentDivWidth = expandedSize.width-22-0-variableCacheWidth-1; 
}
formulaCacheParentDiv.style.width=formulaCacheParentDivWidth;
document.getElementById("formulaCacheDiv").style.width=formulaCacheParentDivWidth-10;
formulaCacheScrollArea.refresh(); 
}
if (scrollBarPositionPriorToRefresh<=10) { 
scrollToBottomOfFormulaCache();
}
}
function scrollToBottomOfFormulaCache()
{
formulaCacheScrollArea.verticalScrollTo(formulaCacheScrollArea.content.scrollHeight - formulaCacheScrollArea.viewHeight);
}
function formulaCacheEquationWasClicked(equationIdClicked)
{
var equationString=globalEquationController.getEquationStringForEquationIndex(equationIdClicked);
if (equationIdClicked!=null) {
if (!event.shiftKey) {
mainTextField.replaceStringWithString(equationString);
mainTextField.setJustCalculatedEquation(0);
} else {
mainTextField.insertString(equationString);
}
}
}
function toggleKeypadVisibility()
{
if (isKeyboardHidden) { 
isKeyboardHidden=0;
document.getElementById("keypadContainer").style.visibility = 'visible';
document.getElementById("cacheContainer").style.visibility = 'hidden';
setWidgetWidth(323);
setWidgetHeight(235);
if (window.widget) {
window.resizeTo(323,235);
}
document.getElementById("keypadToggler").src="images/bottomBar/splitview.png";		
if (document.getElementById("keypadToggler").style.opacity==0.9) {
document.getElementById("keypadToggler").style.opacity=.65;
}
document.getElementById("flipper").style.right="33px";
document.getElementById("resize").style.display="none";
} else { 
isKeyboardHidden=1;
document.getElementById("keypadContainer").style.visibility = 'hidden';
document.getElementById("cacheContainer").style.visibility = 'visible';
document.getElementById("keypadToggler").src="images/bottomBar/buttons.png";
if (document.getElementById("keypadToggler").style.opacity==0.9) {
document.getElementById("keypadToggler").style.opacity=.65;
}
document.getElementById("flipper").style.right="41px";
document.getElementById("resize").style.display="block";
setWidgetWidth(expandedSize.width);
setWidgetHeight(expandedSize.height);
if (window.widget) {
window.resizeTo(expandedSize.width, expandedSize.height);
}
refreshCacheScrollAreasWithWidth(expandedSize.width);
}
globalPreferenceController.setPreferencesKeypadIsHidden(isKeyboardHidden);
}
function setVariableCacheWidth(newWidth)
{
var formulaCacheScrollBarWidth=0; 
var formulaCacheParentDivWidth;
var variableCacheScrollBarWidth=0; 
if (!variableCacheScrollbar.hidden) { 
variableCacheScrollBarWidth=15;
}
if (newWidth>=0 && newWidth<(expandedSize.width-22)) {
if (formulaCacheScrollbar.hidden==false) {
formulaCacheScrollBarWidth=15;
}
document.getElementById("variableCacheContainerDiv").style.width = newWidth;
document.getElementById("variableCacheParentDiv").style.width = newWidth - variableCacheScrollBarWidth;
variableCacheWidth=newWidth;
document.getElementById("variableFormulaCacheResizeDiv").style.left = newWidth-3;
document.getElementById("formulaCacheContainerDiv").style.left = newWidth+1;
document.getElementById("formulaCacheContainerDiv").style.width = expandedSize.width-22-variableCacheWidth-1;
formulaCacheParentDivWidth = expandedSize.width-22-formulaCacheScrollBarWidth-variableCacheWidth-1;
formulaCacheParentDiv.style.width = formulaCacheParentDivWidth;
document.getElementById("formulaCacheDiv").style.width=formulaCacheParentDivWidth-10;
}
refreshCacheScrollAreasWithWidth(expandedSize.width);
}
function setWidgetWidth(newWidth)
{
var formulaCacheScrollBarWidth=0; 
var formulaCacheParentDivWidth;
if (formulaCacheScrollbar.hidden==false) {
formulaCacheScrollBarWidth=15;
}
document.getElementById("formulaBarContainer").style.width=newWidth;
document.getElementById("formulaBarMiddle").style.width=newWidth-54;
document.getElementById("bottomBarContainer").style.width = newWidth;
document.getElementById("bottomBarMiddle").style.width=newWidth-54;
document.getElementById("mainBodyContainer").style.width = newWidth;
document.getElementById("mainBodyTopBorder").style.width = newWidth-22;
document.getElementById("cacheContainer").style.width = newWidth-22;
document.getElementById("formulaCacheContainerDiv").style.width = newWidth-22-variableCacheWidth-1;
answerDiv.style.width=newWidth-94;
formulaCacheParentDivWidth = newWidth-22-formulaCacheScrollBarWidth-variableCacheWidth-1; 
formulaCacheParentDiv.style.width = formulaCacheParentDivWidth;
document.getElementById("formulaCacheDiv").style.width=formulaCacheParentDivWidth-10;
document.getElementById("updateDivContainer").style.width = newWidth-32; 
mainTextField.setWidth(newWidth-73);
}
function setWidgetHeight(newHeight)
{
document.getElementById("bottomBarContainer").style.top =newHeight-39;
if (newHeight>106) {
document.getElementById("mainBodyContainer").style.height = newHeight-106;
document.getElementById("cacheContainer").style.height = newHeight-108;
document.getElementById("updateDivContainer").style.height = newHeight-116;
} else {
document.getElementById("mainBodyContainer").style.height = 0;
}
}
function refreshCacheScrollAreasWithWidth(newWidth)
{
variableCacheScrollArea.refresh(); 
formulaCacheScrollArea.refresh();
var formulaCacheScrollBarWidth=15;
var formulaCacheParentDivWidth;
if (formulaCacheScrollbar.hidden==false) { 
formulaCacheParentDivWidth=newWidth-22-formulaCacheScrollBarWidth-variableCacheWidth-1;
formulaCacheParentDiv.style.width = formulaCacheParentDivWidth;
document.getElementById("formulaCacheDiv").style.width=formulaCacheParentDivWidth-10;
formulaCacheScrollArea.refresh();
}
var variableCacheScrollBarWidth=0; 
if (!variableCacheScrollbar.hidden) { 
variableCacheScrollBarWidth=15;
}
document.getElementById("variableCacheParentDiv").style.width = variableCacheWidth-variableCacheScrollBarWidth;
}
function resizeVariableFormulaCacheDividerMouseDown(event)
{
document.addEventListener("mousemove", resizeVariableFormulaCacheDividerMouseMove, true);
document.addEventListener("mouseup", resizeVariableFormulaCacheDividerMouseUp, true);
isCurrentlyResizing=true;
initialDivPosition.x=parseInt(document.getElementById('variableFormulaCacheResizeDiv').style.left)+3;
initialClick.x=event.x;
}
function resizeVariableFormulaCacheDividerMouseMove(event)
{
var deltaX=event.x-initialClick.x;
var proposedX=initialDivPosition.x+deltaX;
setVariableCacheWidth(proposedX);
}
function resizeVariableFormulaCacheDividerMouseUp(event)
{
document.removeEventListener("mousemove", resizeVariableFormulaCacheDividerMouseMove, true);
document.removeEventListener("mouseup", resizeVariableFormulaCacheDividerMouseUp, true); 
isCurrentlyResizing=false;
}
function resizeMouseDown(event)
{
document.addEventListener("mousemove", resizeMouseMove, true);
document.addEventListener("mouseup", resizeMouseUp, true);
var tempx=parseInt(document.getElementById("resize").style.left);
var tempy=parseInt(document.getElementById("resize").style.top);
var initialWidth=parseInt(document.getElementById("formulaBarContainer").style.width);
var initialHeight=parseInt(document.getElementById("bottomBarContainer").style.top)+39;
initialClick={x:event.x, y:event.y};
initialValues={initialWidth:initialWidth, initialHeight:initialHeight};
isCurrentlyResizing=true;
event.preventDefault();
}
function resizeMouseMove(event)
{
var x = event.x-initialClick.x; 
var y = event.y-initialClick.y;
expandedSize.width=initialValues.initialWidth+x;
expandedSize.height=initialValues.initialHeight+y;
refreshWidgetExpandedSize();
}
function refreshWidgetExpandedSize()
{
if (expandedSize.width>318 && expandedSize.width<328) {
expandedSize.width=323;
} else if (expandedSize.width<297) {
expandedSize.width=297;
}
if (expandedSize.height>230 && expandedSize.height<240) {
expandedSize.height=235;
} else if (expandedSize.height<106) {
expandedSize.height=106;
}
if (currentResizeMode==1) { 
if (expandedSize.height<235) { 
expandedSize.height=235;
}
if (expandedSize.width<323) { 
expandedSize.width=323;
}
}
setWidgetWidth(expandedSize.width);
setWidgetHeight(expandedSize.height);
if (window.widget) {
window.resizeTo(expandedSize.width, expandedSize.height);
}
var formulaCacheScrollBarHidden=formulaCacheScrollbar.hidden;
var formulaCacheParentDivWidth;
var variableCacheScrollBarHidden=variableCacheScrollbar.hidden;
variableCacheScrollArea.refresh();
formulaCacheScrollArea.refresh();
var variableCacheScrollBarWidth=0; 
if (variableCacheScrollBarHidden!=variableCacheScrollbar.hidden) { 
if (!variableCacheScrollbar.hidden) { 
variableCacheScrollBarWidth=15;
}
document.getElementById("variableCacheParentDiv").style.width = variableCacheWidth-variableCacheScrollBarWidth;
}
if (formulaCacheScrollBarHidden!=formulaCacheScrollbar.hidden) { 
if (formulaCacheScrollbar.hidden==false) { 
formulaCacheParentDivWidth = expandedSize.width-22-15-variableCacheWidth-1; 
} else { 
formulaCacheParentDivWidth = expandedSize.width-22-0-variableCacheWidth-1; 
}
formulaCacheParentDiv.style.width=formulaCacheParentDivWidth;
document.getElementById("formulaCacheDiv").style.width=formulaCacheParentDivWidth-10;
formulaCacheScrollArea.refresh();
}
}
function resizeMouseUp(event)
{
document.removeEventListener("mousemove", resizeMouseMove, true);
document.removeEventListener("mouseup", resizeMouseUp, true); 
isCurrentlyResizing=false;
globalPreferenceController.setPreferencesExpandedWidth(expandedSize.width);
globalPreferenceController.setPreferencesExpandedHeight(expandedSize.height);
event.preventDefault();
}
function bottomBarNumberFormattingDidChange()
{
var newNumberFormattingType=parseInt(document.getElementById('bottomBarNumberFormatting').value);
if (isNaN(newNumberFormattingType)) { 
return;
}
globalPreferenceController.setPreferencesNumberFormattingType(newNumberFormattingType);
syncNumberFormattingTypeWithPreferences(1);
}
function syncNumberFormattingTypeWithPreferences(shouldUpdateNumberFormatting) 
{
var newNumberFormattingType=globalPreferenceController.getPreferencesNumberFormattingType();
globalNumberFormatter.setPreferencesNumberFormattingType(newNumberFormattingType);
document.getElementById('bottomBarNumberFormatting').value=newNumberFormattingType;
var tempArray=new Array("", "Float", "Scientific", "Engineering", "Percent", "Binary", "Octal", "Hexadecimal");
document.getElementById('bottomBarNumberFormattingLabel').innerHTML=tempArray[newNumberFormattingType];
if (shouldUpdateNumberFormatting) {
numberFormattingDidChange();
}
}
function numberFormattingDidChange() 
{
var lastResult=globalEquationController.getLastResult();
var variableToAssign;
var lastResultNumber=-1;
if (lastResult==undefined) {
return;
}
if (lastResult==-1) { 
lastResultNumber=0.0;
} else { 
if (lastResult.getIsErrorMessage()) {
return;
}
variableToAssign=lastResult.getVariableToAssign();
lastResultNumber=globalVariableArray[variableToAssign].getNumber();
}
var formattedNumber=globalNumberFormatter.formattedNumberForNumber(lastResultNumber);
answerDiv.innerHTML=formattedNumber;
refreshVariableCacheNumberFormatting();
}
function bottomBarDegreesRadiansDidChange()
{
var newDegreesRadians=parseInt(document.getElementById('bottomBarDegreesRadians').value);
if (isNaN(newDegreesRadians)) { 
return;
}
globalPreferenceController.setPreferencesRadians(newDegreesRadians);
syncDegreesRadiansWithPreferences();
}
function syncDegreesRadiansWithPreferences() 
{
var newDegreesRadians=globalPreferenceController.getPreferencesRadians();
document.getElementById('bottomBarDegreesRadians').value=newDegreesRadians;
var tempArray=new Array("Degrees", "Radians");
document.getElementById('bottomBarDegreesRadiansLabel').innerHTML=tempArray[newDegreesRadians];
globalEquationController.setPreferencesRadians(newDegreesRadians);
}
function switchPreferencesView(viewToSwitchTo)
{
if (viewToSwitchTo==0) { 
document.getElementById("widgetBackGeneralTab").src="images/back/generalOn.png";
document.getElementById("widgetBackFormattingTab").src="images/back/formatting.png";
document.getElementById("widgetBackGeneralTable").style.display="block";
document.getElementById("widgetBackFormattingTable").style.display="none";
} else { 
document.getElementById("widgetBackGeneralTab").src="images/back/general.png";
document.getElementById("widgetBackFormattingTab").src="images/back/formattingOn.png";
document.getElementById("widgetBackGeneralTable").style.display="none";
document.getElementById("widgetBackFormattingTable").style.display="block";
}
}
function widgetBackPercentIsModulusDidChange()
{
var newPreferencesPercentIsModulus=0;
if (document.getElementById("widgetBackPercentIsModulus").checked) {
newPreferencesPercentIsModulus=1;
} else {
newPreferencesPercentIsModulus=0;
}
globalPreferenceController.setPreferencesPercentIsModulus(newPreferencesPercentIsModulus);
syncePercentIsModulusWithPreferences();
}
function syncePercentIsModulusWithPreferences()
{
var newPreferencesPercentIsModulus=globalPreferenceController.getPreferencesPercentIsModulus();
if (newPreferencesPercentIsModulus) {
document.getElementById('widgetBackPercentIsModulus').checked=true;
} else {
document.getElementById('widgetBackPercentIsModulus').checked=false;
}
globalEquationController.setPreferencesPercentIsModulus(newPreferencesPercentIsModulus);
}
function widgetBackMultiplicationSymbolDidChange()
{
var newMultiplicationSymbol=parseInt(document.getElementById('widgetBackMultiplicationSymbol').value);
globalPreferenceController.setPreferencesMultiplicationSymbol(newMultiplicationSymbol);
syncMultiplicationSymbolWithPreferences();
}
function syncMultiplicationSymbolWithPreferences() 
{
var newMultiplicationSymbol=globalPreferenceController.getPreferencesMultiplicationSymbol();
document.getElementById('widgetBackMultiplicationSymbol').value=newMultiplicationSymbol;
mainTextField.setUseMultiplicationDot(newMultiplicationSymbol);
}
function widgetBackCheckForUpdatesDidChange()
{
var newPreferencesCheckForUpdates=1;
if (document.getElementById("widgetBackCheckForUpdates").checked) {
newPreferencesCheckForUpdates=1;
} else {
newPreferencesCheckForUpdates=0;
}
globalPreferenceController.setPreferencesCheckForUpdates(newPreferencesCheckForUpdates);
syncCheckForUpdatesWithPreferences();
newPreferencesCheckForUpdates=globalPreferenceController.getPreferencesCheckForUpdates();
if (newPreferencesCheckForUpdates==1) {
globalUpdateController.checkForUpdates();
}
}
function syncCheckForUpdatesWithPreferences()
{
var newPreferencesCheckForUpdates=globalPreferenceController.getPreferencesCheckForUpdates();
if (newPreferencesCheckForUpdates) {
document.getElementById('widgetBackCheckForUpdates').checked=true;
} else {
document.getElementById('widgetBackCheckForUpdates').checked=false;
}
}
function widgetBackSigfigDecimalComboDidChange()
{
var newPreferencesSigfigDecimalCombo=parseInt(document.getElementById('widgetBackSigfigDecimalCombo').value);
globalPreferenceController.setPreferencesSigfigDecimalComboIndex(newPreferencesSigfigDecimalCombo);
syncSigfigDecimalComboWithPreferences(1);
}
function syncSigfigDecimalComboWithPreferences(shouldUpdateNumberFormatting)
{
var newPreferencesSigfigDecimalCombo=globalPreferenceController.getPreferencesSigfigDecimalComboIndex();
document.getElementById('widgetBackSigfigDecimalCombo').value=newPreferencesSigfigDecimalCombo;
var newPreferencesSignificantFigures=globalPreferenceController.getPreferencesSignificantFigures();
var newPreferencesDecimalPlaces=globalPreferenceController.getPreferencesDecimalPlaces();
globalNumberFormatter.setPreferencesSignificantFiguresAndDecimalPlaces(newPreferencesSignificantFigures, newPreferencesDecimalPlaces);
if (shouldUpdateNumberFormatting) {
numberFormattingDidChange();
}
}
function widgetBackThousandsSeparatorsDidChange()
{
var newPreferencesThousandsSeperators=0;
if (document.getElementById("widgetBackThousandsSeparators").checked) {
newPreferencesThousandsSeperators=1;
} else {
newPreferencesThousandsSeperators=0;
}
globalPreferenceController.setPreferencesThousandsSeparators(newPreferencesThousandsSeperators);
syncThousandsSeparatorWithPreferences(1);
}
function syncThousandsSeparatorWithPreferences(shouldUpdateNumberFormatting)
{
var newPreferencesThousandsSeperators=globalPreferenceController.getPreferencesThousandsSeparators();
if (newPreferencesThousandsSeperators) {
document.getElementById('widgetBackThousandsSeparators').checked=true;
} else {
document.getElementById('widgetBackThousandsSeparators').checked=false;
}
globalNumberFormatter.setPreferencesThousandsSeperators(newPreferencesThousandsSeperators);
if (shouldUpdateNumberFormatting) {
numberFormattingDidChange();
}
}
function PDUButton2Clicked()
{
if (modalDisplayType==1) {
deactivateModalDisplay();
} else if (modalDisplayType==2) { 
resetWidget();
deactivateModalDisplay();
}
}
function PDUButton3Clicked()
{
if (modalDisplayType==1) {
PDUOpenUpdateURL();
deactivateModalDisplay();
} else if (modalDisplayType==2) { 
deactivateModalDisplay();
}
}
function PDUOpenUpdateURL()
{
var updateURL=globalUpdateController.getCurrentReleaseURL();
if(window.widget && updateURL!="") {
widget.openURL(updateURL);
}
}
function PDUTurnUpdateButtonOn(updateButton)
{
document.getElementById('updateLeft'+updateButton).className='updateLeftOn';
document.getElementById('updateMiddle'+updateButton).className='updateMiddleOn';
document.getElementById('updateRight'+updateButton).className='updateRightOn';
}
function PDUTurnUpdateButtonOff(updateButton)
{
document.getElementById('updateLeft'+updateButton).className='updateLeftOff';
document.getElementById('updateMiddle'+updateButton).className='updateMiddleOff';
document.getElementById('updateRight'+updateButton).className='updateRightOff';
}
function PDUSkipThisUpdate()
{
var revisionToSkip=globalUpdateController.getNewestRevisionNumber();
globalPreferenceController.setPreferencesSkipUpdateToRevision(revisionToSkip);
deactivateModalDisplay();
}
function PDUShowEquationQuantityNote(numberOfEquations)
{
modalDisplayType=2;
document.getElementById('updateMessage').innerHTML="There are over "+numberOfEquations+" equations in this session, which may cause PEMDAS to perform slowly.  You can clear the session by double clicking the Clear button above, by quickly pressing the Clear or Esc button on your keyboard twice, or by using the button in this alert.";
document.getElementById('updateHeaderTitle').innerHTML="There are over "+numberOfEquations+" equations in the session.";
document.getElementById('updateButton1Container').style.display='none';
document.getElementById('updateButton2Title').innerHTML='Clear Now';
document.getElementById('update23ButtonSpacer').style.width='24px';
document.getElementById('updateButton3Title').innerHTML='Later';
activateModalDisplay();
}
function PDUShowUpdateDiv()
{
modalDisplayType=1;
document.getElementById('updateMessage').innerHTML=globalUpdateController.getNewestRevesionReleaseMessage();
document.getElementById('updateHeaderTitle').innerHTML='An update to PEMDAS is available!';
document.getElementById('updateButton1Container').style.display='block';
document.getElementById('updateButton2Title').innerHTML='Remind Me Later';
document.getElementById('update23ButtonSpacer').style.width='6px';
document.getElementById('updateButton3Title').innerHTML='Download';
activateModalDisplay();
}
function activateModalDisplay()
{
currentResizeMode=1;
previousExpandedSize.width=expandedSize.width;
previousExpandedSize.height=expandedSize.height;
if (expandedSize.width<defaultSize.width) {
expandedSize.width=defaultSize.width;
}
if (expandedSize.height<defaultSize.height) {
expandedSize.height=defaultSize.height;
}
if (isKeyboardHidden) {
refreshWidgetExpandedSize();
}
document.getElementById('updateDivContainer').style.display='block';
}
function deactivateModalDisplay()
{
document.getElementById('updateDivContainer').style.display='none';
currentResizeMode=0;
expandedSize.width=previousExpandedSize.width;
expandedSize.height=previousExpandedSize.height;
if (isKeyboardHidden) {
refreshWidgetExpandedSize();
}
}