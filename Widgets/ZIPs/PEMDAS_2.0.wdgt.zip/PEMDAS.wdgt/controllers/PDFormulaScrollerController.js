function PDFormulaScrollerController()
{
var masterScrollbackArray;
var currentIndex;
var justCalculatedEquation=0;
var self = this;
this.init=function() {
masterScrollbackArray = new Array(); 
masterScrollbackArray[0]="";
currentIndex=0;
}
this.addCalculatedString=function(calculatedString) {
masterScrollbackArray[masterScrollbackArray.length-1]=calculatedString;
currentIndex=masterScrollbackArray.length-1; 
masterScrollbackArray[masterScrollbackArray.length]=""; 
}
this.stringForPreviousIndexFromString=function(potentiallyModifiedString) {
if (currentIndex==0) { 
return null;
}
masterScrollbackArray[currentIndex]=potentiallyModifiedString
currentIndex--;
return masterScrollbackArray[currentIndex];
}
this.stringForNextIndexFromString=function(potentiallyModifiedString) {
if (currentIndex==(masterScrollbackArray.length-1)) { 
return null;
}
if (justCalculatedEquation) {
currentIndex=masterScrollbackArray.length-1; 
} else {
masterScrollbackArray[currentIndex]=potentiallyModifiedString;		
currentIndex++;
}
return masterScrollbackArray[currentIndex];
}
this.incrementCurrentIndexToLastIndex=function() {
currentIndex=masterScrollbackArray.length-1;
}
this.setJustCalculatedEquation=function(newJustCalculatedEquation) {
justCalculatedEquation=newJustCalculatedEquation;
}
this.clearAll=function() {
masterScrollbackArray = new Array(); 
masterScrollbackArray[0]="";
currentIndex=0;
justCalculatedEquation=0;
}
}