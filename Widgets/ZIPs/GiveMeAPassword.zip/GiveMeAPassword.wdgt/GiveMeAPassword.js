var req = new XMLHttpRequest();
var req_desc = new XMLHttpRequest();
var url = "http://www.givemeapassword.com/passwordRequest.php";

var gInfoButton, gDoneButton;
var gFrontHeight, gFrontWidth;

function getPassword() 
{
	var length = document.getElementById('length').value;
	if (document.getElementById('lowercase').checked)
	{
		var lowercase = "yes";
	}
	else
	{
		var lowercase = "no";
	}
	if (document.getElementById('uppercase').checked)
	{
		var uppercase = "yes";
	}
	else
	{
		var uppercase = "no";
	}
	if (document.getElementById('numbers').checked)
	{
		var numbers = "yes";
	}
	else
	{
		var numbers = "no";
	}
	if (document.getElementById('special').checked)
	{
		var special = "yes";
	}
	else
	{
		var special = "no";
	}
	
	var temppurl = url + "?length=" + length + "&lowercase=" + lowercase + "&uppercase=" + uppercase + "&numbers=" + numbers + "&special=" + special;

	req.onreadystatechange = processReqChange;
	req.overrideMimeType("text/xml");
	req.open("GET",temppurl,true);
	req.setRequestHeader("Cache-Control", "no-cache");
	req.send(null);
}

function processReqChange() 
{	
	if (req.readyState == 4) 
	{
		// only if "OK"
		if (req.status == 200) 
		{
			document.getElementById('password').value = req.responseText;
			
			if (document.getElementById('highlight').checked)
			{
				document.getElementById('password').select();
			}
			
			if (document.getElementById('copy').checked)
			{
				//Auto copy to clipboard
				script = "/usr/bin/osascript -e 'set the clipboard to \"" + req.responseText + "\"'";
				widget.system(script, null);
			}
			
			if (document.getElementById('close').checked)
			{
				setTimeout('getURL("")', 400);
			}
			
		}
	}
}

function setup()
{
	if(window.widget)		// always check to make sure that you are running in Dashboard
	{
		// The preferences are retrieved:
		var length = widget.preferenceForKey("length");
		var lowercase = widget.preferenceForKey("lowercase");
		var uppercase = widget.preferenceForKey("uppercase");
		var numbers = widget.preferenceForKey("numbers");
		var special = widget.preferenceForKey("special");
		var copy = widget.preferenceForKey("copy");
		var highlight = widget.preferenceForKey("highlight");
		var close = widget.preferenceForKey("close");

		if (length && length.length > 0) 
		{											
			document.getElementById("length").value = length;
		}
		else
		{
			document.getElementById("length").value = "14";
		}
		
		if (lowercase && lowercase == "yes")
		{
			document.getElementById("lowercase").checked = true;
		}
		else if (lowercase == "no")
		{
			document.getElementById("lowercase").checked = false;
		}
		
		if (uppercase && uppercase == "yes")
		{
			document.getElementById("uppercase").checked = true;
		}
		else if (uppercase == "no")
		{
			document.getElementById("uppercase").checked = false;
		}
		
		if (numbers && numbers == "yes")
		{
			document.getElementById("numbers").checked = true;
		}
		else if (numbers == "no")
		{
			document.getElementById("numbers").checked = false;
		}
		
		if (special && special == "yes")
		{
			document.getElementById("special").checked = true;
		}
		else if (special == "no")
		{
			document.getElementById("special").checked = false;
		}
		
		if (copy && copy == "yes")
		{
			document.getElementById("copy").checked = true;
		}
		else if (copy == "no")
		{
			document.getElementById("copy").checked = false;
		}
		
		if (highlight && highlight == "yes")
		{
			document.getElementById("highlight").checked = true;
		}
		else if (highlight == "no")
		{
			document.getElementById("highlight").checked = false;
		}
		
		if (close && close == "yes")
		{
			document.getElementById("close").checked = true;
		}
		else if (close == "no")
		{
			document.getElementById("close").checked = false;
		}
		
		gInfoButton = new AppleInfoButton(document.getElementById("infoButton"), document.getElementById("front"), "black", "black", showPrefs);
		gDoneButton = new AppleGlassButton(document.getElementById("doneButton"), "Done", hidePrefs);

	}
}


function saveSettings()
{	
	var length = document.getElementById("length").value;
	if (document.getElementById("lowercase").checked)
	{
		var lowercase = "yes";
	}
	else
	{
		var lowercase = "no";
	}

	if (document.getElementById("uppercase").checked)
	{
		var uppercase = "yes";
	}
	else
	{
		var uppercase = "no";
	}
	
	if (document.getElementById("numbers").checked)
	{
		var numbers = "yes";
	}
	else
	{
		var numbers = "no";
	}
	
	if (document.getElementById("special").checked)
	{
		var lowercase = "special";
	}
	else
	{
		var lowercase = "special";
	}
	
	if (document.getElementById("copy").checked)
	{
		var copy = "yes";
	}
	else
	{
		var copy = "no";
	}
	
	if (document.getElementById("highlight").checked)
	{
		var highlight = "yes";
	}
	else
	{
		var highlight = "no";
	}
	
	if (document.getElementById("close").checked)
	{
		var close = "yes";
	}
	else
	{
		var close = "no";
	}
	

	widget.setPreferenceForKey(length,"length");
	widget.setPreferenceForKey(lowercase,"lowercase");
	widget.setPreferenceForKey(uppercase,"uppercase");
	widget.setPreferenceForKey(numbers,"numbers");
	widget.setPreferenceForKey(special,"special");
	widget.setPreferenceForKey(special,"copy");
	widget.setPreferenceForKey(special,"highlight");
	widget.setPreferenceForKey(special,"close");
		
	hidePrefs();
	
} 


function showPrefs()
{
	document.body.background = 'back.png';
	window.resizeTo(Stretcher.widget_width, Stretcher.max);
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget)
		widget.prepareForTransition("ToBack");		// freezes the widget so that you can change it without the user noticing
	
	front.style.display="none";		// hide the front
	back.style.display="block";		// show the back
	
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);		// and flip the widget over	

	document.getElementById('fliprollie').style.display = 'none';  // clean up the front side - hide the circle behind the info button
	
}


function hidePrefs()
{
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget)
		widget.prepareForTransition("ToFront");		// freezes the widget and prepares it for the flip back to the front
	
	back.style.display="none";			// hide the back
	front.style.display="block";		// show the front
	
	window.resizeTo(Stretcher.widget_width, Stretcher.min);
	
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);		// and flip the widget back to the front
	
	document.body.background = 'Default.png';
}



// PREFERENCE BUTTON ANIMATION (- the pref flipper fade in/out)

var flipShown = false;		// a flag used to signify if the flipper is currently shown or not.


// A structure that holds information that is needed for the animation to run.
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};


// mousemove() is the event handle assigned to the onmousemove property on the front div of the widget. 
// It is triggered whenever a mouse is moved within the bounds of your widget.  It prepares the
// preference flipper fade and then calls animate() to performs the animation.

function mousemove (event)
{
	if (!flipShown)			// if the preferences flipper is not already showing...
	{
		if (animation.timer != null)			// reset the animation timer value, in case a value was left behind
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		
		var starttime = (new Date).getTime() - 13; 		// set it back one frame
		
		animation.duration = 500;												// animation time, in ms
		animation.starttime = starttime;										// specify the start time
		animation.firstElement = document.getElementById ('flip');		// specify the element to fade
		animation.timer = setInterval ("animate();", 13);						// set the animation function
		animation.from = animation.now;											// beginning opacity (not ness. 0)
		animation.to = 1.0;														// final opacity
		animate();																// begin animation
		flipShown = true;														// mark the flipper as animated
	}
}

// mouseexit() is the opposite of mousemove() in that it preps the preferences flipper
// to disappear.  It adds the appropriate values to the animation data structure and sets the animation in motion.

function mouseexit (event)
{
	if (flipShown)
	{
		// fade in the flip widget
		if (animation.timer != null)
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		
		var starttime = (new Date).getTime() - 13;
		
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}


// animate() performs the fade animation for the preferences flipper. It uses the opacity CSS property to simulate a fade.

function animate()
{
	var T;
	var ease;
	var time = (new Date).getTime();
		
	
	T = limit_3(time-animation.starttime, 0, animation.duration);
	
	if (T >= animation.duration)
	{
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	}
	else
	{
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}
	
	animation.firstElement.style.opacity = animation.now;
}


// these functions are utilities used by animate()

function limit_3 (a, b, c)
{
    return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease)
{
    return from + (to - from) * ease;
}

// these functions are called when the info button itself receives onmouseover and onmouseout events

function enterflip(event)
{
	document.getElementById('fliprollie').style.display = 'block';
}

function exitflip(event)
{
	document.getElementById('fliprollie').style.display = 'none';
}
function getURL(url) { //be sure to use single quotes!
	widget.openURL(url);
}