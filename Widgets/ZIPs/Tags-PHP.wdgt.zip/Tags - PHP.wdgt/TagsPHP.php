<?
function writeOutput($Output, $FileName)
{
	@unlink($FileName);
	if(!$handle = @fopen($FileName, 'w')) {
		echo "Cannot open file ($FileName)";
		exit;
	}
	if(@fwrite($handle, $Output) === FALSE) {
		echo "Cannot write to file ($FileName)";
		exit;
	}
}


function getFormattedTag($value)
{
	$Output .= ' ' . $value['type'] . ' <b>' . $value['refname'] . '</b>(';
	$MethodCount = 0;
	if(count($value['methods']) > 0) {
		foreach($value['methods'] as $method) {
			if($MethodCount++ > 0) $Output .= ', ';
			if($method['opt'] == 1) $Output .= '[';
			$Output .= $method['type'] . ' ' . $method['parameter'];
			if($method['opt'] == 1) $Output .= ']';
		}
	}
	$Output .= ')';
	return $Output;
}

ob_start();

$serializedData = file_get_contents('TagsPHP.txt');
$functions = unserialize($serializedData);

$SearchString = $argv[1];
if($SearchString != '') {
	foreach($functions as $key => $value) {
		if(strstr($key, $SearchString)) {
			echo '<a href="#" onclick="go(\'' . str_replace('_', '-', $key) . '\');"><b style="font-size: 120%;">' . $key . '()</a></b><br>';
			echo '<i>' . $value['refpurpose'] . '</i><br>';
			echo '<a href="#" onclick="copyCodeSnippet(\'' . trim(strip_tags(getFormattedTag($value))) . '\');">';
			echo '<span style="font-size: 90%;">' . getFormattedTag($value) . '</span>';
			echo '</a>';
			echo '<hr>';
		}
	}
}

$Output = ob_get_contents();
ob_end_clean();
writeOutput($Output, 'Output.txt');
?>