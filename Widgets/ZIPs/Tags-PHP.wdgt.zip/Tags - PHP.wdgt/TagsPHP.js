image1 = new Image();
image1.src = "indicator.gif";

function SetUp()
{
	//smallWindow();
}


function showStatusMessage(Message)
{
	var Output = "";
	if(Message != "") {
		var Output = "<img name='image1' src='indicator.gif'>";
	}
	return Output;
}

var timeout = null;
function liveReqStart() {
	if(timeout) {
		window.clearTimeout(timeout);
	}
	timeout = window.setTimeout("searchTags()", 500);
}

function searchTags()
{
	var String = document.getElementById("Searchbox").value;
	if(String.length > 0) {
		largeWindow();
		document.getElementById("Tags").innerHTML = "Searching for <b>'" + String + "'</b>:";
		command = widget.system("/usr/bin/php TagsPHP.php '" + String + "'", showTags);
	} else {
		smallWindow();
	}
}

function showTags()
{
	xmlRequest = new XMLHttpRequest();
	xmlRequest.setRequestHeader("Cache-Control", "no-cache");
	xmlRequest.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
	xmlRequest.open("GET","Output.txt",null);
	xmlRequest.onreadystatechange = function() {
		if(null == xmlRequest.readyState) return;
		if(xmlRequest.readyState == 4) {
			document.getElementById("Tags").innerHTML = xmlRequest.responseText;
		}
	}
	xmlRequest.send(null);
}


function copyCodeSnippet(Snippet) {
	//document.getElementById("statusUpdate").innerHTML = showStatusMessage("Copying Snippet...");
	command = widget.system("/usr/bin/php copy.php '" + Snippet + "'", copyCodeSnippetDone);
}

function copyCodeSnippetDone(cmd)
{
	var output = cmd.outputString;
	//document.getElementById("statusUpdate").innerHTML = showStatusMessage("");
}


function smallWindow()
{
	document.body.style.backgroundImage='url(Default.png)';
	document.getElementById("Tags").className = 'inactive';
	window.resizeTo(350, 60);
}
function largeWindow()
{
	document.body.style.backgroundImage='url(Large.png)';
	document.getElementById("Tags").className = 'active';
	window.resizeTo(350, 400);
}

function go(func)
{
	widget.openURL("http://php.net/manual/en/function." + func + ".php");
}