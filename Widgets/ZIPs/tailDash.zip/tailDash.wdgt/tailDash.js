//tail viewer �protagonist.co.uk v1.6.1
//please email comments to support@protagonist.co.uk

//basic setup globals
var lastPos; // tracks where the last mouse position was throughout the drag
var timerInterval = null; //resetting initial timer
var advancedflag = 0; //to deal with whether the user has selected the advanced functions
var tailselect = "/usr/bin/tail"; //location of tail on the system
var loginuse; //this is where the selected log path is stored
var numLines;

//json loaded data store
var data;

//pref settings
var logselectsettings;
var refreshselect;
var lineselect;
var logselect;
var fontselect;
var colourselect;
var sizeselect;
var backgroundselect;
var input1;
var input2;

var x = 800;
var y = 200;

//START
if (window.widget) {
   widget.onhide = onhide;
   widget.onshow = onshow;
}

//little check to get the running version of osx
function getOsVersion() {
	var osData = widget.system("/usr/bin/tail /System/Library/CoreServices/SystemVersion.plist", null);
	var splitContent = osData.outputString.split("\n");
	//don't bother parsing the xml, just grab the right bit of the data
 	versionNum = splitContent[7].substring(9,13);
	
	return versionNum;	
}

//setting up before things start
function setup() {
	//first, we load the prefs
	loadPrefs();
	///now, get the os and set up the right log files
	var osVersion = getOsVersion();
	if (osVersion == "10.4") {
		//alert ("10.4 tiger preferences loaded...");
		logselectsettings = "tigerselect"; 
	} else if (osVersion == "10.5") { // quick little patch by andrew to deal with snow
		//alert ("10.5 leopard preferences loaded...");
		logselectsettings = "leopardselect";
	} else {
		logselectsettings = "leopardselect";
	}

 	//then, generate the other menus from the defaults
	generateMenu("logselect");	
	generateMenu("refreshselect");
	generateMenu("lineselect");
	generateMenu("fontselect");
	generateMenu("colourselect");
	generateMenu("sizeselect");
	generateMenu("backgroundselect");	
	
	//final pieces
	frontResize('back'); //performs resize from user prefs
	prefChangeActivation();	//load up the graphical changes
	logStart(); //kick everything off and we're done
}

//loads prefs and if there are none, sets to a default value
function loadPrefs() {
	// first test to make sure we have a preferences file to work with
	var installedtest = widget.system("/bin/ls ~/Library/Preferences/widget-uk.co.protagonist.widget.tailDash.plist", null).errorString;
	if (installedtest != undefined) { //ie can't find the pref file therefore first run
		createDefaults();
	} else {
	}

	//test for multiple instances of the widget
	if (widget.preferenceForKey(createKey('logselect')) == undefined) {
		createDefaults();
	}

	
	//load the settings
	var input = widget.system("/bin/cat ~/Library/Application\\ Support/tailDash/settings.txt", null).outputString;
	data = eval('(' + input + ')');

	// get the preferences
	logselect = widget.preferenceForKey(createKey("logselect"));
	refreshselect = widget.preferenceForKey(createKey("refreshselect"));
	lineselect = widget.preferenceForKey(createKey("lineselect"));
	fontselect = widget.preferenceForKey(createKey("fontselect"));
	colourselect = widget.preferenceForKey(createKey("colourselect"));
	sizeselect = widget.preferenceForKey(createKey("sizeselect"));
	backgroundselect = widget.preferenceForKey(createKey("backgroundselect"));
	input1 = widget.preferenceForKey(createKey("input1"));
	input2 = widget.preferenceForKey(createKey("input2"));

	x = widget.preferenceForKey(createKey("windowX"));
	y = widget.preferenceForKey(createKey("windowY"));
}

//just dealing with ditching of previous instances of the widget on removal
function onremove() {
	if (window.widget) {
	 	widget.setPreferenceForKey(null, createKey('logselect'));
	 	widget.setPreferenceForKey(null, createKey('refreshselect'));
	 	widget.setPreferenceForKey(null, createKey('lineselect'));
	 	widget.setPreferenceForKey(null, createKey('fontselect'));
	 	widget.setPreferenceForKey(null, createKey('colourselect'));
	 	widget.setPreferenceForKey(null, createKey('sizeselect'));
	 	widget.setPreferenceForKey(null, createKey('backgroundselect'));
		widget.setPreferenceForKey(null, createKey('input1'));
		widget.setPreferenceForKey(null, createKey('input2'));
		widget.setPreferenceForKey(null, createKey('windowX'));
		widget.setPreferenceForKey(null, createKey('windowY'));
	}
}
//trigger for this
if (window.widget) {
	widget.onremove = onremove;
}

function createDefaults() {
 	widget.setPreferenceForKey(0, createKey('logselect'));
 	widget.setPreferenceForKey(1, createKey('refreshselect'));
 	widget.setPreferenceForKey(1, createKey('lineselect'));
 	widget.setPreferenceForKey(0, createKey('fontselect'));
 	widget.setPreferenceForKey(2, createKey('colourselect'));
 	widget.setPreferenceForKey(1, createKey('sizeselect'));
 	widget.setPreferenceForKey(7, createKey('backgroundselect'));

	widget.setPreferenceForKey("", createKey('input1'));
	widget.setPreferenceForKey("", createKey('input2'));
	
	//trash the directory
	var output = widget.system("/bin/rm -rf ~/Library/Application\\ Support/tailDash", null).errorString;	
	//create the storage area
	var output = widget.system("/bin/mkdir ~/Library/Application\\ Support/tailDash", null).errorString;
	//create the default settings
	var output = widget.system("/bin/cp ~/Library/widgets/tailDash.wdgt/settings.txt ~/Library/Application\\ Support/tailDash/settings.txt", null).outputString;
	
}

function debug(functionName, input) {
	// alert (functionName + " error: " + input);
}

//menu is the desired menu, selected is the user preference setting
function generateMenu(menu) {
	//this is using the menu data to place the generated menu (html element) itself
	//as well as to access the variable
	
	var settings;
	var defaultselected = eval(menu);
	var input = document.getElementById(menu);
	
	if (menu != "logselect") {
		settings = eval("data." + menu + "settings"); //check
	} else { //little exception for the log data to support tiger and leopard users
		settings = eval("data." + logselectsettings + "settings"); //check
	}

	//makes the options
	for(i = 0; i < settings.length; i++) {
		input.options[i] = new Option(settings[i]["Name"], settings[i]["Option"]);
	}
	//now just add on the advanced settings
	if (menu == "logselect") {
		input.options[i] = new Option("Advanced...", "advanced");
		loginuse = input.options[0].value;
	}
	//set the selected value from preferences
	input.options[defaultselected].selected = true;
	if (defaultselected == settings.length && menu == "logselect") {
		advancedflag = 1;
		showAdvanced();		
	}
}

//PREF SWITCHING CODE
function showPrefs() {
	logStop();
	frontResize('front');
	
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget)
		widget.prepareForTransition("ToBack");
	
	front.style.display = "none";	
	back.style.display = "block";
	
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);

	document.getElementById('fliprollie').style.display = 'none';
	document.getElementById('growbox').style.display = 'block';
}

function hidePrefs() {
	prefChangeActivation();
	
	document.getElementById("output").innerHTML = "loading new information from file: " + loginuse + "...";
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget)
		widget.prepareForTransition("ToFront");
	
	back.style.display = "none"; // hide the back
	front.style.display = "block"; // show the front
	
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);
		
	if (advancedflag == 1) { //if the user is in advanced - this saves out the new tail and log selections
		loginuse = document.getElementById('input2').value;
		tailselect = document.getElementById('input1').value;
			if(window.widget) {
				widget.setPreferenceForKey(logselect, createKey('logselect'));
			}
	}
		
	frontResize('back'); //performs resize after flip
	logStart(); //restarts timer with the potential new refresh rate
}

//USER PREFS CODE
//called when the user makes a change
//saves out the change to the pref file
function prefChange(pref, input) {
	var	settingIndex = parseInt(pref.selectedIndex);
	//save the preference
	if(window.widget) {
		widget.setPreferenceForKey(settingIndex, createKey(input));
	}

	//little test for the advanced feature
	var data = document.getElementById(input);
	if (data != null) {
		var tester = data.options[data.selectedIndex].value
		if (tester == "advanced") { //little test for the advanced feature
			showAdvanced();
		}	
	}
}

//little bit to saved the advanced settings, if they have been used
function advancedPrefChange() {
	input1 = document.getElementById('input1').value
	input2 = document.getElementById('input2').value
	widget.setPreferenceForKey(input1, createKey("input1"));
	widget.setPreferenceForKey(input2, createKey("input2"));
	
}

//this is called when the prefs are exited 
//it gets all the user settings and applies them across the board
function prefChangeActivation() {
	var data = "Null";
	var selection = "Null";
	
	//now we go through and grab all the data just to be belt and braces 
	//can't do it in a loop as it's a little different every time	
	//refresh selection
	data = document.getElementById('refreshselect');
	selection = data.options[data.selectedIndex].value;	
	refreshselect = selection;
	//number of lines selection
	data = document.getElementById('lineselect');
	selection = data.options[data.selectedIndex].value;
	numLines = selection
	//font selection
	data = document.getElementById('fontselect');
	selection = data.options[data.selectedIndex].value;
	document.getElementById('output').style.fontFamily= selection;
	//colour selection
	data = document.getElementById('colourselect');
	selection = data.options[data.selectedIndex].value;
	document.getElementById('output').style.color = selection;	
	//size (font) selection
	data = document.getElementById('sizeselect');
	selection = data.options[data.selectedIndex].value;
	document.getElementById('output').style.fontSize = selection + "px";
	//background selection
	data = document.getElementById('backgroundselect');
	selection = data.options[data.selectedIndex].value;
	//TODO sort this bit out as we are replacing the background bit
	document.getElementById('backgroundImage').style.opacity = selection;
	//log selection
	data = document.getElementById('logselect');
	selection = parseInt(data.selectedIndex); // this gets the index
	logselect = selection;
	selection = data.options[data.selectedIndex].value; //this gets the actual log
	loginuse = selection;
	
	//if advanced options have been set, should save them out
	if (advancedflag == 1) { //TODO change to true false
		advancedPrefChange();
	}
}

//to enable multiple instances
function createKey(key) {
    return widget.identifier + "-" + key;
}

// ADVANCED PREFS CODE
//handles the advanced user settings case
//this has been separated so on reload if advanced options have been selected, it remembers
function showAdvanced() {
	//show graphical elements
	document.getElementById('logselect').style.display = 'none';
	document.getElementById('close').style.display = 'block';
	document.getElementById('advanced').style.display = 'block';

	//functional bits
	if (input1 != "") { //this test to see whether advanced settings have ever been used
		document.getElementById('input1').value = input1;
		document.getElementById('input2').value = input2;
	} else {
		document.getElementById('input1').value = tailselect;
		document.getElementById('input2').value = loginuse;
	}
	
	advancedflag = 1;
}

//on hiding, the logselect is set back to a default of zero
function hideAdvanced() { //sets log back to normal
	//graphical elements
	document.getElementById('logselect').style.display = 'block'; 
	document.getElementById('close').style.display = 'none';
	document.getElementById('advanced').style.display = 'none';
	document.getElementById('close').style.background = "url('Images/close.png') no-repeat top left";

	//functional bits
	document.getElementById('logselect').selectedIndex = 0;
	widget.setPreferenceForKey(0, createKey('logselect'));
	advancedflag = 0; //resets the main flag
}

//calls the created settings.txt file in application support
function editSettings() {
	widget.system("/usr/bin/open ~/Library/Application\\ Support/tailDash/settings.txt", null);
}

//Log triggers
//LOG UPDATING RELATED CODE
function getlog() {	
	tagparsing = " | sed -e 's/\\</\\&#60;/g' -e 's/\\>/\\&#62;/g'";
	var obj = widget.system(tailselect + " -n" + numLines + " " + loginuse + tagparsing, statusCheck);
}

//little test to make sure everything is cool
//this is called frequently, make sure it is minimal
function statusCheck(input) {
	var logOutput = "";
	var loopCount = numLines;
	output = input.outputString;
	if (output != null) {
		var test = output.split("\n");
		if (test.length <= numLines) {loopCount = test.length - 1;} //to deal with the length overshooting bug
		for ($i = 0; $i <= loopCount; ++$i) {
			if (test[$i] != "undefined") {
				logOutput = logOutput + test[$i] + "<br>";
			}
		}
	} else {
		logOutput = "sorry, " + loginuse + " is an empty log file. please make another selection";
	}

	document.getElementById("output").innerHTML = logOutput;
	input.cancel;
}

function logStart() {
	getlog(); //grabs the log immediately regardless of the timer to get the info soonest
	if (timerInterval == null) {
		timerInterval = setInterval("getlog()", (refreshselect * 1000));
	}
}

function logStop() {
	if (timerInterval != null) {
		clearInterval(timerInterval);
		timerInterval = null;
	}
}

//ON SHOW AND HIDE
function onshow() {
	logStart();
}

function onhide () {
	logStop();
}

function frontResize(input) {
	if (input == 'front') {
		
		window.resizeTo(800, 200);
		document.getElementById('fliprollie').style.display = 'none';
		document.getElementById('flip').style.display = 'none';
		document.getElementById('growbox').style.display = 'none';	
	} else {
		document.getElementById('flip').style.display = 'block';
		setTimeout("tempfunc()",1000);
	}	
}

function tempfunc() {
	window.resizeTo(x,y);
}

function frontReset() { //this is the reset button for the window size
	document.getElementById('resetbutton_roll').style.display = 'none';
	window.resizeTo(800, 200);

	if(window.widget) { //so it saves the preference
		widget.setPreferenceForKey(window.outerWidth, createKey('windowX'));
		widget.setPreferenceForKey(window.outerHeight, createKey('windowY'));
	}
}

//GRAPHICAL SECTION
function mouseDown(event){
	logStop();
	x = event.x + window.screenX; // the placement of the click
	y = event.y + window.screenY;
	document.addEventListener("mousemove", mouseMove, true); 
	document.addEventListener("mouseup", mouseUp, true);
	lastPos = {x:x, y:y};
	event.stopPropagation();
	event.preventDefault();
}

function mouseMove(event) {
	var screenX = event.x + window.screenX;
	var screenY = event.y + window.screenY;
		
	var deltaX = 0;		// will hold the change since the last mouseMove event
	var deltaY = 0;

	if ( (window.outerWidth + (screenX - lastPos.x)) >= 60 && (window.outerWidth + (screenX - lastPos.x)) <= 1600) { 		// sets a minimum width constraint
		deltaX = screenX - lastPos.x;
		lastPos.x = screenX;
	}

	if ((window.outerHeight + (screenY - lastPos.y)) >= 25 && (window.outerHeight + (screenY - lastPos.y))<= 500) {// setting contrains for the height
		deltaY = screenY - lastPos.y;
		lastPos.y = screenY;
	}
	
	window.resizeBy(deltaX, deltaY);
	event.stopPropagation();
	event.preventDefault();
}

function mouseUp(event) {
	document.removeEventListener("mousemove", mouseMove, true);
	document.removeEventListener("mouseup", mouseUp, true);	

	if(window.widget) { 
		widget.setPreferenceForKey(window.outerWidth, createKey('windowX'));
		widget.setPreferenceForKey(window.outerHeight, createKey('windowY'));
	}

	x = window.outerWidth;
	y = window.outerHeight;

	event.stopPropagation();
	event.preventDefault();
	
	logStart();
}

function updateCoordinates() {
	coordinates.innerText = "(" + window.outerWidth +"," + window.outerHeight + ")";

	event.stopPropagation();
	event.preventDefault();
}

//floating elements code
function enterflip(event) {
	document.getElementById('fliprollie').style.display = 'block';
}

function exitflip(event) {
	document.getElementById('fliprollie').style.display = 'none';
}

function enterreset(event) {
	document.getElementById('resetbutton_roll').style.display = 'block';
}

function exitreset(event) {
	document.getElementById('resetbutton_roll').style.display = 'none';
}

// couple of graphical elements
function resetIn() {
	document.getElementById('close').style.background = "url('Images/close_2.png') no-repeat top left";
}

function resetOut() {
	document.getElementById('close').style.background = "url('Images/close.png') no-repeat top left";
}