/*
             Name: WIDGET_NAME
          Version: WIDGET_VERSION
              Web: http://liepins.org/dashboard/WIDGET_NAME

    First Created: DATE
      Last Change: DATE
         Template: 0.1

           Author: _Lasar Liepins
            eMail: lasar@liepins.net
*/

function addEventHandlers () {
	if ( window.widget ) {
		widget.onshow = onshowHandler;
		widget.onhide = onhideHandler;
		window.onfocus = onfocusHandler;
		window.onblur = onblurHandler;
		widget.ondragstart = ondragstartHandler;
		widget.ondragstop = ondragstopHandler;
		widget.onremove = onremoveHandler;
	}
}

function setPref ( name, value ) {
	if ( window.widget ) {
		widget.setPreferenceForKey ( name, value );
	}
}

function getPref ( name ) {
	if ( window.widget ) {
		widget.getPreferenceForKey ( name );
	}
}

function system ( command, callback ) {
	if ( window.widget ) {
		return ret = widget.system(command,callback).outputString;
	}
}

function updateHTML ( id, html ) {
	document.getElementById(id).innerHTML = html;
}

// Functions directly taken from the Dashboard Programming Guide
// http://developer.apple.com/documentation/AppleApplications/Conceptual/Dashboard_Tutorial/index.html

function showPrefs () {
	var front = document.getElementById("front");
	var back = document.getElementById("back");

	if (window.widget) {
		widget.prepareForTransition("ToBack");
	}

	front.style.display="none";
	back.style.display="block";

	if (window.widget) {
		setTimeout ('widget.performTransition();', 0);
	}
}


function hidePrefs () {
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget) {
		widget.prepareForTransition("ToFront");
	}
	
	back.style.display="none";
	front.style.display="block";
	
	if (window.widget) {
		setTimeout ('widget.performTransition();', 0);
	}
}


var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};

function frontMouseMove (event) {
	if (!flipShown) {
		if (animation.timer != null) {
			clearInterval (animation.timer);
			animation.timer  = null;
		}

		var starttime = (new Date).getTime() - 13;

		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 1.0;
		animate();
		flipShown = true;
	}
}

function frontMouseExit (event) {
	if (flipShown) {
		// fade in the info button
		if (animation.timer != null) {
			clearInterval (animation.timer);
			animation.timer  = null;
		}

		var starttime = (new Date).getTime() - 13;

		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}

function animate () {
	var T;
	var ease;
	var time = (new Date).getTime();

	T = limit_3(time-animation.starttime, 0, animation.duration);
	
	if (T >= animation.duration) {
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	} else {
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}
	
	animation.firstElement.style.opacity = animation.now;
}

function limit_3 (a, b, c) {
	return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease) {
	return from + (to - from) * ease;
}




var lastPos;
function resizeMouseDown(event){
	var x = event.x + window.screenX;		// the placement of the click
	var y = event.y + window.screenY;
	document.addEventListener("mousemove", resizeMouseMove, true); 
	document.addEventListener("mouseup", resizeMouseUp, true);
	lastPos = {x:x, y:y};
	event.stopPropagation();
	event.preventDefault();
}

function resizeMouseMove(event) {
	var screenX = event.x + window.screenX;
	var screenY = event.y + window.screenY;
	
	var deltaX = 0;		// will hold the change since the last mouseMove event
	var deltaY = 0;

	if ( (window.outerWidth + (screenX - lastPos.x)) >= 60 && (window.outerWidth + (screenX - lastPos.x)) <= 1600) { 		// sets a minimum width constraint
		deltaX = screenX - lastPos.x;
		lastPos.x = screenX;									
	}

	if ( (window.outerHeight + (screenY - lastPos.y)) >= 25 && (window.outerHeight + (screenY - lastPos.y))<= 500) {		// setting contrains for the heght
		deltaY = screenY - lastPos.y;
		lastPos.y = screenY;
	}
	
	window.resizeBy(deltaX, deltaY);
	//updateCoordinates();

	if ( window.widget ) {
		widget.setPreferenceForKey ( "window_x", screenX );
		widget.setPreferenceForKey ( "window_y", screenY );
	}

	event.stopPropagation();
	event.preventDefault();
}

function resizeMouseUp(event) {
	document.removeEventListener("mousemove", resizeMouseMove, true);
	document.removeEventListener("mouseup", resizeMouseUp, true);	

	if(window.widget) {
		widget.setPreferenceForKey(window.outerWidth, 'windowX');
		widget.setPreferenceForKey(window.outerHeight, 'windowY');
	}

	event.stopPropagation();
	event.preventDefault();
}
