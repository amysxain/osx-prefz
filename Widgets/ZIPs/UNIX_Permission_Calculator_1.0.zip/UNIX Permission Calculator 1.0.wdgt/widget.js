/*
             Name: WIDGET_NAME
          Version: WIDGET_VERSION
              Web: http://liepins.org/dashboard/WIDGET_NAME

    First Created: DATE
      Last Change: DATE
         Template: 0.1

           Author: _Lasar Liepins
            eMail: lasar@liepins.net
*/

////////////////////////////////////////////////////////////////////////////////
// Settings

// Default Window size
window_x = 328;
window_y = 215;

////////////////////////////////////////////////////////////////////////////////
// Handlers

function onloadHandler() {
	// Do stuff when loading the widget
	window.resizeTo(window_x, window_y);
}

function timerHandler () {
	// Do stuff every timer_interval milliseconds
}

function onshowHandler () {
}

function onhideHandler () {
}

function onfocusHandler () {
}

function onblurHandler () {
}

function ondragstartHandler () {
}

function ondragstopHandler () {
	// Does not work?
}

function onremoveHandler () {
}

////////////////////////////////////////////////////////////////////////////////
// Other functions

function startTimer () {
}

function stopTimer () {
	clearInterval ( mainTimer );
	mainTimer = null;
}

function readPrefs () {
}

// ---->

function check2other ()
        {
                check2num ()
                check2string ()
        }

function num2other ()
        {
                clearcheck ()
                num2check ()
                check2string ()
        }

function string2other ()
        {
                clearcheck ()
                string2check ()
                check2num ()
        }

function clearcheck ()
        {
                document.forms[0].o_r.checked = false
                document.forms[0].o_w.checked = false
                document.forms[0].o_x.checked = false
                document.forms[0].g_r.checked = false
                document.forms[0].g_w.checked = false
                document.forms[0].g_x.checked = false
                document.forms[0].e_r.checked = false
                document.forms[0].e_w.checked = false
                document.forms[0].e_x.checked = false
        }

function string2check ()
        {
                var str = document.forms[0].chmodstring.value

				var did_msg = false;

                if ( str.charAt ( 0 ) == 'd' ) { document.forms[0].dir.checked = true }
                else if ( str.charAt ( 0 ) == '-' ) { document.forms[0].dir.checked = false }
                else { updateHTML ( 'msg', 'The string you entered is not valid.<br>The first character must be d or -' ); did_msg=true; }

                if ( str.charAt ( 7 ) == 'r' ) { document.forms[0].e_r.checked = true } else if ( str.charAt ( 7 ) != '-' ) { updateHTML ( 'msg', 'The string you entered is not valid.<br>The eighth character must be r or -' ); did_msg=true; }
                if ( str.charAt ( 8 ) == 'w' ) { document.forms[0].e_w.checked = true } else if ( str.charAt ( 8 ) != '-' ) { updateHTML ( 'msg', 'The string you entered is not valid.<br>The ninth character must be w or -' ); did_msg=true; }
                if ( str.charAt ( 9 ) == 'x' ) { document.forms[0].e_x.checked = true } else if ( str.charAt ( 9 ) != '-' ) { updateHTML ( 'msg', 'The string you entered is not valid.<br>The tenth character must be x or -' ); did_msg=true; }
                if ( str.charAt ( 6 ) == 'x' ) { document.forms[0].g_x.checked = true } else if ( str.charAt ( 6 ) != '-' ) { updateHTML ( 'msg', 'The string you entered is not valid.<br>The seventh character must be x or -' ); did_msg=true; }
                if ( str.charAt ( 5 ) == 'w' ) { document.forms[0].g_w.checked = true } else if ( str.charAt ( 5 ) != '-' ) { updateHTML ( 'msg', 'The string you entered is not valid.<br>The sixth character must be w or -' ); did_msg=true; }
                if ( str.charAt ( 4 ) == 'r' ) { document.forms[0].g_r.checked = true } else if ( str.charAt ( 4 ) != '-' ) { updateHTML ( 'msg', 'The string you entered is not valid.<br>The fifth character must be r or -' ); did_msg=true; }
                if ( str.charAt ( 3 ) == 'x' ) { document.forms[0].o_x.checked = true } else if ( str.charAt ( 3 ) != '-' ) { updateHTML ( 'msg', 'The string you entered is not valid.<br>The fourth character must be x or -' ); did_msg=true; }
                if ( str.charAt ( 2 ) == 'w' ) { document.forms[0].o_w.checked = true } else if ( str.charAt ( 2 ) != '-' ) { updateHTML ( 'msg', 'The string you entered is not valid.<br>The third character must be w or -' ); did_msg=true; }
                if ( str.charAt ( 1 ) == 'r' ) { document.forms[0].o_r.checked = true } else if ( str.charAt ( 1 ) != '-' ) { updateHTML ( 'msg', 'The string you entered is not valid.<br>The second character must be r or -' ); did_msg=true; }

				if ( !did_msg ) {
					updateHTML ( "msg", "" );
				}
        }

function num2check ()
        {
                var chmod = document.forms[0].chmodnumber.value
                
                if ( chmod > 777 )
                        {
                                updateHTML ( 'msg', 'The number you entered is too high.<br>777 is the maximum.' )
                                document.forms[0].chmodnumber.value = 777
                                chmod = 777
                        }
                else
                        {
                                if ( chmod >= 400 )
                                        { document.forms[0].o_r.checked = true; chmod -= 400 }
                                if ( chmod >= 200 )
                                        { document.forms[0].o_w.checked = true; chmod -= 200 }
                                if ( chmod >= 100 )
                                        { document.forms[0].o_x.checked = true; chmod -= 100 }

                                if ( chmod >= 40 )
                                        { document.forms[0].g_r.checked = true; chmod -= 40 }
                                if ( chmod >= 20 )
                                        { document.forms[0].g_w.checked = true; chmod -= 20 }
                                if ( chmod >= 10 )
                                        { document.forms[0].g_x.checked = true; chmod -= 10 }

                                if ( chmod >= 4 )
                                        { document.forms[0].e_r.checked = true; chmod -= 4 }
                                if ( chmod >= 2 )
                                        { document.forms[0].e_w.checked = true; chmod -= 2 }
                                if ( chmod >= 1 )
                                        { document.forms[0].e_x.checked = true; chmod -= 1 }
                        }
        }

function check2num ()
        {
                var chmod = 0

                if ( document.forms[0].o_r.checked ) { chmod += 400 }
                if ( document.forms[0].o_w.checked ) { chmod += 200 }
                if ( document.forms[0].o_x.checked ) { chmod += 100 }
                if ( document.forms[0].g_r.checked ) { chmod += 40 }
                if ( document.forms[0].g_w.checked ) { chmod += 20 }
                if ( document.forms[0].g_x.checked ) { chmod += 10 }
                if ( document.forms[0].e_r.checked ) { chmod += 4 }
                if ( document.forms[0].e_w.checked ) { chmod += 2 }
                if ( document.forms[0].e_x.checked ) { chmod += 1 }

                if ( chmod < 10 ) { chmod = '00' + chmod }
                else if ( chmod < 100 ) { chmod = '0' + chmod }

                document.forms[0].chmodnumber.value = chmod
        }

function check2string ()
        {
                var str = ''
                
                if ( document.forms[0].dir.checked ) { str = 'd' } else { str += '-' }
                
                if ( document.forms[0].o_r.checked ) { str += 'r' } else { str += '-' }
                if ( document.forms[0].o_w.checked ) { str += 'w' } else { str += '-' }
                if ( document.forms[0].o_x.checked ) { str += 'x' } else { str += '-' }
                if ( document.forms[0].g_r.checked ) { str += 'r' } else { str += '-' }
                if ( document.forms[0].g_w.checked ) { str += 'w' } else { str += '-' }
                if ( document.forms[0].g_x.checked ) { str += 'x' } else { str += '-' }
                if ( document.forms[0].e_r.checked ) { str += 'r' } else { str += '-' }
                if ( document.forms[0].e_w.checked ) { str += 'w' } else { str += '-' }
                if ( document.forms[0].e_x.checked ) { str += 'x' } else { str += '-' }
                
                document.forms[0].chmodstring.value = str
        }

function display ( num )
        {
                document.forms[0].chmodnumber.value = num
                num2other ()
        }
