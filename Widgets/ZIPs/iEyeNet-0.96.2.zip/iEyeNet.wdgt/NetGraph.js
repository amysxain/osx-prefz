//
// NetGraph.js
//

//
// Constructor: NetGraph()
//
function NetGraph(canvasId)
{
	// This is the place where we store our points to graph.
	// The array should have the format:
	this.dataset = {
		'inboundDataSet':		[],
		'outboundDataSet':		[],
	}
	
	// The ID of the <canvas> we are to render to.
	this.canvasId = canvasId;
	this.width = 0;			// Total width of our drawing area.
	this.height = 0;		// Total height of our drawing area.
	
	// Graph dimensions
	this.graphAreaLeft = 0;
	this.graphAreaRight = 0;
	this.graphAreaTop = 0;
	this.graphAreaBottom = 0;
	this.graphAreaWidth = 0;
	this.graphAreaHeight = 0;

	// Graph scale
	// The resolution (how many X points) of the graph
	this.xPoints = 0;					// TODO: Make this a configurable option.
	this.yMax = 0;
	
	// Immediate (current) data values
	this.immediateValueIn = 0;
	this.immediateValueOut = 0;
	
	// Rendering flag. If this is set, don't render the graph (we could be still rendering in another thread).
	this.isRendering = 0;
}

//
// Method: init()
// Initialisation
//
NetGraph.prototype.init = function()
{
	// Setup
	////////
	
    var canvas = document.getElementById(this.canvasId);
    var context = canvas.getContext("2d");
	this.width = canvas.width;
	this.height = canvas.height;
	
	// Determine graph area constraints.
	this.graphAreaLeft = 6;
	this.graphAreaRight = this.width - 6;
	this.graphAreaTop = 0;
	this.graphAreaBottom = this.height;
	this.graphAreaWidth = this.graphAreaRight - this.graphAreaLeft;
	this.graphAreaHeight = this.graphAreaBottom - this.graphAreaTop;

	// This number of data points along the X axis.
	this.xPoints = this.graphAreaWidth;
	
	// The spacing between ticks on the Y axis.
	this.tickYSpacing = this.graphAreaHeight / 4;
	this.tickXSpacing = 30;
	
	// Prerendering
	///////////////

	// Pre-fill the datasets with zeros.
	this.zeroDataSet("inboundDataSet");
	this.zeroDataSet("outboundDataSet");
}

//
// Method: render()
// Render the graph
//
NetGraph.prototype.render = function()
{
	if (!enableGraphRendering || this.isRendering)				// Don't do anything is graph rendering is disabled (ie. the widget is hidden) or another thread is still rendering.
		return;
		
	this.isRendering = true;
		
    var canvas = document.getElementById(this.canvasId);
	this.width = canvas.width;
    var context = canvas.getContext("2d");
	
	// Clear the graph area and paint the graph background
	context.clearRect(this.graphAreaLeft, this.graphAreaTop, this.graphAreaWidth, this.graphAreaHeight);
    context.setFillColor(0.1, 0.1, 0.1, 0.8);
    context.fillRect(this.graphAreaLeft, this.graphAreaTop, this.graphAreaWidth, this.graphAreaHeight);
	
	// Clear the immediate indicator area to the right and left of the graph
	context.clearRect(this.graphAreaRight, this.graphAreaTop, this.width, this.graphAreaHeight);
	context.clearRect(0, this.graphAreaTop, this.graphAreaLeft, this.graphAreaHeight);
	
	// Y maximum
	previousyMax = this.yMax;
	inboundYMax = this.dataSetYMax(this.dataset["inboundDataSet"]);
	outboundYMax = this.dataSetYMax(this.dataset["outboundDataSet"]);
	this.yMax = (inboundYMax > outboundYMax ? inboundYMax : outboundYMax);
	
	// Add 10% to the yMax so that we leave a little space
	this.yMax += (this.yMax * 0.1);
				
	// Set the Y scale
	if (this.yMax != previousyMax)							// New Y scale, redraw the Y ticks and labels.
		this.setYScale();
	// Draw the horizontal scale lines
	this.renderYLines(context);
	// Draw the vertical scale lines
	this.renderXLines(context);

	// Plot the two datasets.
	this.plotDataSet(context, "inboundDataSet");
	this.plotDataSet(context, "outboundDataSet");
	
	this.isRendering = false;
}

//
// Method: plotDataSet
// Plots the given dataset on the graph.
//
NetGraph.prototype.plotDataSet = function(context, dataSetName)
{
	xStep		= this.graphAreaWidth / this.xPoints;			// How many pixels between each point along the X axis?
	xLocation	= this.graphAreaLeft + 1;						// This will be our starting point on the X axis.
	yLocation	= this.graphAreaBottom - 1;						// This will be our starting point on the Y axis.
	
	// Create the fill/stroke gradients
	if (dataSetName == "inboundDataSet")
	{
		// Green (inbound) fill
		context.strokeStyle		= "rgba(0, 224, 0, 0.9)";					// Solid green
		var inboundGradient		= context.createLinearGradient(this.graphAreaLeft, this.graphAreaTop, this.graphAreaLeft, this.graphAreaBottom);
		inboundGradient.addColorStop(0,    "rgba(0,   224, 0,  1.0)");
		inboundGradient.addColorStop(0.75, "rgba(0,   224, 0,  0.7)");
		inboundGradient.addColorStop(1,    "rgba(50,  224, 50, 0.4)");
		context.fillStyle		= inboundGradient;
		
		immediateFillStyle		= "rgba(0, 224, 0, 0.7)";					// Immediate triangle fill style.
		immediateLineStyle		= "rgba(0, 224, 0, 0.3)";					// Immediate line stroke style.
	}
	else
	{
		// Outbound line
		context.strokeStyle		= "rgba(0, 224, 224, 0.9);";				// Aqua line
		immediateFillStyle		= "rgba(0, 224, 224, 0.7)";					// Immediate triangle fill style.
		immediateLineStyle		= "rgba(0, 224, 224, 0.3)";					// Immediate line stroke style.
	}
	
	context.lineWidth	= 0.8;
	
	context.beginPath();

	// Draw the graph points
	////////////////////////
	for(i = 0; i < this.xPoints; i++)
	{
		// Determine the Y position to draw to on the graph for this point.
		if (this.graphAreaHeight && this.yMax && this.dataset[dataSetName][i])
			yLocation	= (this.graphAreaHeight / this.yMax) * this.dataset[dataSetName][i];
		else
			yLocation	= 0;
			
		if (yLocation < 0)	
			yLocation	= 0;
		
		// Invert the Y point (canvas coords are top,left origin vs. bottom,left for our calculations)
		yPlot	= this.graphAreaBottom - yLocation - 1;
		
		// If this is the first point or the plot value is 0, moveTo - not lineTo
		if (i == 0 || yLocation == 0)
			context.moveTo(Math.round(xLocation), Math.round(yPlot));		// First point on the graph
		else
			context.lineTo(Math.round(xLocation), Math.round(yPlot));
		
		// Move the pen along one point on the x axis.
		xLocation += xStep;
	}
	
	
	// Complete the line (and fill if necessary)
	////////////////////////////////////////////
	if (dataSetName == "inboundDataSet")				// The inbound graph series is filled.
	{
		context.lineTo(this.graphAreaRight, this.graphAreaBottom);		// Move the pen to the bottom right so we get a good fill() or stroke()
		context.lineTo(this.graphAreaLeft, this.graphAreaBottom);
		context.fill();
	}
	else
		context.stroke();
		
	// Render the current value triangle.
	this.renderImmedateValueTriangle(context, this.dataset[dataSetName][this.dataset[dataSetName].length -1], immediateFillStyle, immediateLineStyle);
}

//
// Method: renderYLines
// Renders Y axis soft lines across the graph 
//
NetGraph.prototype.renderYLines = function(context)
{
	lineStartX = this.graphAreaLeft;									// The left starting point of the line.
	lineEndX   = this.graphAreaRight;									// The right (end) point of the line.
	lineCount = Math.round(this.graphAreaHeight / this.tickYSpacing);	// The number of lines to render.
	
    context.strokeStyle = "rgba(255,255,255,0.7)";
	context.lineWidth = 0.2;
	
	lineY = this.tickYSpacing - 2;						// The first line.
	for(i = 1; i < lineCount; i++)
	{
		context.beginPath();
		context.moveTo(Math.round(lineStartX), Math.round(lineY));
		context.lineTo(Math.round(lineEndX), Math.round(lineY));
		context.stroke();
		
		lineY += this.tickYSpacing;
	}
}

//
// Method: renderXLines
// Renders X axis soft lines across the graph 
//
NetGraph.prototype.renderXLines = function(context)
{
	lineStartY = this.graphAreaTop;										// The top starting point of the line.
	lineEndY   = this.graphAreaBottom;									// The bottom (end) point of the line.
	lineCount = Math.round(this.graphAreaWidth / this.tickXSpacing);	// The number of lines to render.
	
    context.strokeStyle = "rgba(255,255,255,0.3)";
	context.lineWidth = 0.2;
	
	lineX = this.graphAreaRight - this.tickXSpacing;						// The first line.
	for(i = 1; i < lineCount; i++)
	{
		context.beginPath();
		context.moveTo(Math.round(lineX), Math.round(lineStartY));
		context.lineTo(Math.round(lineX), Math.round(lineEndY));
		context.stroke();
		
		lineX -= this.tickXSpacing;
	}
}

//
// Method: renderImmedateValueTriangle
// Renders a dot showing the current (immediate) value 
//
NetGraph.prototype.renderImmedateValueTriangle = function(context, yPoint, triangleFillStyle, acrossLineStyle)
{
	BoxRight1 = this.graphAreaRight;								// Right-hand triangle
	BoxRight2 = BoxRight1 + 4;
	BoxLeft1 = this.graphAreaLeft;									// Left-hand triangle
	BoxLeft2 = BoxLeft1 - 4;
	BoxHeight = 5;
	
    context.fillStyle = triangleFillStyle;
	context.strokeStyle = acrossLineStyle;
	context.lineWidth = 1;
	
	// Determine the Y position to draw to on the graph for this point.
	if (this.graphAreaHeight && this.yMax && yPoint)
		yLocation = (this.graphAreaHeight / this.yMax) * yPoint;
	else
		yLocation = 1;
		
	// Invert the Y point (canvas coords are top,left origin vs. bottom,left for our calculations)
	yPlot = this.graphAreaBottom - yLocation - 1;

	// Draw the left triangle
	context.moveTo(Math.round(BoxRight1), Math.round(yPlot)+(BoxHeight / 2));
	context.lineTo(Math.round(BoxRight2), Math.round(yPlot));
	context.lineTo(Math.round(BoxRight1), Math.round(yPlot)-(BoxHeight / 2));
	context.fill();

	// Draw the right triangle
	context.moveTo(Math.round(BoxLeft1), Math.round(yPlot)+(BoxHeight / 2));
	context.lineTo(Math.round(BoxLeft2), Math.round(yPlot));
	context.lineTo(Math.round(BoxLeft1), Math.round(yPlot)-(BoxHeight / 2));
	context.fill();
	
	// Draw the line between them
	context.beginPath();
	context.moveTo(Math.round(BoxLeft1), Math.round(yPlot));
	context.lineTo(Math.round(BoxRight1), Math.round(yPlot));
	context.stroke();
}

//
// Method: setYScale
// Updates the scale values on the Y axis.
//
NetGraph.prototype.setYScale = function()
{
	yScaleText4 = formatDataRateShort(this.yMax);
	yScaleText3 = formatDataRateShort((this.yMax / 4) * 3);
	yScaleText2 = formatDataRateShort((this.yMax / 4) * 2);
	yScaleText1 = formatDataRateShort((this.yMax / 4));
	
	document.getElementById("textYScale4").innerHTML = yScaleText4;
	document.getElementById("textYScale3").innerHTML = yScaleText3;
	document.getElementById("textYScale2").innerHTML = yScaleText2;
	document.getElementById("textYScale1").innerHTML = yScaleText1;
}

//
// Method: addToDataset
// Adds the given value to the specified dataset.
// - This is called each time new bytes/Sec values come in. They get added to the dataset and the graph gets re-rendered.
// - If the dataset is full, old values get chopped off the end.
// - The dataset is essentially a FILO queue.
// - currentValue is the current value, regardless of whether we're graphing average or current values. 
//
NetGraph.prototype.addToDataset = function(/*String*/dataSetName, /*int*/value, /*int*/immediateValue)
{
	// Store the immediate value
	if (dataSetName == "inboundDataSet")
		this.immediateValueIn = immediateValue;
	else
		this.immediateValueOut = immediateValue;

	// Drop the first value from the dataset (shift it 'left')
	this.dataset[dataSetName].shift();
	// Add the new value to the end.
	this.dataset[dataSetName].push(value);
}

//
// Method: zeroDataSet
// Wipes the given data set name.
//
NetGraph.prototype.zeroDataSet = function(dataSetName)
{
	// Delete and re-initialise the array.
	delete this.dataset[dataSetName];
	this.dataset[dataSetName] = [];
	
	for(i=0;i<this.xPoints;i++)
		this.dataset[dataSetName].push(0);
}

//
// Method: dataSetYMax
// Determines the largest value in the given dataset (array).
//
NetGraph.prototype.dataSetYMax = function(dataSet)
{
	max = 0;
	
	for(i = 0; i < dataSet.length; i++)
		max = (dataSet[i] > max ? dataSet[i] : max);
		
	return max;
}

