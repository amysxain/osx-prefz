//
// CommandLine.js
// Contains command-line code and logic for issuing and handling output from external commands.

// External Commands
var snmpGetCommand = "/usr/bin/snmpget";
var snmpWalkCommand = "/usr/bin/snmpwalk";

var aOutputLines = [];

var hasError = false;
var errorMessage = "";

function SnmpOIDEnumerator(target, community)
{
	this.target = target;
	this.community = community;
	this.commandLine = "";
	this.oidFilter = "IF-MIB::ifDescr";
	this.systemCommand = "";
}

SnmpOIDEnumerator.prototype.OnReadOutput = function(line)
{
	if (line.length)
	{
		aOutputLines = [];
	
		// Split the lines out into an array.
		aLines = line.split("\n");
		if (aLines.length)
		{
			// Process the lines into our final array (aOutputLines). Ignore blank lines.
			for(i=0;i<aLines.length;i++)
				if (aLines[i].length)
				{
					alert("SNMP Enumerator: " + aLines[i]);
					
					// Create the label and the value for the dropdown item.
					// IF-MIB::ifDescr.1 = STRING: loopback (Leopard)
					// RFC1213-MIB::ifDescr.1 = STRING: "loopback"
					dropdownValue = aLines[i].replace(/([\w\d:.]+) \= .+/, "$1");
					dropdownLabel = aLines[i].replace(/.+ \= \w+\: ([\"\w\s\d:.]+)/, "$1");
					// Tiger fix - remove any " around the Label
					//dropdownLabel = dropdownLabel.replace(/\"/g, "");
					enumeratedInterfaceIndex = dropdownValue.replace(/.+?(\d+)$/, "$1");
					aOutputLines.push([enumeratedInterfaceIndex + ": " + dropdownLabel, enumeratedInterfaceIndex ]);
				}
		}
	}
}

SnmpOIDEnumerator.prototype.OnError = function(output)
{
	// Extract the last line of the error message.
	aErrorLines = output.split("\n");
	errorMessage = aErrorLines[aErrorLines.length-2];
	
	textRouterStatus = document.getElementById("textRouterStatus");
	textRouterStatus.innerHTML = errorMessage;
	textRouterStatus.style.setProperty("color", "#C9575C");

	hasError = true;
}

SnmpOIDEnumerator.prototype.OnFinished = function(command)
{
	// Re-enable the router/gateway and community text fields
	textRouter			= document.getElementById("textRouter");
	textRouter.disabled = false;
	textRouter.style.setProperty("background-color", "#fff");
	textSNMPCommunity			= document.getElementById("textSNMPCommunity");
	textSNMPCommunity.disabled	= false;	
	textSNMPCommunity.style.setProperty("background-color", "#fff");

	// Did we receive an error on stderr?
	if(hasError == true)
	{
		// Clear the interfaces dropdown.
		aErrorOptions = [];
		var popupInterface = document.getElementById("popupInterface");
		popupInterface.object.setOptions(aErrorOptions);

		// Set the indicator light to red.
		setConfigIndicatorStatus(15);

		// Set the status to the error message
		textRouterStatus = document.getElementById("textRouterStatus");
		textRouterStatus.style.setProperty("color", "#C9575C");
		textRouterStatus.innerHTML = errorMessage;
	}
	else
	{
		// Set the status to OK
		textRouterStatus = document.getElementById("textRouterStatus");
		textRouterStatus.style.setProperty("color", "#52C95C");
		textRouterStatus.innerHTML = "SNMP response received OK";
	
		// Update the Interface popup.
		var popupInterface = document.getElementById("popupInterface");
		popupInterface.object.setOptions(aOutputLines);
		
		// Set the selectedIndex (if we have it)
		if (interfaceIndex)
		{
			popupInterface.object.setSelectedIndex(interfaceIndex-1);	
			
			// Store the name of the currently selected interface. We then pick up on this and update the 
			interfaceName = aOutputLines[interfaceIndex-1][0].replace(/([\d:]+) ([\w\d\s\-\.\(\)]+)/, "$2");
		}
		else
			interfaceName = "";
		
		// Set the light to green.
		setConfigIndicatorStatus(1);
	}
}

SnmpOIDEnumerator.prototype.Execute = function()
{
	hasError = false;
	
	// Gray out the router name and community string whilst we update the interfaces from it.
	textRouter = document.getElementById("textRouter");
	textSNMPCommunity = document.getElementById("textSNMPCommunity");
	textRouter.disabled = true;
	textRouter.style.setProperty("background-color", "#ddd");
	textSNMPCommunity.disabled = true;	
	textSNMPCommunity.style.setProperty("background-color", "#ddd");
	
	// Set up the snmpwalk command and execute it.
	this.commandLine = snmpWalkCommand + " -v1 -c " + this.community + " " + this.target + " " + this.oidFilter;

	// Execute the snmpwalk
	alert("Executing snmpwalk: " + this.commandLine);
	this.systemCommand = widget.system(this.commandLine, this.OnFinished);
	this.systemCommand.onreadoutput = this.OnReadOutput;
	this.systemCommand.onreaderror = this.OnError;
}