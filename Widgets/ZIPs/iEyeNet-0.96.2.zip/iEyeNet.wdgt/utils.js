//
// utils.js
// Generic utility functions

var routeTableCommand = "/usr/sbin/netstat";

//
// Function: formatDataRate(dataRate)
// Takes a numeric input and formats it as a the correct data rate
// 1011 => 1011 bytes/sec
// 12894 => 12.8KB/sec
// 131442 => 131.4KB/sec
// 6443221 => 6.44MB/sec
//
function formatDataRate(dataRate, displayUnits)
{
	returnValue = "";
	
	switch(displayUnits)
	{
		case "displayUnitsKbytes":
			KBSuffix = "KB/s";
			MBSuffix = "MB/s";
			GBSuffix = "GB/s";
			break;
		case "displayUnitsKbits":
			// Convert bytes to bits
			dataRate = dataRate * 8;
			KBSuffix = "Kbps";
			MBSuffix = "Mbps";
			GBSuffix = "Gbps";
			break;
	}
	
	if (dataRate < 128)
		returnValue = "< 0.1 " + KBSuffix;
	else if (dataRate >= 128 && dataRate < (1024))
	{
		returnValue = (dataRate / 1024).toFixed(2) + " " + KBSuffix;
	}
	else if (dataRate >= 1024 && dataRate < (1024 * 1024))
	{
		returnValue = (dataRate / 1024).toFixed(2) + " " + KBSuffix;
	}
	else if (dataRate >= (1024 * 1024) && dataRate < (1024 * 1024 * 1024))
	{
		returnValue = (dataRate / 1024 / 1024).toFixed(2) + " " + MBSuffix;
	}
	else if (dataRate >= (1024 * 1024 * 1024) && dataRate < (1024 * 1024 * 1024 * 1024))
	{
		returnValue = (dataRate / 1024 / 1024 / 1024).toFixed(2) + " " + GBSuffix;
	}
	
	return returnValue;
}

//
// Function: formatDataRateShort(dataRate)
// Takes a numeric input and formats it as a the correct data rate
// 1011 => 1011 b
// 12894 => 12.8 K
// 131442 => 131.4 K
// 6443221 => 6.44 M
// 7556443221 => 7.55 G
//
function formatDataRateShort(dataRate)
{
	returnValue = "";
	
	switch(displayUnits)
	{
		case "displayUnitsKbytes":
			BSuffix = "b";
			KBSuffix = "K";
			MBSuffix = "M";
			GBSuffix = "G";
			break;
		case "displayUnitsKbits":
			// Convert bytes to bits
			dataRate = dataRate * 8;
			BSuffix = "b";
			KBSuffix = "K";
			MBSuffix = "M";
			GBSuffix = "G";
			break;
	}	
	
	if (dataRate < 128)
		returnValue = "< 0.1 " + KBSuffix;
	else if (dataRate >= 128 && dataRate < (1024))
	{
		returnValue = (dataRate / 1024).toFixed(1) + " " + BSuffix;
	}
	else if (dataRate >= 1024 && dataRate < (1024 * 1024))
	{
		returnValue = (dataRate / 1024).toFixed(1) + " " + KBSuffix;
	}
	else if (dataRate >= (1024 * 1024) && dataRate < (1024 * 1024 * 1024))
	{
		returnValue = (dataRate / 1024 / 1024).toFixed(1) + " " + MBSuffix;
	}
	else if (dataRate >= (1024 * 1024 * 1024) && dataRate < (1024 * 1024 * 1024 * 1024))
	{
		returnValue = (dataRate / 1024 / 1024 / 1024).toFixed(1) + " " + GBSuffix;
	}
	
	return returnValue;
}


//
// Function: autoDiscoverRouter()
// Automatically discovers this machine's default route by reading the routing table.
//
function autoDiscoverRouter()
{
	defaultRouter = "";
	
	document.getElementById("textRouterLabel").innerHTML = "Discovering your router...";

	// Execute the command
	commandLine = routeTableCommand + " -rn";
	output = widget.system(commandLine, null).outputString;

	// Process the output
	if (output.length)
	{
		// Split the lines out into an array.
		aLines = output.split("\n");
		if (aLines.length)
		{
			// Process the lines. Ignore blank lines.
			for(i=0;i<aLines.length;i++)
				if (aLines[i].length)
				{
					// Process the line.
					if (aLines[i].search(/^default.+/) != -1)
					{	
						// Found the default route line - extract it.
						matches = aLines[i].match(/^default\s+([\d\.]+).+/);
						if (matches[1])
						{
							defaultRouter = matches[1];
							break;
						}
					}
				}
		}
	}
	
	return defaultRouter;
}

//
// Function: getUTCNow()
// Returns the number of milliseconds since January 1st, 1970
//
function getUTCNow()
{
	now = new Date();
	return Date.UTC(now.getUTCFullYear(), 
					now.getUTCMonth(), 
					now.getUTCDay(), 
					now.getUTCHours(), 
					now.getUTCMinutes(), 
					now.getUTCSeconds(), 
					now.getUTCMilliseconds());
}

//
// Function: arrayAverage(array)
// Returns the average of all values in the array.
//
function arrayAverage(array)
{
	total = 0;
	for(i=0;i<array.length;i++)
		total += array[i];
	return total / array.length;
}