var localizedStrings = new Object;

localizedStrings["PROCESSOR"] = "PROCESSOR";
localizedStrings["DISK ACTIVITY"] = "DISK ACTIVITY";
localizedStrings["NETWORK"] = "NETWORK";
localizedStrings["IN"] = "IN";
localizedStrings["OUT"] = "OUT";
localizedStrings["Done"] = "Done";
