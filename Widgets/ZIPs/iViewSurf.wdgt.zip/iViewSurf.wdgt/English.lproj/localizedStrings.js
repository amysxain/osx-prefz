var localizedStrings = new Array;

localizedStrings['Wind speed'] = 'Wind speed';
localizedStrings['Waves height'] = 'Waves height';
localizedStrings['Temperature'] = 'Temperature';

localizedStrings['Knots'] = 'Knots';
localizedStrings['Bft'] = 'Bft';
localizedStrings['Mph'] = 'Mph';
localizedStrings['Km/h'] = 'Km/h';
localizedStrings['m/s'] = 'm/s';

localizedStrings['Meters'] = 'Meters';
localizedStrings['Feet'] = 'Feet';

localizedStrings['&deg;C'] = '&deg;C';
localizedStrings['&deg;F'] = '&deg;F';

//localizedStrings[''] = '';
