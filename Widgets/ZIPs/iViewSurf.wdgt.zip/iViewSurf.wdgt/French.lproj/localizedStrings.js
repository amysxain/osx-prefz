var localizedStrings = new Array;

localizedStrings['Wind speed'] = 'Vitesse vent';
localizedStrings['Waves height'] = 'Hauteur vagues';
localizedStrings['Temperature'] = 'Temp&eacute;rature';

localizedStrings['Knots'] = 'Noeuds';
localizedStrings['Bft'] = 'Beauforts';
localizedStrings['Mph'] = 'Mph';
localizedStrings['Km/h'] = 'Km/h';
localizedStrings['m/s'] = 'm/s';

localizedStrings['Meters'] = 'Metres';
localizedStrings['Feet'] = 'Pieds';

localizedStrings['&deg;C'] = '&deg;C';
localizedStrings['&deg;F'] = '&deg;F';

//localizedStrings[''] = '';
