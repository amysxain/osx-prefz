
// SETUP FUNCTIONS.
// Called on widget creation, reload.
var spots=Array();

spots[0]=Array(1,"---select spot---","");

spots[1]=Array(3,"anglet corsaires","http://films.viewsurf-attitude.com/angletcorsaires/p3/last_lst");
spots[2]=Array(3,"anglet surf club","http://films.viewsurf-attitude.com/anglet/surf_club_320/last_lst");
spots[3]=Array(3,"anglet vvf","http://films.viewsurf-attitude.com/anglet/VVF_320/last_lst");
spots[4]=Array(3,"anglet sables d'or","http://films.viewsurf-attitude.com/anglet/sables_320/last_lst");
spots[5]=Array(1,"anglet cavaliers nord","http://www.viewsurf-attitude.com/video.php?id=335&type=1");
spots[6]=Array(1,"anglet cavaliers sud","http://www.viewsurf-attitude.com/video.php?id=337&type=1");

spots[7]=Array(1,"biarritz","http://www.viewsurf-attitude.com/video.php?id=48&type=1");
spots[8]=Array(3,"biscarrosse","http://films.viewsurf-attitude.com/biscarrosse/bisca320/last_lst");
spots[9]=Array(2,"capbreton","2226");
spots[10]=Array(3,"hendaye","http://films.viewsurf-attitude.com/hendaye/320_vs//last_lst");
spots[11]=Array(2,"hossegor","2232");


spots[12]=Array(3,"lacanau plage centrale","http://films.viewsurf-attitude.com/lacanaucentrale/320/last_lst");
spots[13]=Array(3,"lacanau plage nord3","http://films.viewsurf-attitude.com/lacanaunord/vue2_320/last_lst");
spots[14]=Array(3,"lacanau plage sud","http://films.viewsurf-attitude.com/lacanausud/lacanausud320/last_lst");
spots[15]=Array(3,"mimizan plage nord","http://films.viewsurf-attitude.com/mimizan/nord320//last_lst");
spots[16]=Array(3,"mimizan plage sud","http://films.viewsurf-attitude.com/mimizan/sud320//last_lst");


spots[17]=Array(3,"saint jean de luz","http://films.viewsurf-attitude.com/sjdeluz/surf_320/last_lst");
spots[18]=Array(3,"saint jean de luz zoom","http://films.viewsurf-attitude.com/sjdeluz/Stbarbe/last_lst");

spots[19]=Array(1,"seignosse le penon","http://www.viewsurf-attitude.com/video.php?id=368&type=1");
spots[20]=Array(1,"seignosse les bourdaines","http://www.viewsurf-attitude.com/video.php?id=369&type=1");
spots[21]=Array(1,"seignosse estagnots","http://www.viewsurf-attitude.com/video.php?id=367&type=1");

spots[22]=Array(1,"soulac","http://www.viewsurf-attitude.com/video.php?id=400&type=1");

spots[23]=Array(1,"---snow---","");

spots[24]=Array(3,"cauterets - ts des cretes 1","http://films.viewsurf-attitude.com/cauterets/lelys/321_vs/last_lst");
spots[25]=Array(3,"cauterets - ts des cretes 2","http://films.viewsurf-attitude.com/cauterets/lelys/322_vs/last_lst");
spots[26]=Array(3,"cauterets - ts des cretes 3","http://films.viewsurf-attitude.com/cauterets/lelys/323_vs/last_lst");
spots[27]=Array(3,"cauterets - ts des cretes 4","http://films.viewsurf-attitude.com/cauterets/lelys/320_vs/last_lst");
spots[28]=Array(3,"cauterets - plat du clos","http://films.viewsurf-attitude.com/cauterets/pontdespagne/320_vs/last_lst");
spots[29]=Array(3,"cauterets - village","http://films.viewsurf-attitude.com/cauteretsvillage/320/last_lst");

spots[30]=Array(5,"font romeu","http://films.viewsurf-attitude.com/fontromeu//fontromeu.vcr");

spots[31]=Array(3,"gourette 1","http://films.viewsurf-attitude.com/gourette/gourette320/last_lst");
spots[32]=Array(3,"gourette 2","http://films.viewsurf-attitude.com/gourette/gourette321/last_lst");
spots[33]=Array(3,"gourette 3","http://films.viewsurf-attitude.com/gourette/gourette322/last_lst");
spots[34]=Array(3,"gourette 4","http://films.viewsurf-attitude.com/gourette/gourette323/last_lst");

spots[35]=Array(3,"pierre st martin","http://films.viewsurf-attitude.com/pierresaintmartin/pistes320/last_lst");
spots[36]=Array(1,"pierre st martin - pistes","http://www.viewsurf-attitude.com/video.php?id=501&type=1");

spots[37]=Array(1,"luz ardiden","http://www.viewsurf-attitude.com/video.php?id=393&type=1");

spots[38]=Array(1,"peyragudes - arrivee","http://www.viewsurf-attitude.com/video.php?id=514&type=1");
spots[39]=Array(3,"peyragudes - les agudes","http://films.viewsurf-attitude.com/peyragudes/peyragudes/320_vs/last_lst");
spots[40]=Array(1,"peyragudes - serre doumenge","http://www.viewsurf-attitude.com/video.php?id=515&type=1");
spots[41]=Array(3,"peyragudes - peyresourde","http://films.viewsurf-attitude.com/peyragudes/peyresourde/320_vs/last_lst");
spots[42]=Array(1,"peyragudes - sommet","http://www.viewsurf-attitude.com/video.php?id=511&type=1");
spots[43]=Array(1,"peyragudes - telesiege","http://www.viewsurf-attitude.com/video.php?id=513&type=1");

spots[44]=Array(1,"piau engaly - canons a neige","http://www.viewsurf-attitude.com/video.php?id=499&type=1");
spots[45]=Array(1,"piau engaly - espace debutants","http://www.viewsurf-attitude.com/video.php?id=385&type=1");
spots[46]=Array(1,"piau engaly - pic de piau","http://www.viewsurf-attitude.com/video.php?id=383&type=1");
spots[47]=Array(1,"piau engaly - ts clot et cantoural","http://www.viewsurf-attitude.com/video.php?id=384&type=1");

spots[48]=Array(1,"saint lary - big air","http://www.viewsurf-attitude.com/video.php?id=520&type=1");
spots[49]=Array(1,"saint lary - mirabelle bas","http://www.viewsurf-attitude.com/video.php?id=522&type=1");
spots[50]=Array(1,"saint lary - mirabelle haut","http://www.viewsurf-attitude.com/video.php?id=521&type=1");
spots[51]=Array(1,"saint lary - plat d'aldet","http://www.viewsurf-attitude.com/video.php?id=76&type=1");
spots[52]=Array(1,"saint lary - plat d'aldet zoom","http://www.viewsurf-attitude.com/video.php?id=157&type=1");
spots[53]=Array(1,"saint lary - snow park","http://www.viewsurf-attitude.com/video.php?id=519&type=1");
spots[54]=Array(1,"saint lary - telesiege","http://www.viewsurf-attitude.com/video.php?id=518&type=1");


function doSetup() {
	if (window.widget)
	{
		var mySpot=widget.preferenceForKey(createkey("mySpot"));
		if (!mySpot) {
			mySpot=7;
			widget.setPreferenceForKey(mySpot,createkey("mySpot"));
		}
	}
	createGenericButton(document.getElementById('done'), "OK", hidePrefs,40);
	loadCam();
}

//
// WIDGET EVENTS
if (window.widget) {
	widget.onremove = onremove;
	widget.onshow = onshow;
	widget.onhide = onhide;
}

function onremove () {
	if (window.widget) {
		widget.setPreferenceForKey("",createkey("mySpot"));
	}
}

// Restart the animations (if they were already going)

function onshow () {
	loadCam();
}

// Pause the animation on hide (no wasted cycles or trans fats)

function onhide () {
	document.getElementById('webcam').innerHTML = "";
}
function drawPrefs() {
	var selectSpot=document.getElementById('selectSpot');
	removeAllChildren(selectSpot);
	var nbspots=spots.length;
	var mySpot=widget.preferenceForKey(createkey("mySpot"));
	for (var i=0;i<nbspots;i++) {
		var option=document.createElement('option');
		option.setAttribute("value",i);
		if (i==mySpot) {
			option.setAttribute("selected", "");
		}
		option.appendChild(document.createTextNode(spots[i][1]));
		selectSpot.appendChild(option);
	}
}
function removeAllChildren (parent)
{
	while (parent.hasChildNodes())
		parent.removeChild(parent.firstChild);
}

function loadCam() {
	var mySpot=widget.preferenceForKey(createkey("mySpot"));
	var sortie="";
	switch(spots[mySpot][0]) {
		case 1:
			/*sortie+='<applet code="com.fluendo.player.Cortado.class" codebase="http://java.viewsurf-attitude.com/vb2_320" archive="cortado-vs-0.1.2-3.jar" width="320" height="240">';
			sortie+='<param name="url" value="'+spots[mySpot][1]+'"/>'
			sortie+='<param name="debug" value="0" />'
			sortie+='<param name="loopPause" value="0" />'
			sortie+='</applet>';*/
			loadXMLDoc(spots[mySpot][2]);
			break;
		case 2:
			sortie+="<applet code='JPEG.class' width='320' height='240' codebase='http://javalive.viewsurf.com/java_caillou' archive='vcrviewer.jar'><param name='live' value='true'><param name='logo' value='true'><param name='host' value='live.viewsurf.com'><param name='port' value='"+spots[mySpot][2]+"'></applet>";
			break;	
		case 3:
			sortie+="<applet code='JPEG.class' width='320' height='240' codebase='http://java.viewsurf-attitude.com/java_caillou' archive='vcrviewer.jar'><param name='live' value='false'><param name='logo' value='true'><param name='loop' value='true'><param name='last_lst' value='"+spots[mySpot][2]+"'></applet>";
			break;
		case 4: //fluendo
			sortie+='<applet code="com.fluendo.player.Cortado.class" codebase="http://java.viewsurf-attitude.com/vb2_320" archive="cortado-vs-0.1.2-3.jar" width="320" height="240"><param name="url" value="'+spots[mySpot][2]+'"/><param name="debug" value="0" /><param name="loopPause" value="0" /></applet>';
			break;
		case 5: //vcr
			sortie+="<applet code='JPEG.class' width='320' height='240' codebase='http://java.viewsurf-attitude.com/java_alliance' archive='vcrviewer.jar'><param name='live' value='false'><param name='logo' value='true'><param name='loop' value='true'><param name='file' value='"+spots[mySpot][2]+"'></applet>";
			break;			
			
		default:
			break;
	}
	document.getElementById('webcam').innerHTML = sortie;
	document.getElementById('webcamTitre').innerHTML =spots[mySpot][1];
}


function changeSpot() {
	widget.setPreferenceForKey(document.getElementById('selectSpot').value,createkey("mySpot"));
	loadCam() ;
}
function drawCam(valeur) {
	valeur=valeur.substring(valeur.indexOf("<applet"),valeur.indexOf("</applet>"));
	document.getElementById('webcam').innerHTML = valeur+"</applet>";
}


function getLocalizedString (key) {
	try {
		var ret = localizedStrings[key];
		if (ret === undefined)
			ret = key;
		return ret;
	} catch (ex) {}
	return key;
}
function removeAllChildren (parent)
{
	while (parent.hasChildNodes())
		parent.removeChild(parent.firstChild);
}

function createkey(key)
{
	return widget.identifier + "-" + key;
}

function GiveHex(Dec){
   var v;if(Dec==10) v="A";else if(Dec==11) v="B";else if(Dec==12) v="C";else if(Dec==13) v="D";else if(Dec==14) v="E";else if(Dec==15) v="F";else v=""+Dec; return v;
}

// FLIPPER
// What follows is Apple's standard flipper magic
function showPrefs() {
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	if (window.widget)
		widget.prepareForTransition("ToBack");		// freezes the widget so that you can change it without the user noticing
	
	front.style.display="none";		// hide the front
	back.style.display="block";		// show the back
	
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);		// and flip the widget over	

	document.getElementById('fliprollie').style.display = 'none';  // clean up the front side - hide the circle behind the info button
}

var isIE = false;
var req;

function hidePrefs() {
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	
	if (window.widget)
		widget.prepareForTransition("ToFront");		// freezes the widget and prepares it for the flip back to the front
	
	back.style.display="none";			// hide the back
	front.style.display="block";		// show the front
	
	if (window.widget)
		setTimeout ('widget.performTransition();', 0);		// and flip the widget back to the front
		setTimeout('hintStart();', 750);	// I wish there was a way to get notified when the flip is complete!
	
}

// PREFERENCE BUTTON ANIMATION (the pref flipper fade in/out)

var flipShown = false;		// a flag used to signify if the flipper is currently shown or not.

// A structure that holds information that is needed for the animation to run.

var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};

function mousemove (event) {
	if (!flipShown)	{							// if the preferences flipper is not already showing...
		if (animation.timer != null) {			// reset the animation timer value, in case a value was left behind
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		
		var starttime = (new Date).getTime() - 13; 		// set it back one frame
		
		animation.duration = 500;												// animation time, in ms
		animation.starttime = starttime;										// specify the start time
		animation.firstElement = document.getElementById ('flip');				// specify the element to fade
		animation.timer = setInterval ("animate();", 13);						// set the animation function
		animation.from = animation.now;											// beginning opacity (not ness. 0)
		animation.to = 1.0;														// final opacity
		animate();																// begin animation
		flipShown = true;														// mark the flipper as animated
	}
}

// mouseexit() is the opposite of mousemove() in that it preps the preferences flipper
// to disappear.  It adds the appropriate values to the animation data structure and sets the animation in motion.

function mouseexit (event) {
	if (flipShown) {
		// fade in the flip widget
		if (animation.timer != null) {
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		
		var starttime = (new Date).getTime() - 13;
		
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}


// animate() performs the fade animation for the preferences flipper. It uses the opacity CSS property to simulate a fade.

function animate() {
	var T;
	var ease;
	var time = (new Date).getTime();
	
	T = limit_3(time-animation.starttime, 0, animation.duration);
	
	if (T >= animation.duration) {
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	}
	else {
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}
	
	animation.firstElement.style.opacity = animation.now;
}


// these functions are utilities used by animate()

function limit_3 (a, b, c) {
    return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease) {
    return from + (to - from) * ease;
}

// these functions are called when the info button itself receives onmouseover and onmouseout events

function enterflip(event) {
	document.getElementById('fliprollie').style.display = 'block';
}

function exitflip(event) {
	document.getElementById('fliprollie').style.display = 'none';
}

//xml parse fonctions :
function processReqChange() {
    // only if req shows "loaded"
    if (req.readyState == 4) {
        // only if "OK"
        if (req.status == 200) {
			//parseWind(req.responseText);
			/*widget.setPreferenceForKey(req.responseText,createkey("myLastWind"));
			drawWind();*/
			drawCam(req.responseText);
          	//drawWind(req.responseText);
         } else {
			//document.getElementById('chronotexte2').innerHTML="ca fuck";
         }
    }
}
function loadXMLDoc(url) {
    // branch for native XMLHttpRequest object
	
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        req.onreadystatechange = processReqChange;
        req.open("GET", url, true);
        req.send(null);
    // branch for IE/Windows ActiveX version
    } else if (window.ActiveXObject) {
        isIE = true;
        req = new ActiveXObject("Microsoft.XMLHTTP");
        if (req) {
            req.onreadystatechange = processReqChange;
            req.open("GET", url, true);
            req.send();
        }
    }
}
